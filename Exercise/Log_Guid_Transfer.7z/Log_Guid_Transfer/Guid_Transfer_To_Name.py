import os
import sys
import random
from pprint import pprint

import re


class GuidAction():
    def __init__(self):
        self.Guid_Table = []
        self.transfer_guid_file_to_list()

    def transfer_guid_file_to_list(self):
        with open("Guid.xref", "r") as Guid_File:
            for line in Guid_File:
                line_list = (line.replace("\n", "")).split(' ')
                self.Guid_Table.append(line_list)
#            print(self.Guid_Table)

    def check_and_replace_guid(self, line):
        if 4 <= line.count('-'):
            line_list = (line.replace("\n", "")).split(' ')
            for index, k in enumerate(line_list):
                if 4 == k.count('-'):
                    for g, name in self.Guid_Table:
                        if k == g:
                            line_list[index] = name
            return ' '.join(line_list) + "\n"
        return


if __name__ == '__main__':
    p = GuidAction()

    with open("LivingStone2.log", "r") as Old_log:
        with open("New.txt", "w") as New_log:
            for original_message in Old_log:
                m_message = p.check_and_replace_guid(original_message)
                if m_message is None:
                    m_message = original_message
                New_log.write(m_message)
