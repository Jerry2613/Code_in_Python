/*++

Copyright (c) 2016 Dell Inc. All rights reserved.
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Dell Inc.

Module Name:

    RuggedSpecialSUMATable.h

Abstract:

--*/

#ifndef _RUGGED_SPECIAL_SUMA_TABLE_H_
#define _RUGGED_SPECIAL_SUMA_TABLE_H_

#define USE_SHA1
#define SALTVALUE_USE_MAC_ADDRESS
#define ServiceTagNum               22318 

#define MAX_TAG_STRING_SIZE             81 // 81 Allocate enough space for the max owner tag + a NULL character.

#ifdef SALTVALUE_USE_MAC_ADDRESS
#define SaltValueSize		            13 // 12 bytes ASCII MAC with trailing null
#else
#define SaltValueSize		             7 // 7 Allocate enough space for the salt value + a NULL character.
#endif

UINT8 mSalt[SaltValueSize]= {"rugged"};

extern EFI_GUID gFormerServiceTagGuid;

typedef struct _DELL_SERVICETAG_VALUE
{  
    UINT8       ServiceTagValue[MAX_TAG_STRING_SIZE];	// 80 bytes ASCII with trailing null
} DELL_SERVICETAG_VALUE;

typedef struct _DELL_SERVICETAG_DIGEST
{
    UINT32       HashValue0;
    UINT32       HashValue1;
    UINT32       HashValue2;
    UINT32       HashValue3;
#ifdef USE_SHA1
    UINT32       HashValue4;
#endif
} DELL_SERVICETAG_DIGEST;

typedef struct _DELL_SPECIAL_MAC_ADDRESS
{  
    UINT8       MacAddress[13];	   // 12 bytes ASCII MAC with trailing null
} DELL_SPECIAL_MAC_ADDRESS;

DELL_SERVICETAG_DIGEST mServiceTagDigest[ServiceTagNum] = {
#ifdef USE_SHA1
#include <RuggedDigest.h>
#else
#include <RuggedDigest_MD5.h>	
#endif	
};

DELL_SPECIAL_MAC_ADDRESS mMac[] = {
#include <RuggedMac.h>	
};

#endif
