//*************************************************************************
//*************************************************************************
//**                                                                     **
//**        (C)Copyright 1985-2016, American Megatrends, Inc.            **
//**                                                                     **
//**                       All Rights Reserved.                          **
//**                                                                     **
//**      5555 Oakbrook Parkway, Suite 200, Norcross, GA 30093           **
//**                                                                     **
//**                       Phone: (770)-246-8600                         **
//**                                                                     **
//*************************************************************************
//*************************************************************************

//*************************************************************************
// $Header:
//
// $Revision:
//
// $Date:
//*************************************************************************
// Revision History
// ----------------
// $Log:
//
//*************************************************************************
//<AMI_FHDR_START>
//
// Name:        DellAuxMac.c
//
// Description:
//
//<AMI_FHDR_END>
//*************************************************************************

#include "AmiDxeLib.h"
#include "DellCommonLib.h"
#include "Protocol\DellProperty.h"
#include "Protocol\DellMfgMode.h"

#include "DellAuxMac.h"
#include "Protocol\SmmBase2.h"
//#include <Protocol\SmmSwDispatch2.h>//<set-test>
//#include <Protocol\SmmSwDispatch.h>//<set-test>

#include <Guid/DellPersistentPropertyIds.h>
#include <Library/BaseLib.h>
#include <AcpiRes.h>
#include <Library/DellSmmRange.h>
//<AMI_UPDATE>- 20160908 Fix debug mode build error. >>>
//- #include <Library/DebugLib.h>
//<AMI_UPDATE>- 20160908 Fix debug mode build error. <<<

#define CAST_TO_VOIDPTR(u)      ((VOID*)((UINTN)u))

EFI_GUID gAuxMacGuid = AUX_MAC_GUID;  //<PROJECT_CHANGE>+ 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level
extern EFI_GUID  gEfiAcpi20TableGuid;
extern EFI_GUID  gEfiAcpi10TableGuid;

EFI_SMB_SMM_DACI_PROTOCOL   	*DaciProtocol = NULL;
DELL_PROPERTY_PROTOCOL  		*PropertyProtocol = NULL;
EFI_SMM_SYSTEM_TABLE2           *gSmst2 = NULL;


//<set-test> +>
/*EFI_STATUS
SetTest (
	EFI_HANDLE			ImageHandle,
	EFI_SMM_SW_DISPATCH_CONTEXT *DispatchContext,
    VOID         *CommBuffer,
    UINTN        *CommBufferSize)
{
    EFI_STATUS                  Status = EFI_SUCCESS;
    DELL_AUX_MAC_ADDRESS 			*pMacAddr;
    UINT8 buffer[17]={13,0,0,0,'a','b','c','d','e','f','g','h','i','j','k','l',0};

    DEBUG_DELL (DBG_SMM_LOM_SMB, ("gAux=%x\n",gAux));
    pMacAddr=((DELL_AUX_MAC_ADDRESS *)((UINT64)(&buffer)));
    Status = PropertyProtocol->SetProperty ( PropertyProtocol,
                                             PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             sizeof(DELL_AUX_MAC_ADDRESS),
                                             pMacAddr);
    memcpy(gAux->NameString,"_AUXMAC_#", sizeof("_AUXMAC_#"));
    memcpy(gAux->AuxMac,pMacAddr->AuxMacAddress,sizeof(pMacAddr->AuxMacAddress));
    gAux->EndChar[0]='#';
    gAux->EndChar[1]=0;

    DsdtTable->Checksum = 0;
    DsdtTable->Checksum=ChsumTbl((UINT8*)DsdtTable,DsdtTable->Length);

	return EFI_SUCCESS;
}*/
//<set-test> +<

//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   GetAUXMAC
//
// Description: Class 11 selector 6
//
//
// Input:cbArg1  Address of output buffer as example.
//   buffer[] = {13,0,0,0,'D','S','C','I','D','S','C','I','D','S','C','I',x}
//
// Output:cbRes1 	0	success
//					-1	error
//					-5	did not have the proper format
//					-6	Size is not enough
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
VOID
EFIAPI
GetAUXMAC(
    IN OUT SMBIOS_DACI_COMMAND_BUFFER   *CommandBuffer
)
{
    EFI_STATUS                   Status;
    DELL_AUX_MAC_ADDRESS         pMacAddr;
    UINTN                        Size;
    UINT8                        *pData = NULL;
    UINT32                       *Length = NULL; 
    UINT32                       BufSize;

    /*
      only use this for writing the length field back to smbios buffers
      if you read from this by dereferencing, you subject yourself to 
      double fetch issues
    */
    UINT32 *pOutLength = NULL;

    /*
      Patching CheckInputBuffer call to use the new calling convention to avoid race conditions
      See CheckInputBuffer_s for further information
    */
    if(BufferTouchesSmram(CAST_TO_VOIDPTR(CommandBuffer->cbArg1), sizeof(UINT32)))
    {
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER;
        DEBUG_DELL (DBG_SMM_LOM_SMB, ("CommandBuffer->cbArg1 touches SMRAM. Asserting due to security violation.\n"));
        ASSERT(FALSE);
        return;
    }

    *Length = *(UINT32 *)(CAST_TO_VOIDPTR(CommandBuffer->cbArg1));
    pOutLength = (UINT32 *)(CAST_TO_VOIDPTR(CommandBuffer->cbArg1));

    //Check input buffer format
//    if (!mDaciProtocol->CheckInputBuffer((VOID*)(UINTN)SmbiosCb->cbArg3, &BufferSize, &Buffer)) {    
    if (DaciProtocol->CheckInputBuffer((VOID*)(UINTN)(CommandBuffer->cbArg1), &Length, &pData) == FALSE)
    {
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER;
        return;
    }
    Size = sizeof(DELL_AUX_MAC_ADDRESS);
    Status = PropertyProtocol->GetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             &Size,
                                             &pMacAddr);
    //If AUX MAX has not been set, return -1
    if (EFI_ERROR(Status))
    {
        CommandBuffer->cbRes1 = SMBIOS_ERROR;
        return;
    }

    BufSize=*Length;

    //Check input buffer size
    if (BufSize < pMacAddr.DataSize)
    {
        *pOutLength = pMacAddr.DataSize;
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER_SIZE;
        return;
    }

    MemCpy(pData,pMacAddr.AuxMacAddress, pMacAddr.DataSize);
    CommandBuffer->cbRes1 = SMBIOS_SUCCESS;
}
//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   SetAUXMAC
//
// Description: Class 11 selector 7
//
//
// Input:cbArg1  Address of input buffer as example.
//   buffer[] = {13,0,0,0,'1','2','3','4','5','6','7','8','9','A','B','C',0}
//
//
// Output: cbRes1 	0	success
// 				 	-1	error
//				 	-5	did not have the proper format
//
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
VOID
EFIAPI
SetAUXMAC(
    IN OUT SMBIOS_DACI_COMMAND_BUFFER   *CommandBuffer
    )
{
    EFI_STATUS                  Status;
    DELL_AUX_MAC_ADDRESS        *pMacAddr;
    UINT8                       MacChar;
    UINT8                       i;
    DELL_MFG_MODE_PROTOCOL      *MfgModeProtocol;
    ACTIVE_MFG_MODES            ActiveMfgModes = 0;

    // Check if manufacturing mode is on
    Status = gSmst2->SmmLocateProtocol ( &gDellSmmMfgModeProtocolGuid,
                                         NULL,
                                         &MfgModeProtocol);
    if (EFI_ERROR (Status))
        return ;

    MfgModeProtocol->GetMfgMode(&ActiveMfgModes,
                                MFG_MODE_CLASSIC,
                                MFG_MODE_SERVICE_MENU,
                                MFG_MODE_DELL_FACTORY,
                                MFG_MODE_SYSTEM_SERVICE,
                                MFG_MODE_OPEN_SECURITY,
                                MFG_MODE_FACTORY_UTILITIES,
                                MFG_MODE_ENGINEERING,
                                MFG_MODE_PCBA_FLAG,
                                MFG_MODE_NULL);
    if(!ActiveMfgModes)
    {
        CommandBuffer->cbRes1 = SMBIOS_ERROR;
        return ;
    }

    //Check ASCII hex characters in [0-9,A-F,a-f]
    pMacAddr=((DELL_AUX_MAC_ADDRESS *)((UINT64)(CommandBuffer->cbArg1)));
    for(i=0;i<(pMacAddr->DataSize-1);i++)
    {
        MacChar = pMacAddr->AuxMacAddress[i];
        if( !(  ((MacChar >= '0') && (MacChar <= '9')) ||
                ((MacChar >= 'A') && (MacChar <= 'F')) ||
                ((MacChar >= 'a') && (MacChar <= 'f')) ) )
        {
            CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER;
            return;
        }
    }
    //Check end char
    if(pMacAddr->AuxMacAddress[i]!=0)
    {
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER;
        return;
    }
    //Check size
    if(pMacAddr->DataSize!=AUX_MAC_SIZE)
    {
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER_SIZE;
        return;
    }
    Status = PropertyProtocol->SetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             sizeof(DELL_AUX_MAC_ADDRESS),
                                             pMacAddr);
    if (EFI_ERROR(Status))
    {
        CommandBuffer->cbRes1 = SMBIOS_ERROR;
        return;
    }

    CommandBuffer->cbRes1 = SMBIOS_SUCCESS;

}
//<PROJECT_CHANGE>- 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level >>>
/*
//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   SetOpRomAddress
//
// Description: Update AMAC String on address EBDA_MAC_ADDRESS_BUFFER.
//              OPROM will use this buffer. 
//
// Input:
//
//
// Output:
//
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
VOID
EFIAPI
SetOpRomAddress(UINT8 *AuxMac)
{
    UINT8    *OPRomMac;
    UINT8    i;
    CHAR8    buffer[2];
    
    OPRomMac=(UINT8 *)EBDA_MAC_ADDRESS_BUFFER;
    
    for(i=0;i<6;i++)
    {
        Sprintf(buffer, "%c%c", AuxMac[2*i],AuxMac[2*i+1]);
        OPRomMac[i]=(UINT8)Strtol(buffer,NULL,16); 
    }

}
*/
//<PROJECT_CHANGE>- 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level <<<
//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   UpdateAMACAslObject
//
// Description: Update AMAC String on post time.
//
//
// Input:
//
//
// Output:
//
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
EFI_STATUS
EFIAPI
UpdateAMACAslObject()
{
    EFI_STATUS                      Status;
    ASL_OBJ_INFO                    ObjInfo;
    DELL_AUX_MAC_ADDRESS            pMacAddr;
    UINTN                           Size;
    AUX_MAC_STRING                  *Aux;
    EFI_PHYSICAL_ADDRESS            DsdtAddr;
    EFI_ACPI_DESCRIPTION_HEADER     *DsdtTable = NULL;


    Size = sizeof(DELL_AUX_MAC_ADDRESS);
    Status = PropertyProtocol->GetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             &Size,
                                             &pMacAddr);

    if(!EFI_ERROR(Status))
    {
        //If found AUXMAC ,updated to DSDT table.
        LibGetDsdt(&DsdtAddr, EFI_ACPI_TABLE_VERSION_ALL);
        DsdtTable = (EFI_ACPI_DESCRIPTION_HEADER*)(UINTN)DsdtAddr;

        Status = GetAslObj(	(UINT8*)((UINTN)DsdtTable + sizeof(EFI_ACPI_DESCRIPTION_HEADER)),
                             DsdtTable->Length - sizeof(EFI_ACPI_DESCRIPTION_HEADER),
                            "AMAC",
                            otName,
                            &ObjInfo);
        if (EFI_ERROR (Status)) {
            return Status;
        }

        Aux = (AUX_MAC_STRING*)((UINT8*)ObjInfo.DataStart+4);

        //Write string formatted as "_AUXMAC_#0123456789AB#"
        MemCpy(Aux->NameString,"_AUXMAC_#", sizeof("_AUXMAC_#"));
        MemCpy(Aux->AuxMac,pMacAddr.AuxMacAddress,sizeof(pMacAddr.AuxMacAddress));
        Aux->EndChar[0]='#';
        Aux->EndChar[1]=0;

        DsdtTable->Checksum = 0;
        DsdtTable->Checksum=ChsumTbl((UINT8*)DsdtTable,DsdtTable->Length);
//        SetOpRomAddress(Aux->AuxMac);  //<PROJECT_CHANGE>- 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level
    }

    return Status;
}
//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   DellAuxMacEntry
//
// Description:
//
//
// Input:
//
//
// Output:
//
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
EFI_STATUS
EFIAPI
DellAuxMacEntry (
    IN  EFI_HANDLE          ImageHandle,
    IN  EFI_SYSTEM_TABLE    *SystemTable)
{
    EFI_STATUS                  Status = EFI_SUCCESS;
    EFI_SMM_BASE2_PROTOCOL      *pSmm = NULL;
    EFI_HANDLE                  Handle = NULL;  //<PROJECT_CHANGE>+ 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level

//<set-test> +>
/*	EFI_SMM_SW_DISPATCH2_PROTOCOL	*SwDispatch;
    EFI_SMM_SW_REGISTER_CONTEXT		SwContext={0x77};
    EFI_HANDLE						Handle;*/
//<set-test> +<
    InitAmiSmmLib (ImageHandle, SystemTable);
//<set-test> +>
/*  Status = pSmst->SmmLocateProtocol (
			&gEfiSmmSwDispatch2ProtocolGuid,
			NULL,
			&SwDispatch
			);
	if (EFI_ERROR (Status)) {
		return Status;
	}
	Status = SwDispatch->Register (
			SwDispatch,
			SetTest,
			&SwContext,
			&Handle
			);
	if (EFI_ERROR (Status)) {
		return Status;
	}*/
//<set-test> +<
    DEBUG_DELL (DBG_SMM_LOM_SMB, ("DellAuxMacEntry()\n"));

    Status = pBS->LocateProtocol (&gEfiSmmBase2ProtocolGuid, NULL, &pSmm);
    ASSERT_EFI_ERROR (Status);

    pSmm->GetSmstLocation (pSmm, &gSmst2);

    ASSERT (gSmst2 != NULL);

    Status = gSmst2->SmmLocateProtocol (&gEfiSmbSmmDaCiProtocolGuid, NULL, (void**)&DaciProtocol);
    ASSERT_EFI_ERROR (Status);
    if (EFI_ERROR (Status))
        return Status;

    Status = gSmst2->SmmLocateProtocol (&gDellPropertySmmProtocolGuid, NULL, (void**)&PropertyProtocol);
    ASSERT_EFI_ERROR (Status);
    if (EFI_ERROR (Status))
        return Status;

    UpdateAMACAslObject();
	// Register the handler with SMBIOS DA CI dispatcher Class 11, Selector 6 and 7
    Status = DaciProtocol->RegisterDaCommand (SMB_DACI_CLASS11, SMB_DACI_SELECT6, SMB_DACI_SELECT6, GetAUXMAC);
    Status = DaciProtocol->RegisterDaCommand (SMB_DACI_CLASS11, SMB_DACI_SELECT7, SMB_DACI_SELECT7, SetAUXMAC);

//<PROJECT_CHANGE>+ 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level >>>
    Handle = NULL;
    Status = pBS->InstallProtocolInterface(&Handle,
                                           &gAuxMacGuid,
                                           EFI_NATIVE_INTERFACE,
                                           NULL);
    ASSERT_EFI_ERROR(Status);
//<PROJECT_CHANGE>+ 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level <<<
    
    return Status;
}
