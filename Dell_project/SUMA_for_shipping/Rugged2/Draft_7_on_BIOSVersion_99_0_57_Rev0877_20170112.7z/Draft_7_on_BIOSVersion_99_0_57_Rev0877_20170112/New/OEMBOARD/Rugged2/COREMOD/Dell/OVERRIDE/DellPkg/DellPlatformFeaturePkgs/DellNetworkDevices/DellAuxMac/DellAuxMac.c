//*************************************************************************
//*************************************************************************
//**                                                                     **
//**        (C)Copyright 1985-2016, American Megatrends, Inc.            **
//**                                                                     **
//**                       All Rights Reserved.                          **
//**                                                                     **
//**      5555 Oakbrook Parkway, Suite 200, Norcross, GA 30093           **
//**                                                                     **
//**                       Phone: (770)-246-8600                         **
//**                                                                     **
//*************************************************************************
//*************************************************************************

//*************************************************************************
// $Header:
//
// $Revision:
//
// $Date:
//*************************************************************************
// Revision History
// ----------------
// $Log:
//
//*************************************************************************
//<AMI_FHDR_START>
//
// Name:        DellAuxMac.c
//
// Description:
//
//<AMI_FHDR_END>
//*************************************************************************

#include "AmiDxeLib.h"
#include "DellCommonLib.h"
#include "Protocol\DellProperty.h"
#include "Protocol\DellMfgMode.h"

#include "DellAuxMac.h"
#include "Protocol\SmmBase2.h"
//#include <Protocol\SmmSwDispatch2.h>//<set-test>
//#include <Protocol\SmmSwDispatch.h>//<set-test>

#include <Guid/DellPersistentPropertyIds.h>
#include <Library/BaseLib.h>
#include <AcpiRes.h>
#include <Library/DellSmmRange.h>
#include <Library/DebugLib.h>
#if DellMAPT20_SUPPORT
#include <Guid/DellPropertyIds.h>
#include <SetupPrep.h>
#endif
#if DellSUMAForShippingMachine_SUPPORT
#include <Library/BaseMemoryLib.h>
#include <Library/BaseCryptLib.h>
#include <Guid/DellPropertyIds.h>
#include <RuggedSpecialSUMATable.h>
#endif

#define CAST_TO_VOIDPTR(u)      ((VOID*)((UINTN)u))

EFI_GUID gAuxMacGuid = AUX_MAC_GUID;  //<PROJECT_CHANGE>+ 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level
extern EFI_GUID  gEfiAcpi20TableGuid;
extern EFI_GUID  gEfiAcpi10TableGuid;

EFI_SMB_SMM_DACI_PROTOCOL_VER2   	*DaciProtocol = NULL;
DELL_PROPERTY_PROTOCOL  		*PropertyProtocol = NULL;
EFI_SMM_SYSTEM_TABLE2           *gSmst2 = NULL;

#if DellMAPT20_SUPPORT
VOID
EFIAPI
SaveMacAddressToPid (
	VOID
  	);
#endif

#if DellSUMAForShippingMachine_SUPPORT
VOID
EFIAPI
DealWithRuggedSpecialRequest (
	VOID
    );

VOID
EFIAPI
ShowBufferOriginalTextAndBytes(
	IN UINT8		*Buffer,
	IN UINTN    	BufferSize
    );

EFI_STATUS
EFIAPI
HashContext(
	IN UINT8		*Buffer,
	IN UINTN		BufferSize,
	IN OUT UINT8	*HashValue
    );

VOID
EFIAPI
ShowOneServiceTagDigestValue(
	IN DELL_SERVICETAG_DIGEST	*Buffer
    );

VOID
EFIAPI
ClearPidAuxMAndPidSumaS(
    VOID
    );

#endif

//<set-test> +>
/*EFI_STATUS
SetTest (
	EFI_HANDLE			ImageHandle,
	EFI_SMM_SW_DISPATCH_CONTEXT *DispatchContext,
    VOID         *CommBuffer,
    UINTN        *CommBufferSize)
{
    EFI_STATUS                  Status = EFI_SUCCESS;
    DELL_AUX_MAC_ADDRESS 			*pMacAddr;
    UINT8 buffer[17]={13,0,0,0,'a','b','c','d','e','f','g','h','i','j','k','l',0};

    DEBUG_DELL (DBG_SMM_LOM_SMB, ("gAux=%x\n",gAux));
    pMacAddr=((DELL_AUX_MAC_ADDRESS *)((UINT64)(&buffer)));
    Status = PropertyProtocol->SetProperty ( PropertyProtocol,
                                             PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             sizeof(DELL_AUX_MAC_ADDRESS),
                                             pMacAddr);
    memcpy(gAux->NameString,"_AUXMAC_#", sizeof("_AUXMAC_#"));
    memcpy(gAux->AuxMac,pMacAddr->AuxMacAddress,sizeof(pMacAddr->AuxMacAddress));
    gAux->EndChar[0]='#';
    gAux->EndChar[1]=0;

    DsdtTable->Checksum = 0;
    DsdtTable->Checksum=ChsumTbl((UINT8*)DsdtTable,DsdtTable->Length);

	return EFI_SUCCESS;
}*/
//<set-test> +<

//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   GetAUXMAC
//
// Description: Class 11 selector 6
//
//
// Input:cbArg1  Address of output buffer as example.
//   buffer[] = {13,0,0,0,'D','S','C','I','D','S','C','I','D','S','C','I',x}
//
// Output:cbRes1 	0	success
//					-1	error
//					-5	did not have the proper format
//					-6	Size is not enough
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
VOID
EFIAPI
GetAUXMAC(
    IN OUT SMBIOS_DACI_COMMAND_BUFFER   *CommandBuffer
)
{
    EFI_STATUS                   Status;
    DELL_AUX_MAC_ADDRESS         pMacAddr;
    UINTN                        Size;
    UINT8                        *pData = NULL;
    UINT32                       Length = 0; 
    UINT32                       BufSize;

    /*
      only use this for writing the length field back to smbios buffers
      if you read from this by dereferencing, you subject yourself to 
      double fetch issues
    */
    UINT32 *pOutLength = NULL;

    /*
      Patching CheckInputBuffer call to use the new calling convention to avoid race conditions
      See CheckInputBuffer_s for further information
    */
    if(BufferTouchesSmram(CAST_TO_VOIDPTR(CommandBuffer->cbArg1), sizeof(UINT32)))
    {
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER;
        DEBUG_DELL (DBG_SMM_LOM_SMB, ("CommandBuffer->cbArg1 touches SMRAM. Asserting due to security violation.\n"));
        ASSERT(FALSE);
        return;
    }

    Length = *(UINT32 *)(CAST_TO_VOIDPTR(CommandBuffer->cbArg1));
    pOutLength = (UINT32 *)(CAST_TO_VOIDPTR(CommandBuffer->cbArg1));

    //Check input buffer format
    if (DaciProtocol->CheckInputBuffer_s((VOID*)(UINTN)(CommandBuffer->cbArg1), Length, &pData) == FALSE)
    {
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER;
        return;
    }
    Size = sizeof(DELL_AUX_MAC_ADDRESS);
    Status = PropertyProtocol->GetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             &Size,
                                             &pMacAddr);
    //If AUX MAX has not been set, return -1
    if (EFI_ERROR(Status))
    {
        CommandBuffer->cbRes1 = SMBIOS_ERROR;
        return;
    }

    BufSize=Length;

    //Check input buffer size
    if (BufSize < pMacAddr.DataSize)
    {
        *pOutLength = pMacAddr.DataSize;
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER_SIZE;
        return;
    }

    MemCpy(pData,pMacAddr.AuxMacAddress, pMacAddr.DataSize);
    CommandBuffer->cbRes1 = SMBIOS_SUCCESS;
}
//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   SetAUXMAC
//
// Description: Class 11 selector 7
//
//
// Input:cbArg1  Address of input buffer as example.
//   buffer[] = {13,0,0,0,'1','2','3','4','5','6','7','8','9','A','B','C',0}
//
//
// Output: cbRes1 	0	success
// 				 	-1	error
//				 	-5	did not have the proper format
//
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
VOID
EFIAPI
SetAUXMAC(
    IN OUT SMBIOS_DACI_COMMAND_BUFFER   *CommandBuffer
    )
{
    EFI_STATUS                  Status;
    DELL_AUX_MAC_ADDRESS        *pMacAddr;
    UINT8                       MacChar;
    UINT8                       i;
    DELL_MFG_MODE_PROTOCOL      *MfgModeProtocol;
    ACTIVE_MFG_MODES            ActiveMfgModes = 0;
#if DellSUMAForShippingMachine_SUPPORT
	UINT8                       ServiceTag[MAX_TAG_STRING_SIZE];
#endif

    // Check if manufacturing mode is on
    Status = gSmst2->SmmLocateProtocol ( &gDellSmmMfgModeProtocolGuid,
                                         NULL,
                                         &MfgModeProtocol);
    if (EFI_ERROR (Status))
        return ;

    MfgModeProtocol->GetMfgMode(&ActiveMfgModes,
                                MFG_MODE_CLASSIC,
                                MFG_MODE_SERVICE_MENU,
                                MFG_MODE_DELL_FACTORY,
                                MFG_MODE_SYSTEM_SERVICE,
                                MFG_MODE_OPEN_SECURITY,
                                MFG_MODE_FACTORY_UTILITIES,
                                MFG_MODE_ENGINEERING,
                                MFG_MODE_PCBA_FLAG,
                                MFG_MODE_NULL);
    if(!ActiveMfgModes)
    {
        CommandBuffer->cbRes1 = SMBIOS_ERROR;
        return ;
    }

    //Check ASCII hex characters in [0-9,A-F,a-f]
    pMacAddr=((DELL_AUX_MAC_ADDRESS *)((UINT64)(CommandBuffer->cbArg1)));
    for(i=0;i<(pMacAddr->DataSize-1);i++)
    {
        MacChar = pMacAddr->AuxMacAddress[i];
        if( !(  ((MacChar >= '0') && (MacChar <= '9')) ||
                ((MacChar >= 'A') && (MacChar <= 'F')) ||
                ((MacChar >= 'a') && (MacChar <= 'f')) ) )
        {
            CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER;
            return;
        }
    }
    //Check end char
    if(pMacAddr->AuxMacAddress[i]!=0)
    {
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER;
        return;
    }
    //Check size
    if(pMacAddr->DataSize!=AUX_MAC_SIZE)
    {
        CommandBuffer->cbRes1 = SMBIOS_INVALID_BUFFER_SIZE;
        return;
    }
    Status = PropertyProtocol->SetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             sizeof(DELL_AUX_MAC_ADDRESS),
                                             pMacAddr);
    if (EFI_ERROR(Status))
    {
        CommandBuffer->cbRes1 = SMBIOS_ERROR;
        return;
    }
#if DellSUMAForShippingMachine_SUPPORT	
    Status = PropertyProtocol->SetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_SUMA_FOR_SHIPPING_SERVICE_TAG,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             0,
                                             ServiceTag);										
    DEBUG_DELL (DBG_SMM_LOM_SMB, ("Clear PERSISTENT_PID_SUMA_FOR_SHIPPING_SERVICE_TAG %r \n", Status));
#endif										
    CommandBuffer->cbRes1 = SMBIOS_SUCCESS;

}
//<PROJECT_CHANGE>- 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level >>>
/*
//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   SetOpRomAddress
//
// Description: Update AMAC String on address EBDA_MAC_ADDRESS_BUFFER.
//              OPROM will use this buffer. 
//
// Input:
//
//
// Output:
//
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
VOID
EFIAPI
SetOpRomAddress(UINT8 *AuxMac)
{
    UINT8    *OPRomMac;
    UINT8    i;
    CHAR8    buffer[2];
    
    OPRomMac=(UINT8 *)EBDA_MAC_ADDRESS_BUFFER;
    
    for(i=0;i<6;i++)
    {
        Sprintf(buffer, "%c%c", AuxMac[2*i],AuxMac[2*i+1]);
        OPRomMac[i]=(UINT8)Strtol(buffer,NULL,16); 
    }

}
*/
//<PROJECT_CHANGE>- 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level <<<
//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   UpdateAMACAslObject
//
// Description: Update AMAC String on post time.
//
//
// Input:
//
//
// Output:
//
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
EFI_STATUS
EFIAPI
UpdateAMACAslObject()
{
    EFI_STATUS                      Status;
    ASL_OBJ_INFO                    ObjInfo;
    DELL_AUX_MAC_ADDRESS            pMacAddr;
    UINTN                           Size;
    AUX_MAC_STRING                  *Aux;
    EFI_PHYSICAL_ADDRESS            DsdtAddr;
    EFI_ACPI_DESCRIPTION_HEADER     *DsdtTable = NULL;
#if DellMAPT20_SUPPORT
    UINT8                           MaptValue;
#endif


#if DellMAPT20_SUPPORT
	Size = sizeof(UINT8);
    Status = PropertyProtocol->GetProperty ( PropertyProtocol,
										     PID_MAC_ADDRESS_PASS_THROUGH,
                                             &gDellPropertyNamespaceGuid,
                                             &Size,
                                             &MaptValue);
    Size = sizeof(DELL_AUX_MAC_ADDRESS);
    if (!EFI_ERROR(Status)&&(MaptValue == 2)) {
        DEBUG_DELL (DBG_SMM_LOM_SMB, ("Dell MAPT2.0: disabled. \n"));
        return Status;
    } else if (!EFI_ERROR(Status)&&(MaptValue == 0)) {
        Status = PropertyProtocol->GetProperty ( PropertyProtocol,
                                                 PERSISTENT_PID_AUX_MAC,
                                                 &gDellPersistentPropertyNamespaceGuid,
                                                 &Size,
                                                 &pMacAddr);
		DEBUG_DELL (DBG_SMM_LOM_SMB, ("Dell MAPT2.0: use system unique mac address Status = %r. \n", Status));										         
    } else if (!EFI_ERROR(Status)&&(MaptValue == 1)) {
        Status = PropertyProtocol->GetProperty ( PropertyProtocol,
        		                                 PID_NIC1_MAC_STRING,
                                                 &gDellPropertyNamespaceGuid,
                                                 &Size,
                                                 &pMacAddr);
		DEBUG_DELL (DBG_SMM_LOM_SMB, ("Dell MAPT2.0: use Nic1 mac address Status = %r. \n", Status));										 
    }
#else
    Size = sizeof(DELL_AUX_MAC_ADDRESS);
    Status = PropertyProtocol->GetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             &Size,
                                             &pMacAddr);
#endif

    if(!EFI_ERROR(Status))
    {
        //If found AUXMAC ,updated to DSDT table.
        LibGetDsdt(&DsdtAddr, EFI_ACPI_TABLE_VERSION_ALL);
        DsdtTable = (EFI_ACPI_DESCRIPTION_HEADER*)(UINTN)DsdtAddr;

        Status = GetAslObj(	(UINT8*)((UINTN)DsdtTable + sizeof(EFI_ACPI_DESCRIPTION_HEADER)),
                             DsdtTable->Length - sizeof(EFI_ACPI_DESCRIPTION_HEADER),
                            "AMAC",
                            otName,
                            &ObjInfo);
        if (EFI_ERROR (Status)) {
            return Status;
        }

        Aux = (AUX_MAC_STRING*)((UINT8*)ObjInfo.DataStart+4);

        //Write string formatted as "_AUXMAC_#0123456789AB#"
        MemCpy(Aux->NameString,"_AUXMAC_#", sizeof("_AUXMAC_#"));
        MemCpy(Aux->AuxMac,pMacAddr.AuxMacAddress,sizeof(pMacAddr.AuxMacAddress));
        Aux->EndChar[0]='#';
        Aux->EndChar[1]=0;

        DsdtTable->Checksum = 0;
        DsdtTable->Checksum=ChsumTbl((UINT8*)DsdtTable,DsdtTable->Length);
//        SetOpRomAddress(Aux->AuxMac);  //<PROJECT_CHANGE>- 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level
    }

    return Status;
}
//<AMI_PHDR_START>
//----------------------------------------------------------------------------
// Procedure:   DellAuxMacEntry
//
// Description:
//
//
// Input:
//
//
// Output:
//
//----------------------------------------------------------------------------
//<AMI_PHDR_END>
EFI_STATUS
EFIAPI
DellAuxMacEntry (
    IN  EFI_HANDLE          ImageHandle,
    IN  EFI_SYSTEM_TABLE    *SystemTable)
{
    EFI_STATUS                  Status = EFI_SUCCESS;
    EFI_SMM_BASE2_PROTOCOL      *pSmm = NULL;
    EFI_HANDLE                  Handle = NULL;  //<PROJECT_CHANGE>+ 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level

//<set-test> +>
/*	EFI_SMM_SW_DISPATCH2_PROTOCOL	*SwDispatch;
    EFI_SMM_SW_REGISTER_CONTEXT		SwContext={0x77};
    EFI_HANDLE						Handle;*/
//<set-test> +<
    InitAmiSmmLib (ImageHandle, SystemTable);
//<set-test> +>
/*  Status = pSmst->SmmLocateProtocol (
			&gEfiSmmSwDispatch2ProtocolGuid,
			NULL,
			&SwDispatch
			);
	if (EFI_ERROR (Status)) {
		return Status;
	}
	Status = SwDispatch->Register (
			SwDispatch,
			SetTest,
			&SwContext,
			&Handle
			);
	if (EFI_ERROR (Status)) {
		return Status;
	}*/
//<set-test> +<
    DEBUG_DELL (DBG_SMM_LOM_SMB, ("DellAuxMacEntry()\n"));

    Status = pBS->LocateProtocol (&gEfiSmmBase2ProtocolGuid, NULL, &pSmm);
    ASSERT_EFI_ERROR (Status);

    pSmm->GetSmstLocation (pSmm, &gSmst2);

    ASSERT (gSmst2 != NULL);

    Status = gSmst2->SmmLocateProtocol (&gEfiSmbSmmDaCiProtocolVer2Guid, NULL, (void**)&DaciProtocol);
    ASSERT_EFI_ERROR (Status);
    if (EFI_ERROR (Status))
        return Status;

    Status = gSmst2->SmmLocateProtocol (&gDellPropertySmmProtocolGuid, NULL, (void**)&PropertyProtocol);
    ASSERT_EFI_ERROR (Status);
    if (EFI_ERROR (Status))
        return Status;

#if DellMAPT20_SUPPORT
    SaveMacAddressToPid();
#endif
#if DellSUMAForShippingMachine_SUPPORT
	DealWithRuggedSpecialRequest();
#endif

    UpdateAMACAslObject();
	// Register the handler with SMBIOS DA CI dispatcher Class 11, Selector 6 and 7
    Status = DaciProtocol->RegisterDaCommand (SMB_DACI_CLASS11, SMB_DACI_SELECT6, SMB_DACI_SELECT6, GetAUXMAC);
    Status = DaciProtocol->RegisterDaCommand (SMB_DACI_CLASS11, SMB_DACI_SELECT7, SMB_DACI_SELECT7, SetAUXMAC);

//<PROJECT_CHANGE>+ 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level >>>
    Handle = NULL;
    Status = pBS->InstallProtocolInterface(&Handle,
                                           &gAuxMacGuid,
                                           EFI_NATIVE_INTERFACE,
                                           NULL);
    ASSERT_EFI_ERROR(Status);
//<PROJECT_CHANGE>+ 2016/07/11 EIP277715 PCR 2266 - Unique Pass Through MAC Address and WiFi MAC address are exposed at the OS level <<<
    
    return Status;
}

#if DellMAPT20_SUPPORT
VOID
EFIAPI
SaveMacAddressToPid (
  VOID
  )
{
    EFI_STATUS                  Status = EFI_SUCCESS;
    UINTN                       Size;
    SETUP_DATA                  SetupData;
    UINT32                      Attributes;
    DELL_AUX_MAC_ADDRESS        pMacAddr;
	
    Size = sizeof (SETUP_DATA);
    Status = pRS->GetVariable ( L"Setup", &gEfiNormalSetupGuid, &Attributes, &Size, &SetupData );
    Sprintf(pMacAddr.AuxMacAddress,"%02X%02X%02X%02X%02X%02X",SetupData.OEMMAC[0],SetupData.OEMMAC[1],SetupData.OEMMAC[2],SetupData.OEMMAC[3],SetupData.OEMMAC[4],SetupData.OEMMAC[5]);
    pMacAddr.DataSize = AUX_MAC_SIZE;
    Status = PropertyProtocol->SetProperty( PropertyProtocol,
                                            PID_NIC1_MAC_STRING,
                                            &gDellPropertyNamespaceGuid,
											sizeof(DELL_AUX_MAC_ADDRESS),
											&pMacAddr);
 	if (0) {
       Size = sizeof (DELL_AUX_MAC_ADDRESS);
       Status = PropertyProtocol->GetProperty ( PropertyProtocol,
           		                                PID_NIC1_MAC_STRING,
                                                &gDellPropertyNamespaceGuid,
                                                &Size,
                                                &pMacAddr);
       DEBUG_DELL (DBG_SMM_LOM_SMB, ("Dell MAPT2.0:NIC 1 MAC address = %a \n", pMacAddr.AuxMacAddress));
    }
	DEBUG_DELL (DBG_SMM_LOM_SMB, ("Dell MAPT2.0:Save PID_NIC1_MAC_STRING. \n"));
}
#endif
#if DellSUMAForShippingMachine_SUPPORT
VOID
EFIAPI
ShowBufferOriginalTextAndBytes(
	IN UINT8		*Buffer,
	IN UINTN		BufferSize
	)
{
	UINTN i;
	
    DEBUG_DELL (DBG_SMM_LOM_SMB, ("JointBuffer original text =%a, size =%d \n", Buffer, BufferSize));
	DEBUG_DELL (DBG_SMM_LOM_SMB, ("JointBuffer original bytes ="));
    for (i = 0 ; i < BufferSize; i++) {
        DEBUG_DELL (DBG_SMM_LOM_SMB, ("%x", Buffer[i]));
    }
    DEBUG_DELL (DBG_SMM_LOM_SMB, ("\n"));	
}

EFI_STATUS
EFIAPI
HashContext( 
	IN UINT8		*Buffer,
	IN UINTN		BufferSize,
	IN OUT UINT8	*HashValue
	) 
{
	EFI_STATUS		Status;             
	UINTN			DataSize;
	VOID           	*AlgoContext;	
	
#ifdef USE_SHA1
	DataSize = Sha1GetContextSize ();
	Status = pBS->AllocatePool (EfiReservedMemoryType, DataSize, &AlgoContext);
	ASSERT_EFI_ERROR (Status);
	if (EFI_ERROR (Status)) {
	   return Status;
	}
    Sha1Init (AlgoContext);
	Sha1Update (AlgoContext, Buffer, BufferSize );
	Sha1Final (AlgoContext, HashValue);
	pBS->FreePool (AlgoContext);			
#else
	DataSize = Md5GetContextSize ();
	Status = pBS->AllocatePool (EfiReservedMemoryType, DataSize, &AlgoContext);
	ASSERT_EFI_ERROR (Status);
	if (EFI_ERROR (Status)) {
	   return Status;
	}
    Md5Init (AlgoContext);
	Md5Update (AlgoContext, Buffer, BufferSize );
	Md5Final (AlgoContext, HashValue);
	pBS->FreePool (AlgoContext);	
#endif
	return EFI_SUCCESS;
}

VOID
EFIAPI
ShowOneServiceTagDigestValue(
	IN DELL_SERVICETAG_DIGEST    *Buffer
	)
{
	DEBUG_DELL (DBG_SMM_LOM_SMB, ("0x%x, ",  Buffer->HashValue0));
	DEBUG_DELL (DBG_SMM_LOM_SMB, ("0x%x, ",  Buffer->HashValue1));
	DEBUG_DELL (DBG_SMM_LOM_SMB, ("0x%x, ",  Buffer->HashValue2));
	DEBUG_DELL (DBG_SMM_LOM_SMB, ("0x%x, ",  Buffer->HashValue3));
#ifdef USE_SHA1
	DEBUG_DELL (DBG_SMM_LOM_SMB, ("0x%x, ",  Buffer->HashValue4));
#endif   
	DEBUG_DELL (DBG_SMM_LOM_SMB, ("\n"));
}

VOID
EFIAPI
ClearPidAuxMAndPidSumaS(
    VOID
    )
{
	EFI_STATUS                      Status;
	UINT8                           ServiceTag[MAX_TAG_STRING_SIZE];
	DELL_AUX_MAC_ADDRESS            pMacAddr;
	
    Status = PropertyProtocol->SetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             0,
	   						                 &pMacAddr);	
    Status |= PropertyProtocol->SetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_SUMA_FOR_SHIPPING_SERVICE_TAG,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             0,
                                             ServiceTag);										
    DEBUG_DELL (DBG_SMM_LOM_SMB, ("Clear PERSISTENT_PID_AUX_MAC and PERSISTENT_PID_SUMA_FOR_SHIPPING_SERVICE_TAG %r \n", Status)); 											
}	

VOID
EFIAPI
DealWithRuggedSpecialRequest (
	VOID
)
{
	EFI_STATUS                      Status;
	DELL_AUX_MAC_ADDRESS            pMacAddr;
    UINTN                           Size;
	UINT8                           CurrentServiceTag[MAX_TAG_STRING_SIZE];
	UINT8                           FormerServiceTag[MAX_TAG_STRING_SIZE];
	UINTN                           Index;
	UINTN							Retval;
	BOOLEAN							DoSearch = FALSE;
	BOOLEAN							DoHash = TRUE;
	BOOLEAN							FoundInTable = FALSE;
	UINT8                           JointBuffer[SaltValueSize+MAX_TAG_STRING_SIZE];
	UINTN                           DataInJointBufferSize;
	UINT8                       	*HashValue;
#ifdef USE_SHA1	
    UINTN                           DigestSize = SHA1_DIGEST_SIZE;
#else
	UINTN 							DigestSize = MD5_DIGEST_SIZE;
#endif

	DEBUG_DELL (DBG_SMM_LOM_SMB, ("DealWithRuggedSpecialRequest() Enter. \n"));
    Size = sizeof (DELL_AUX_MAC_ADDRESS);
    Status = PropertyProtocol->GetProperty ( PropertyProtocol,
                                             PERSISTENT_PID_AUX_MAC,
                                             &gDellPersistentPropertyNamespaceGuid,
                                             &Size,
                                             &pMacAddr);
    if (!EFI_ERROR(Status))
    {
		Size = MAX_TAG_STRING_SIZE;
        Status = PropertyProtocol->GetProperty ( PropertyProtocol,
                                                 PERSISTENT_PID_SUMA_FOR_SHIPPING_SERVICE_TAG,
                                                 &gDellPersistentPropertyNamespaceGuid,
                                                 &Size,
                                                 FormerServiceTag);
        if (!EFI_ERROR(Status)) { 
		    DEBUG_DELL (DBG_SMM_LOM_SMB, ("PERSISTENT_PID_SUMA_FOR_SHIPPING_SERVICE_TAG = %a Status = %r\n", FormerServiceTag, Status));
	        Size = MAX_TAG_STRING_SIZE; 
		    Status = PropertyProtocol->GetProperty( PropertyProtocol,
                                                    PID_SERVICE_TAG,
                                                    &gDellPropertyNamespaceGuid,
                                                    &Size,
                                                    CurrentServiceTag);
		    ASSERT_EFI_ERROR (Status);
            DEBUG_DELL (DBG_SMM_LOM_SMB, ("PID_SERVICE_TAG = %a \n", CurrentServiceTag));		  
		    if (AsciiStrCmp(CurrentServiceTag, FormerServiceTag) != 0) {
			    DoSearch = TRUE;
                ClearPidAuxMAndPidSumaS();			 
		    } 
	    } else {
		    DEBUG_DELL (DBG_SMM_LOM_SMB, ("PERSISTENT_PID_AUX_MAC wasn't implemented by SUMA for shipping. \n"));	
		}
	} else {
 	    DEBUG_DELL (DBG_SMM_LOM_SMB, ("PERSISTENT_PID_AUX_MAC don't exist \n"));
		Size = MAX_TAG_STRING_SIZE; 
		Status = PropertyProtocol->GetProperty( PropertyProtocol,
                                                PID_SERVICE_TAG,
                                                &gDellPropertyNamespaceGuid,
                                                &Size,
                                                CurrentServiceTag);
        DEBUG_DELL (DBG_SMM_LOM_SMB, ("PID_SERVICE_TAG = %a \n", CurrentServiceTag));
		if (!EFI_ERROR(Status)) {
			Size = MAX_TAG_STRING_SIZE; 
            Status = PropertyProtocol->GetProperty ( PropertyProtocol,
                                                     PID_FORMER_SERVICE_TAG,
                                                     &gDellPropertyNamespaceGuid,
                                                     &Size,
                                                     FormerServiceTag);
            if (!EFI_ERROR(Status)) {
				if (AsciiStrCmp(CurrentServiceTag, FormerServiceTag) != 0) {
			        DoSearch = TRUE;
                } 
            } else {
			    DoSearch = TRUE;	
			}	
		} else {
		    DEBUG_DELL (DBG_SMM_LOM_SMB, ("PID_SERVICE_TAG don't exist. \n")); 	
	    }					
    }

    if (DoSearch){
		DEBUG_DELL (DBG_SMM_LOM_SMB, ("Do ServiceTagDigest search \n"));  
		Status = pBS->AllocatePool (EfiReservedMemoryType, DigestSize, &HashValue);
	    ASSERT_EFI_ERROR (Status); 
			  
        for (Index = 0 ; Index < ServiceTagNum ; Index++) {
		    if (DoHash) { 
        	    ZeroMem(JointBuffer, SaltValueSize+MAX_TAG_STRING_SIZE); 
                AsciiStrCat (JointBuffer, CurrentServiceTag);
#ifdef SALTVALUE_USE_MAC_ADDRESS				  
                AsciiStrCpy(mSalt, mMac[Index].MacAddress);
#endif				  
			    AsciiStrCat (JointBuffer, mSalt);				  
                DataInJointBufferSize = AsciiStrSize (JointBuffer) - 1;        // Skip NULL string 
                Status= HashContext (JointBuffer, DataInJointBufferSize, HashValue);
#ifndef SALTVALUE_USE_MAC_ADDRESS
                DoHash = FALSE;
#endif	
		    }
// Show Original text and bytes. Digest value 
//			ShowBufferOriginalTextAndBytes (JointBuffer, DataInJointBufferSize);
//			ShowOneServiceTagDigestValue ((VOID*) HashValue);
			
  	        Retval = CompareMem(&mServiceTagDigest[Index], HashValue, DigestSize);
            if (Retval == 0) {
				DEBUG_DELL (DBG_SMM_LOM_SMB, ("Digest table Index =0x%x match \n", Index)); 
				ShowOneServiceTagDigestValue ((VOID*) &mServiceTagDigest[Index]);
					 
                AsciiStrCpy(pMacAddr.AuxMacAddress, mMac[Index].MacAddress);
				pMacAddr.DataSize = AUX_MAC_SIZE;  
				Status = PropertyProtocol->SetProperty (PropertyProtocol,
                                                        PERSISTENT_PID_AUX_MAC,
                                                        &gDellPersistentPropertyNamespaceGuid,
                                                        sizeof(DELL_AUX_MAC_ADDRESS),
                                                        &pMacAddr);												  
                DEBUG_DELL (DBG_SMM_LOM_SMB, ("Set PERSISTENT_PID_AUX_MAC = %a, Status = %r \n", pMacAddr.AuxMacAddress, Status));

                Size = MAX_TAG_STRING_SIZE;
                Status = PropertyProtocol->SetProperty ( PropertyProtocol,
                                                         PERSISTENT_PID_SUMA_FOR_SHIPPING_SERVICE_TAG,
                                                         &gDellPersistentPropertyNamespaceGuid,
                                                         Size,
                                                         CurrentServiceTag);									
				DEBUG_DELL(DBG_SMM_LOM_SMB, ("Save PERSISTENT_PID_SUMA_FOR_SHIPPING_SERVICE_TAG Status: %r\n", Status));
                FoundInTable = TRUE;
			    break;
			}
		}
		if (!FoundInTable) {
			Size = MAX_TAG_STRING_SIZE;
            Status = PropertyProtocol->SetProperty ( PropertyProtocol,
                                                     PID_FORMER_SERVICE_TAG,
                                                     &gDellPropertyNamespaceGuid,
                                                     Size,
                                                     CurrentServiceTag);									
			DEBUG_DELL(DBG_SMM_LOM_SMB, ("Save PID_FORMER_SERVICE_TAG Status: %r\n", Status));
			DEBUG_DELL(DBG_SMM_LOM_SMB, ("System don't set PERSISTENT_PID_AUX_MAC"));
		}
	}			
	
    DEBUG_DELL (DBG_SMM_LOM_SMB, ("DealWithRuggedSpecialRequest() Exit. \n"));	
}
#endif
