/**
Copyright (c) 2015 Dell Inc. All rights reserved.
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Dell Inc.

DellPersistentPropertyIds.h

*/

#ifndef _DELL_PERSISTENT_PROPERTY_IDS_H_
#define _DELL_PERSISTENT_PROPERTY_IDS_H_

/** @file
This file enumerates all Dell-specific persistent property identifiers (and values).

The data type for the Property Id (PID) is UINT32; however, for the time
being, use only the lower 16 bits, due to limitations in VFR and SMBIOS.  Of
these 16 bits, the upper 4 bits have special meaning.  So, "name" your
properties in the lower 12 bits, and reserve the upper 4 bits for Property
Type information.  Consult PropertyTypes.h for more information.

Note: To map a property to a CMOS location, you must include CMOS mapping
information in the relevant platform-specific CmosMap.h include file.
*/

// 
// Persistent Property Namespace. Any property defined in this namespace will survive a
// service reset.
// 
// ***Caution: It will be very difficult to remove/replace a write-once variable defined in
// the persistent namespace. Only hardware methods (e.g. Dediprog) or SAFE-authorized FPT
// programming (or other methods that can perform a full SPI wipe) will be able to remove a
// write-once property defined in the persistent namespace.
// 
// ***IMPORTANT - READ THIS: Until we have expanded the persistent property interface to add
// support for some special mechanism that will allow deleting write-once persistent
// properties, DO NOT create any properties in this namespace as write-once!
//
// TODO: Design secure mechanism to allow for deletion of write-once properties defined in the
// persistent namespace.
// 
extern EFI_GUID gDellPersistentPropertyNamespaceGuid;   // {E4F8D2D5-6F1D-4E5C-8085-5A4C21F4CDC4}

#include <Numbers.h>
#include <PropertyTypes.h>

/*
********************************************************************************************
********************************************************************************************
** PLATFORM BUILDS MUST NOT MODIFY THIS FILE.  PLATFORM BUILDS MUST NOT MODIFY THIS FILE. **
**                                                                                        **
** These definitions must maintain uniqueness.                                            **
**                                                                                        **
** Dell Provided Features and Independent BIOS Vendor and Independent Hardware Vendor     **
**  must all make use of this file to build against, and the golden master will be        **
**  maintained by Dell because the Dell Property ID is subject to Dell governance.        **
**                                                                                        **
** Please submit any required changes back to Dell Provided Features for inclusion, which **
**  will permit "locking" the file. The intention of this requriement is not to impede    **
**  access but to guarantee that no two properties collide.                               **
********************************************************************************************
********************************************************************************************
*/

// PID 0x000 is not used
#define PERSISTENT_PID_UNDEFINED                0x0000
#define PERSISTENT_PID_AUX_MAC                  0x0001      // Auxiliary MAC Address
#define PERSISTENT_PID_SUMA_FOR_SHIPPING_SERVICE_TAG    0x0002      
///////////////////////////////////////////////////////////
//PID 0x0002 TO 0x0FFF Available for future use
///////////////////////////////////////////////////////////

/*
********************************************************************************************
********************************************************************************************
** PLATFORM BUILDS MUST NOT MODIFY THIS FILE.  PLATFORM BUILDS MUST NOT MODIFY THIS FILE. **
**                                                                                        **
** These definitions must maintain uniqueness.                                            **
**                                                                                        **
** Dell Provided Features and Independent BIOS Vendor and Independent Hardware Vendor     **
**  must all make use of this file to build against, and the golden master will be        **
**  maintained by Dell because the Dell Property ID is subject to Dell governance.        **
**                                                                                        **
** Please submit any required changes back to Dell Provided Features for inclusion, which **
**  will permit "locking" the file. The intention of this requriement is not to impede    **
**  access but to guarantee that no two properties collide.                               **
********************************************************************************************
********************************************************************************************
*/

#endif // _DELL_PERSISTENT_PROPERTY_IDS_H_
