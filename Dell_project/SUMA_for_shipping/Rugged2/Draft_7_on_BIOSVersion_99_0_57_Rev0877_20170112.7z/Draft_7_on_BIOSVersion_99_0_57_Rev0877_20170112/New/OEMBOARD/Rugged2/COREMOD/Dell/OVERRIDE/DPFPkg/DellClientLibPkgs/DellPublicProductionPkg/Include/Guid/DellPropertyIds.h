/**
Copyright (c) 2008 - 2016 Dell Inc. All rights reserved.
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Dell Inc.

DellPropertyIds.h

*/

#ifndef _DELL_PROPERTY_IDS_H_
#define _DELL_PROPERTY_IDS_H_

/** @file
This file enumerates all Dell-specific property identifiers (and values).

The data type for the Property Id (PID) is UINT32; however, for the time
being, use only the lower 16 bits, due to limitations in VFR and SMBIOS.  Of
these 16 bits, the upper 4 bits have special meaning.  So, "name" your
properties in the lower 12 bits, and reserve the upper 4 bits for Property
Type information.  Consult PropertyTypes.h for more information.

Note: To map a property to a CMOS location, you must include CMOS mapping
information in the relevant platform-specific CmosMap.h include file.
*/

// {417ACEE0-6FA9-4a82-99D7-F9B1DD271E48}
#define DELL_PROPERTY_NAMESPACE_GUID \
    { 0x417acee0, 0x6fa9, 0x4a82, 0x99, 0xd7, 0xf9, 0xb1, 0xdd, 0x27, 0x1e, 0x48 }

#ifndef PROPERTY_IDS_ONLY
extern EFI_GUID gDellPropertyNamespaceGuid; // {417ACEE0-6FA9-4a82-99D7-F9B1DD271E48}
#endif

#include <Numbers.h>
#include <PropertyTypes.h>

/*
********************************************************************************************
********************************************************************************************
** PLATFORM BUILDS MUST NOT MODIFY THIS FILE.  PLATFORM BUILDS MUST NOT MODIFY THIS FILE. **
**                                                                                        **
** These definitions must maintain uniqueness.                                            **
**                                                                                        **
** Dell Provided Features and Independent BIOS Vendor and Independent Hardware Vendor    **
**  must all make use of this file to build against, and the golden master will be        **
**  maintained by Dell because the Dell Property ID is subject to Dell governance.        **
**                                                                                        **
** Please submit any required changes back to Dell Provided Features for inclusion, which **
**  will permit "locking" the file. The intention of this requriement is not to impede    **
**  access but to guarantee that no two properties collide.                               **
********************************************************************************************
********************************************************************************************
*/

/*
Note: if no VALUE is defined for a PID, then use VALUE_DIS and VALUE_EN.
*/
#define VALUE_DIS   0
#define VALUE_EN    1
#define VALUE_OFF   2
#define VALUE_ON    3
#define VALUE_AUTO  3

/*
********************************************************************************************
********************************************************************************************
** PLATFORM BUILDS MUST NOT MODIFY THIS FILE.  PLATFORM BUILDS MUST NOT MODIFY THIS FILE. **
**                                                                                        **
** These definitions must maintain uniqueness.                                            **
**                                                                                        **
** Dell Provided Features and Independent BIOS Vendor and Independent Hardware Vendor    **
**  must all make use of this file to build against, and the golden master will be        **
**  maintained by Dell because the Dell Property ID is subject to Dell governance.        **
**                                                                                        **
** Please submit any required changes back to Dell Provided Features for inclusion, which **
**  will permit "locking" the file. The intention of this requriement is not to impede    **
**  access but to guarantee that no two properties collide.                               **
********************************************************************************************
********************************************************************************************
*/

// PID 0x000 is not used
#define PID_UNDEFINED                           0x0000

// PID 0x001 Reserved for TEST
#define PID_TEST                                (0x0001)
#define PID_TEST_WO                             (0x0001 | PT_WRITE_ONCE)
#define PID_TEST_VOLATILE                       (0x0001 | PT_VOLATILE)
#define PID_TEST_BS_VOLATILE                    (0x0001 | PT_BOOT_SERVICE | PT_VOLATILE)
#define PID_TEST_BS_VOLATILE_BOOLEAN            (0x0001 | PT_BOOT_SERVICE | PT_VOLATILE | PT_BOOLEAN)
#define PID_TEST_NV_BOOLEAN                     (0x0001 | PT_BOOLEAN)

/*
Some of the following property identifiers map to CMOS locations.  Make sure
you update the CMOS property map with any properties that you require mapped
to CMOS locations.
*/
#define PID_CMOS_CHECK                          0x0002      // CMOS Check
    #define VALUE_CMOS_CHECK_RESETTING              0x5A    // CMOS check value resetting
    #define VALUE_CMOS_CHECK_BOOT_WITH_DEFAULTS     0x55    // CMOS check value causes boot with defaults
    #define VALUE_CMOS_CHECK_GOOD                   0xA5    // CMOS check value good
#define PID_CMOS_DIAG_STATUS                    0x000E      // CMOS diagnostic status
//----
#define PID_CMOS_FLOPPY_TYPE                    0x0010      // CMOS floppy type
#define PID_CMOS_HD_TYPE                        0x0012      // CMOS hard disk type
#define PID_CMOS_BASE_MEM_LOW                   0x0015      // CMOS Base Memory in k (low byte)
#define PID_CMOS_BASE_MEM_HIGH                  0x0016      // CMOS Base Memory in k (high byte)
    #define VALUE_BASE_MEM                          0x280   // 640k (low and high bytes)
#define PID_CMOS_EXT_MEM_LOW                    0x0017      // CMOS Extended Memory in k (low byte)
#define PID_CMOS_EXT_MEM_HIGH                   0x0018      // CMOS Extended Memory in k (high byte)
#define PID_CMOS_HD0_TYPE_EX                    0x0019      // CMOS hard drive 1, primary controller
#define PID_CMOS_HD1_TYPE_EX                    0x001A      // CMOS hard drive 2, primary controller
#define PID_CMOS_HD2_TYPE_EX                    0x001B      // CMOS hard drive 1, secondary controller
#define PID_CMOS_HD3_TYPE_EX                    0x001C      // CMOS hard drive 2, secondary controller
//----
#define PID_CMOS_EXT_MEM_TESTED_LOW             0x0030      // CMOS Tested Memory in k (low byte)
#define PID_CMOS_EXT_MEM_TESTED_HIGH            0x0031      // CMOS Tested Memory in k (high byte)
#define PID_CMOS_SBF                            0x0032      // CMOS Simple boot flag SBF_CMOS_ADDR
// PID_USE_FAST_BOOT is a flag that DXE driver use to expedite the booting process by skipping memory test.
// This property can be set if PID_FAST_BOOT is set with BOOT_MIN or BOOT_AUTO and Simple Boot Flag diag bit is set to zero.
#define PID_CMOS_USE_FAST_BOOT                  0x0033
#define PID_CMOS_SCRUB_MEMORY                   0x0034

//----

// ONETIME_FLAGS are pulled up from the EC in early POST. The bits are defined in PmCmdNb.h
#define PID_KB_ONETIME_FLAGS                    0x0040
    #define     KBO_FLASH_RECOVERY                  0x01
    #define     KBO_S3_RESUME                       0x02
    #define     KB_DCI_VIDEO_SUPPORT                0x04
    #define     KBO_EC_RECOVERY                     0x08
    #define     KBO_DISCRETE_GFX                    0x10
    #define     KBO_DEBUG_ENABLE                    0x20
    #define     KBO_SOL_ACTIVE                      0x40
    #define     KBO_UMA_GFX                         0x80

// BOOTFLAGS pulled up from the EC in early POST
#define PID_QUICKBOOT_ENABLED                  (0x0041 | PT_VOLATILE | PT_BOOLEAN)
#define PID_EDIAGS_ENABLED                     (0x0042 | PT_VOLATILE | PT_BOOLEAN)
#define PID_SPLASH_ENABLED                     (0x0043 | PT_VOLATILE | PT_BOOLEAN)
#define PID_BLACKTOP_BOOTFLAG                  (0x0044 | PT_VOLATILE | PT_BOOLEAN)
#define PID_RTC_POWER_ON                       (0x0045 | PT_VOLATILE | PT_BOOLEAN)
#define PID_BIOS_FLASHED                       (0x0046 | PT_VOLATILE | PT_BOOLEAN)
#define PID_WAKE_FROM_LOM                      (0x0047 | PT_VOLATILE | PT_BOOLEAN)
//----
#define PID_ALS_ENABLE                          0x0077
#define PID_RBU_ENABLE                          0x0078
#define PID_BRIGHTNESS_AC                       0x0079
#define PID_THERMAL_TRIP_FLAG                   0x007b
    #define CMOS_THERMAL_TRIP_INDEX                 PID_THERMAL_TRIP_FLAG   // BIT0 = a thermal trip caused the previous shutdown
    #define CMOS_THERMAL_TRIP_MASK                  (BIT0)                  // BitField for thermal trip
//----
#define PID_TOTAL_EXTENDED_MEMORY              (0x0117 | PT_VOLATILE)  // Total Extended Memory (DWORD)
//----
#define PID_BRIGHTNESS_BATT                     0x0179
#define PID_LAST_POWER_OFF                      0x017b // CMOS Location 0x7B Bits2:1
    #define ABNORMAL_POWER_OFF                      0
    #define NORMAL_POWER_OFF                        1
//----
#define PID_PREVIOUS_FAN_FAILURE                0x027b
    #define PREVIOUS_FAN_FAILURE_HAPPENED           1
//----
#define PID_PREVIOUS_THERM_FAILURE              0x037b
    #define PREVIOUS_THERM_FAILURE_HAPPENED         1


//----


#define PID_ACPI                                0x0400
#define PID_IDE                                 0x0401
    #define VALUE_IDE_AUTO                          0
    #define VALUE_IDE_OFF                           1
#define PID_SERIAL_PORT1                        0x0402
    #define VALUE_SER1_DIS                          0   // Serial port 1 disable
    #define VALUE_SER1_AUTO                         1   // Serial port 1 auto-config
    #define VALUE_SER1_COM1                         2   // Serial port 1 as COM1
    #define VALUE_SER1_COM2                         3   // Serial port 1 as COM2
    #define VALUE_SER1_COM3                         4   // Serial port 1 as COM3
    #define VALUE_SER1_COM4                         5   // Serial port 1 as COM4
#define PID_SERIAL_PORT2                        0x0403
    #define VALUE_SER2_DIS                          0   // Serial port 2 disable
    #define VALUE_SER2_AUTO                         1   // Serial port 2 auto-config
    #define VALUE_SER2_COM2                         2   // Serial port 2 as COM2
    #define VALUE_SER2_COM4                         3   // Serial port 2 as COM4
#define PID_LPT                                 0x0404
    #define VALUE_LPT_DIS                           0   // Parallel port disable
    #define VALUE_LPT_LPT1                          1   // Parallel port io 378
    #define VALUE_LPT_LPT2                          2   // Parallel port io 278
    #define VALUE_LPT_LPT3                          3   // Parallel port io 3BC
                                                        // LPT mode is defined below
#define PID_SER2                                0x0405
    #define VALUE_SER2_DIS                          0   // Serial port 2 disable
    #define VALUE_SER2_AUTO                         1   // Serial port 2 auto-config
    #define VALUE_SER2_COM2                         2   // Serial port 2 as COM2
    #define VALUE_SER2_COM4                         3   // Serial port 2 as COM4
#define PID_FLOP                                0x0406
    #define VALUE_FLOP_DIS                          0   // Diskette disable
    #define VALUE_FLOP_AUTO                         1   // Diskette auto-configuration
    #define VALUE_FLOP_READONLY                     2   // Diskette write protect
#define PID_BUILT_IN_POINT_DEV                  0x0407
#define PID_SPEAKER                             0x0408
    #define VALUE_SPEAKER_DIS                       0   // Speaker disable
    #define VALUE_SPEAKER_LOW                       1   // Speaker low volume
    #define VALUE_SPEAKER_MED                       2   // Speaker medium volume
    #define VALUE_SPEAKER_HI                        3   // Speaker igh volume
#define PID_SOUND                               0x0409
#define PID_PCISLOT_ENABLE                      0x040A
#define PID_MAXIMUM_PCI_BUS                     0x040B          // Maximum Pci Bus number
    #define VALUE_MAXIMUM_PCI_BUS_64                0x00        // Maximum Pci Bus number = 64
    #define VALUE_MAXIMUM_PCI_BUS_128               0x01        // Maximum Pci Bus number = 128
    #define VALUE_MAXIMUM_PCI_BUS_256               0x02        // Maximum Pci Bus number = 256
#define PID_HDD1_FAN_PRESENT                    0x040C   // on P3WS, indicates presence of optional HDD1 fan
    #define VALUE_HDD1_FAN_PRESENT                   1
#define PID_HDD2_FAN_PRESENT                    0x040D   // on P3WS, indicates presence of optional HDD2 fan
    #define VALUE_HDD2_FAN_PRESENT                   1
#define PID_HDD3_FAN_PRESENT                    0x040E   // on P3WS, indicates presence of optional HDD3 fan
    #define VALUE_HDD3_FAN_PRESENT                   1
#define PID_UEFI_NETWORK_STACK                  0x040F   // UEFI network stack

#define PID_PWRMGMT                             0x0410
    #define VALUE_PWRMGMT_DIS                       0   // Power management disable
    #define VALUE_PWRMGMT_MIN                       1   // Power management minimum
    #define VALUE_PWRMGMT_REG                       2   // Power management regular
    #define VALUE_PWRMGMT_MAX                       3   // Power management maximum
#define PID_AUTOPWR                             0x0411
    #define VALUE_AUTOPWRON_DIS                     0   // Auto-power-on disable
    #define VALUE_AUTOPWRON_EVRYDAY                 1   // Auto-power-on every day
    #define VALUE_AUTOPWRON_WKDAYS                  2   // Auto-power-on mon-fri
    #define VALUE_AUTOPWRON_SELECT_DAYS             3   // Atuo-power-on user selects the days
//Auto-power-on hour and minute BCD value are defined few pages down
#define PID_NIC                                 0x0412
    #define VALUE_NIC_DIS                           0
    #define VALUE_NIC_EN                            1
    #define VALUE_NIC_PXE                           2
    #define VALUE_NIC_RPL                           3
    #define VALUE_NIC_WITHOUT_BOOT                  4
    #define VALUE_NIC_IMG_SERV                      5
#define PID_IRLOC                               0x0413
    #define VALUE_IRLOC_FRONT                       0   // Infrared location front
    #define VALUE_IRLOC_BACK                        1   // Infrared location back
#define PID_REPSCSI                             0x0414
#define PID_REPNIC                              0x0415
#define PID_MONITORTOG                          0x0416
#define PID_PCCARD1SLOT                         0x0417
#define PID_PCCARD2SLOT                         0x0418
#define PID_KBCLICK                             0x0419
#define PID_IR_PORT                             0x041A
    #define VALUE_IRDEV_DIS                         0   // Infrared device disable
    #define VALUE_IRDEV_COM1                        1   // Infrared device as COM1
    #define VALUE_IRDEV_COM2                        2   // Infrared device as COM2
    #define VALUE_IRDEV_COM3                        3   // Infrared device as COM3
    #define VALUE_IRDEV_COM4                        4   // Infrared device as COM4

#define PID_SECURE_BOOT_ENABLE                 0x041B   // Secure Boot Enable
#define PID_LEGACY_OPROM_SWITCH                0x041C   // Allow Legacy option ROMs in UEFI boot mode

#define PID_BOOT_MODE_VIS                      0x041D   // 0 = Legacy or 1 = UEFI boot mode
#define PID_SECURE_BOOT_VIS                    0x041E   // 0 = Disabled 1 = Enabled
#define PID_LEGACY_OPROM_VIS                   0x041F   // 1 = Allow Legacy option ROMs

#define PID_NUMLOCK                             0x0420
#define PID_SCSI1                               0x0421
#define PID_SCSI2                               0x0422
#define PID_MEMCACHE                            0x0423
#define PID_PCISCAN                             0x0424
    #define VALUE_PCISCAN_OBFIRST                   0       // PCI scan onboard first
    #define VALUE_PCISCAN_SLOTFIRST                 1       // PCI scan slot first
#define PID_BKUPREMIND                          0x0425
#define PID_SMB_REG_PROT_COUNT                  0x0426      // Number of registered protocols through the SMBIOS DACI
#define PID_CURRENT_THERMAL_MODE                0x0427
    #define VALUE_THERMAL_MODE_BALANCED             0
    #define VALUE_THERMAL_MODE_COOL_BOTTOM          1
    #define VALUE_THERMAL_MODE_QUIET                2
    #define VALUE_THERMAL_MODE_PERFORMANCE          3
    #define VALUE_THERMAL_MODE_MEDIUM_LOW           4
    #define VALUE_THERMAL_MODE_MEDIUM_HIGH          5
// RETIRED - DO NOT USE                         0x0428
#define PID_FAN_CONTROL_OVERRIDE                0x0429      // Fan Control Override Enable/Disable
#define PID_DEEP_SLEEP_MODE                     0x042A      // Fix Changing several BIOS items simultaneously fails to be saved on the next boot
    #define PID_DEEP_SLEEP_DISABLED                 0
    #define PID_DEEP_SLEEP_S5_ONLY                  2
    #define PID_DEEP_SLEEP_S5_AND_S4                4
#define PID_IFFS_SUPPORT                        0x042B
#define PID_DBC_VISIBILITY                      0x042C
#define PID_DBC_ENABLE                          0x042D
#define PID_STEALTHMODE_VISIBILITY              0x042E
#define PID_GPE_VISIBILITY                      0x042F

#define PID_USB_CONTROLLER                      0x0430      // USB Controller
    #define VALUE_USB_CONTR_OFF                     0       // USB Controller = Disabled
    #define VALUE_USB_CONTR_ON                      1       // USB Controller = Enabled
    #define VALUE_USB_CONTR_NOBOOT                  2       // USB Controller = Enabled, No Boot
// RETIRED - DO NOT USE                         0x0431
// RETIRED - DO NOT USE                         0x0432
// RETIRED - DO NOT USE                         0x0433
#define PID_KBD_ATTACHED                        0x0434      // Keyboard attached
#define PID_MULT_CPU_CORE                       0x0435      // Multiple CPU Core Enable/Disable
    #define VAL_MULT_CPU_CORE_ALL                   0       // Enable ALL cores in the CPU
    #define VAL_MULT_CPU_CORE_1                     1       // The PID value is a count of cores with value
    #define VAL_MULT_CPU_CORE_2                     2       //    of zero meaning all cores.  So, these
    #define VAL_MULT_CPU_CORE_3                     3       //    defines can be updated as needed
    #define VAL_MULT_CPU_CORE_4                     4
    #define VAL_MULT_CPU_CORE_5                     5
    #define VAL_MULT_CPU_CORE_6                     6
    #define VAL_MULT_CPU_CORE_7                     7
    #define VAL_MULT_CPU_CORE_8                     8
    #define VAL_MULT_CPU_CORE_9                     9
    #define VAL_MULT_CPU_CORE_10                    10
    #define VAL_MULT_CPU_CORE_11                    11
    #define VAL_MULT_CPU_CORE_12                    12
    #define VAL_MULT_CPU_CORE_13                    13
    #define VAL_MULT_CPU_CORE_14                    14
    #define VAL_MULT_CPU_CORE_15                    15
    #define VAL_MULT_CPU_CORE_16                    16
    #define VAL_MULT_CPU_CORE_17                    17
    #define VAL_MULT_CPU_CORE_18                    18
    #define VAL_MULT_CPU_CORE_19                    19
    #define VAL_MULT_CPU_CORE_20                    20
    #define VAL_MULT_CPU_CORE_21                    21
    #define VAL_MULT_CPU_CORE_22                    22
    #define VAL_MULT_CPU_CORE_23                    23
    #define VAL_MULT_CPU_CORE_24                    24
    #define VAL_MULT_CPU_CORE_25                    25
    #define VAL_MULT_CPU_CORE_26                    26
    #define VAL_MULT_CPU_CORE_27                    27
    #define VAL_MULT_CPU_CORE_28                    28
    #define VAL_MULT_CPU_CORE_29                    29
    #define VAL_MULT_CPU_CORE_30                    30
    #define VAL_MULT_CPU_CORE_31                    31
#define PID_KBD_ERRORS                          0x0436      // Kbd error detection reporting on/ off
#define PID_VIRTUALIZATION                      0x0437      // Virtualization Enable/Disable
#define PID_VIRTUAL_APPLIANCE                   0x0438      // Virtual Appliance Enable/Disable
#define PID_VA_CONFIG_LOCK                      0x0439      // VA Config Lock
    #define VALUE_VA_CONFIG_UNLOCKED                0       // VA Config = UnLocked
    #define VALUE_VA_CONFIG_LOCKED                  1       // VA Config = Locked
#define PID_VA_CONFIRMATION                     0x043A      // VA Confirmation Enable/Disable
#define PID_MEMORY_THROTTLE                     0x043B      // EC initiated Memory Thermal Throttling
#define PID_RESERVED_043C                       0x043C      // Reserved
#define PID_KBD_ERRORS_VISIBILITY               0x043D      // Setup visibility for kbd errors
#define PID_F12_BOOT_OPTION                     0x043E      // Show 'F12 boot option' string on the screen on/ off
#define PID_SKIP_POST_SOFT_ERR_MSG              0x043F      // During POST, skip displaying any MESSAGE_ERROR_SOFT grade errors
//----
#define PID_LIM_CPUID                           0x0440      // Limit CPUID Enable/Disable
#define PID_HDD_ACOUSTIC_MODE                   0x0441      // HDD Acoustic Mode
    #define VALUE_HDD_ACOUSTIC_BYPASS               0       // HDD Acoustic Mode = 'Bypass'
    #define VALUE_HDD_ACOUSTIC_QUIET                0x80    // HDD Acoustic Mode = 'Quiet'
    #define VALUE_HDD_ACOUSTIC_SUGGESTED            0xFE       // HDD Acoustic Mode = 'Suggested'
    #define VALUE_HDD_ACOUSTIC_PERF                 0xFE    // HDD Acoustic Mode = 'Performance'
#define PID_TPM_SECURITY                        0x0442      // TPM Enable/Disable
#define PID_EXECUTE_SUPPORT                     0x0443      // XD Enable/Disable
#define PID_COMPUTRACE                          0x2444      // (0x0444 | PT_WRITE_ONCE)
                                                            // Computrace PID_COMPUTRACE appears
                                                            //    in a .SD file so it can not use
                                                            //    an OR in the equate
    #define VALUE_COMPUTRACE_DEACTIVATE             0       // Computrace Deactivated (No state)
    #define VALUE_COMPUTRACE_ACTIVATE               1       // Computrace Activate (Activate)
    #define VALUE_COMPUTRACE_DISABLE                2       // Computrace Disabled (Deactivate)
#define PID_AC_RECOVERY_MODE                    0x0445      // AC Recovery Mode
    #define VALUE_AC_RECOVERY_OFF                   0       // AC Recovery Mode Off
    #define VALUE_AC_RECOVERY_ON                    1       // AC Recovery Mode On
    #define VALUE_AC_RECOVERY_LAST                  2       // AC Recovery Mode Last
#define PID_REMOTE_WAKEUP                       0x0446      // Remote Wakeup
    #define VALUE_REMOTE_WAKE_OFF                   0       // Remote Wakeup Off
    #define VALUE_REMOTE_WAKE_ON                    1       // Remote Wakeup On
    #define VALUE_REMOTE_WAKE_ON_NIC                2       // Remote Wakeup On w/Boot to NIC
#define PID_LOW_POWER_MODE                      0x0447      // Low Power Mode Enable/Disable
#define PID_SUSPEND_MODE                        0x0448      // Suspend Mode
    #define VALUE_SUSPEND_MODE_S1                   0       // Suspend Mode = S1
    #define VALUE_SUSPEND_MODE_S3                   1       // Suspend Mode = S3
#define PID_TPM_PRESENT                         0x0449      // TPM Present
#define PID_TPM_STATE                           0x044A      // TPM State
    #define VALUE_TPM_STATE_DEACT                   0x00        // TPM De-Activate
    #define VALUE_TPM_STATE_ACT                     0x01        // TPM Activate
    #define VALUE_TPM_STATE_CLEAR                   0x02        // TPM Clear
#define PID_TPM_FORCE_CLEAR                     0x044B      // TPM Force Clear
    #define VALUE_TPM_FC_NO                         0x00        // TPM Force Clear = No
    #define VALUE_TPM_FC_YES                        0x01        // TPM Force Clear = Yes
#define PID_GPE_CLEAR_OWNER                     0x044C      // GPE Clear Owner
    #define VALUE_GPE_STATE_NO_CLEAR                0x00        // Don't clear GPE owner
    #define VALUE_GPE_STATE_CLEAR                   0x01        // Clear GPE owner
#define PID_GPE_ENABLE                          0x044D      // GPE Feature Enable / Disable
#define PID_WARM_BOOT_STORAGE                   0x044e      // Used to save a block of data across warm boot
#define PID_WARM_BOOT                          (0x044f | PT_VOLATILE)
    #define VALUE_WARMBOOT                          0x01    // This is WarmBoot
//----
#define PID_FAST_BOOT                           0x0450      // Fast Boot Enable/Disable
    #define VALUE_FAST_BOOT_MIN                     0       // Boot Mode = "Minimal"
    #define VALUE_FAST_BOOT_THOROUGH                1       // Boot Mode = "Thorough"
    #define VALUE_FAST_BOOT_AUTO                    2       // Boot Mode = "Auto"
#define PID_MEBX_HOTKEY                         0x0451      // MEBx Hotkey Enable/Disable
// RETIRED - DO NOT USE                         0x0452
#define PID_SLP20                               0x0453      // SLP20 supportRemoteWakeup
    #define VALUE_SLP20_ENABLED                     2       // The support is enabled and unlocked - default
    #define VALUE_SLP20_ENABLED_LOCKED              1       // The support is enabled and locked from users changing it
    #define VALUE_SLP20_DISABLED_LOCKED             0       // The support is disabled and locked from users changing it
#define PID_MGMT_DRVR                           0x0454      // Management driver present/ absent
#define PID_LPT_MODE                            0x0455
//  #define VALUE_LPT_DIS                           0   // Parallel port disable
    #define VALUE_LPT_MODE_AT                       1       // Parallel port AT mode
    #define VALUE_LPT_MODE_PS2                      2       // Parallel port PS/2 mode
    #define VALUE_LPT_MODE_ECP                      3       // Parallel port ECP mode
    #define VALUE_LPT_MODE_EPP                      4       // Parallel port EPP mode
    #define VALUE_LPT_MODE_DMA1                     5       // Parallel port DMA1 mode
    #define VALUE_LPT_MODE_DMA3                     6       // Parallel port DMA3 mode
#define PID_SLP20_INVALID                       0x0456  // The support is disabled and locked for CHM
    #define VALUE_SLP20_INVALID                     1
#define PID_STEALTH_ENABLE                      0x0457  // Allow Fn+B support to enable/ disable Steath mode
#define PID_REMOTE_BIOS_UPDATE                  0x0458      // Remote BIOS update
#define PID_PXE_NEXT_BOOT                       0x0459      // Force PXE on next boot
#define PID_SATA_OP                             0x045A      // SATA Operation
    #define VALUE_SATA_OP_ATA                       0       // SATA Mode = ATA
    #define VALUE_SATA_OP_AHCI                      1       // SATA Mode = AHCI
    #define VALUE_SATA_OP_RAID                      2       // SATA mode = RAID
    #define VALUE_SATA_OP_IRRT                      3       // SATA mode = IRRT
    #define VALUE_SATA_OP_DISABLE                  0xFF     // SATA mode = Disable
#define PID_SMART_REPORTING_ENABLE              0x045B      // SMART Reporting
    #define VALUE_SMART_REPORTING_ENABLE          0x01      // SMART Reporting = Enable
#define PID_DISKETTE_DRIVE_ENABLE               0x045C      // Diskette Drive Enable
    #define VALUE_DISKETTE_OP_DISABLE             0x00      // Diskette Drive = Disable
    #define VALUE_DISKETTE_OP_ENABLE              0x01      // Diskette Drive = Enable
#define PID_GPE_DATA                            0x045D      // GPE Data Structure
#define PID_GPE_STATUS_PROPERTY                (0x045E | PT_VOLATILE | PT_BOOT_SERVICE)
#define PID_GPE_HANDLE                          0x045F      // GPE Handle
//----
#define PID_SATA_0                              0x0460      // SATA-0 Enable/Disable
#define PID_SATA_1                              0x0461      // SATA-1 Enable/Disable
#define PID_SATA_2                              0x0462      // SATA-2 Enable/Disable
#define PID_SATA_3                              0x0463      // SATA-3 Enable/Disable
#define PID_SATA_4                              0x0464      // SATA-4 Enable/Disable
#define PID_SATA_5                              0x0465      // SATA-5 Enable/Disable
#define PID_SATA_6                              0x0466      // SATA-6 Enable/Disable
#define PID_SATA_7                              0x0467      // SATA-7 Enable/Disable
#define PID_SATA_0_VISIBLE                      0x0468      // SATA-0 Visibility
#define PID_SATA_1_VISIBLE                      0x0469      // SATA-1 Visibility
#define PID_SATA_2_VISIBLE                      0x046A      // SATA-2 Visibility
#define PID_SATA_3_VISIBLE                      0x046B      // SATA-3 Visibility
#define PID_SATA_4_VISIBLE                      0x046C      // SATA-4 Visibility
#define PID_SATA_5_VISIBLE                      0x046D      // SATA-5 Visibility
#define PID_SATA_6_VISIBLE                      0x046E      // SATA-6 Visibility
#define PID_SATA_7_VISIBLE                      0x046F      // SATA-7 Visibility
//----
#define PID_BOOT_TIME_VIDEO                     0x0470      //Boot-time video is onboard or add-in?
    #define VALUE_PRIMARY_ONBOARD                   0
    #define VALUE_PRIMARY_ADDIN                     1
#define PID_TXT                                 0x0471      // Intel Trusted execution technology
#define PID_VT_DIO                              0x0472      // Intel Virtualization technology direct i/o
#define PID_HYPERTHREADING                      0x0473      // Intel Hyperthreading
#define PID_HW_PREFETCHING                      0x0474      // MLC streamer prefetching
#define PID_ACL_PREFETCHING                     0x0475      // MLC Spatial prefetching
#define PID_AUTOPWRON_HOUR                      0x0476      // Auto-power-on hour BCD value
#define PID_AUTOPWRON_MINUTE                    0x0477      // Auto-power-on minute
#define PID_WAKE_ON_LAN                         0x0478      // Wake-on-LAN
    #define VALUE_WOL_DIS                           0
    #define VALUE_WOL_EN                            1
    #define VALUE_ADDIN_CARD                        2
    #define VALUE_ONBOARD_CARD                      3
    #define VALUE_WIRELESS_OR_NIC                   4
    #define VALUE_LAN_ONLY                          5
    #define VALUE_WLAN_ONLY                         6
    #define VALUE_LAN_WITH_PXE_BOOT                 7
#define PID_WOL_BOOT_OVERRIDE                   0x0479
#define PID_CTRL_WLAN_RADIO_EN                  0x047A
#define PID_CTRL_WWAN_RADIO_EN                  0x047B
#define PID_BLOCK_SLEEP                         0x047C
#define PID_AOAC                                0x047D
#define PID_HIGH_DEF_AUDIO_BAR                  0x047E      //High Def Audio BAR saved for S3 resume path
#define PID_MIC_ARRAY_PRESENT                   0x047F      //Mic array present saved for S3 resume path
//----
#define PID_POST_TEST                           0x0480      //Post boot testing
    #define VALUE_POST_TEST_MIN                     0
    #define VALUE_POST_TEST_FULL                    1
    #define VALUE_POST_TEST_AUTO                    2
#define PID_ENERGY_STAR                         0x0481      //Energy star enable/ disable
#define PID_KILL_TPM                            0x2482      // Removes all TPM support from BIOS (NOTE Don't use the ( x | PT_WRITE_ONCE) here the vfr compiler can't handle it.
// RETIRED - DO NOT USE                         0x0483
#define PID_HOTKEY_F2                           0x0484      //F2 post display enable/ disable
// RETIRED - DO NOT USE                         0x0485
#define PID_CHASSIS_INTRUSION                   0x0486      //Chassis intrusion enable/ disable
    #define VALUE_CI_DIS                            0
    #define VALUE_CI_EN                             1
    #define VALUE_CI_ENS                            2       //enable silent
#define PID_CHASSIS_INTRUSION_WARNING           0x0487     //Clear Intrusion Warning
#define PID_CHASSIS_INTRUSION_VISIBILITY        0x0488      //Chassis Intrusion option visibility
#define PID_EC_MFG_MODE                         0x0489
#define PID_OPTIMUS_VISIBILITY                  0x048A      // Display Optimus user setting
#define PID_BOOT_LIST                           0x048B      // Select UEFI or Legacy boot mode
    #define VALUE_BOOT_LIST_LEGACY              0           // Normal boot is legacy
    #define VALUE_BOOT_LIST_UEFI                1           // Normal boot is UEFI
#define PID_OA30_SHOW_MSDM_TABLE                0x048C      // OA30 Show/Hide MSDM Table
    #define VALUE_OA30_MSDM_HIDE                    0
    #define VALUE_OA30_MSDM_SHOW                    1
#define PID_OA30_KEY                            0x048D      // The board-specific key that gets populated into
#define PID_CHASSIS_INTRUSION_READ              0x048E      // Chassis intrusion state - tied to DA tokens
    #define VALUE_CI_TRIPPED                         0       // Chassis has been opened
//  #define VALUE_CI_NOT_TRIPPED                     1       // RETIRED
    #define VALUE_CI_OPEN                            2       // Chassis is open
    #define VALUE_CI_CLOSED                          3       // Chassis is closed
#define PID_CHASSIS_INTRUSION_RESET             0x048F      // DA token to reset chassis intrusion status
//----
#define PID_SYSTEM_CHECK                        0x0490      //Indentifies any of system mgmt h/w sensors reported errors since last read
#define PID_CLEAR_EVENT_LOG                     0x0491      // Clear system event log enable/ disable
#define PID_PPID                                0x0492
#define PID_PCBA_MFG_MODE                       0x0493
#define PID_ABSOLUTE_ROM_STATUS                 0x0494      // Absolute security rom status. Not used by DA TOKEN
                                                            // Working with PID_COMPUTRACE
    #define VALUE_ABS_DISABLED                      0           // Computrace is disabled
    #define VALUE_ABS_ENABLED                       4           // Computrace is enabled
#define PID_ABSOLUTE_ROM_PASSWRD                0x0495      //Use to store security rom password. Not used by DA TOKEN
#define PID_USER_PW                             0x0496      // This property is used to save the user password
#define PID_ADMIN_PW                            0x0497      // This property is used to save the admin password
#define PID_OWNER_PW                            0x0498      // This property is used to save the owner password
#define PID_VIDEO_TEMPERATURE                  (0x0499 | PT_VOLATILE)  // Tracks video temperature
#define PID_CPU_TEMPERATURE                     0x849A      // (0x049A | PT_VOLATILE)  // Tracks CPU temperature
    #define VALUE_CPU_TEMPERATURE                   0x55
#define PID_THERM0_PRESENT_STATUS               0x849B      // (0x049B | PT_VOLATILE)  // Tracks the Thermistor 0 status
    #define VALUE_T0_STATUS_SAFE                     3          // OK
    #define VALUE_T0_STATUS_WARNING                  4          // Non-critical
    #define VALUE_T0_STATUS_CRITICAL                 5          // Critical
#define PID_THERM0_CRITICAL_HIGH                0x849C      // (0x049C | PT_VOLATILE)  // Thermistor 0 high critical threshold
    #define VALUE_T0_CRIT_HIGH                      0x7F
#define PID_THERM0_CRITICAL_LOW                 0x849D      // (0x049D | PT_VOLATILE)  // Thermistor 0 low critical threshold
    #define VALUE_T0_CRIT_LOW                       0x00
#define PID_DELL_WDT_FEATURE_EN                 0x049E      // This is the property used to enable/disable the Dell watchdog timer feature
    #define VALUE_DELL_WDT_DIS                      0x00    // Disabled
    #define VALUE_DELL_WDT_EN                       0x01    // Enabled
#define PID_EXTEND_BIOS_POST                    0x049F      // Extend BIOS POST Time
    #define VALUE_EXTEND_POST_0                     0x0000      // zero seconds
    #define VALUE_EXTEND_POST_5                     0x0001      // five seconds
    #define VALUE_EXTEND_POST_10                    0x0002      // ten seconds
#define PID_OPTIONAL_BOOT_SEQUENCE              0x04A0
#define PID_ONSCREEN_BUTTONS                    0x04A1
#define PID_DOCK_DP1_VIDEO                      0x04A2
    #define VALUE_DP1_INT                           0               // Internal video
    #define VALUE_DP1_EXT                           1               // Discrete/external video
#define PID_PM_SVC_MENU_REBOOT_COUNT            0x04A3
#define PID_POWER_OFF                           0x04A4      // A system powr-off has been requested by hardware
#define PID_PREV_BOOT_MEM_AMT                   0x04A5      // Amount of memory in the system on the previous boot
    #define VALUE_PREV_BOOT_MEM_AMT_LEN             4       // Value is in MB, so 4 bytes gives 4TB
#define PID_DELL_WDT_ACTIVATION                 0x24A6      // (0x04A6 | PT_WRITE_ONCE) This is the property used to Activate the Dell WDT feature
    #define VALUE_DELL_WDT_DEACT                  0x00      // De-Activated
    #define VALUE_DELL_WDT_ACT                    0x01      // Activated
#define PID_DELL_WDT_VISIBILITY                 0x04A7      // This is the property used for WDT visibility in Setup
#define PID_PEAKPOWER_EN                        0x04A8      // Peak Power for EC
#define PID_SWITCHABLE_GRAPHICS_EN              0x04A9      // Switchable graphics
#define PID_MINIPCI_EN                          0x04AA      // MiniPCI

// This is where Error Logger (ReportStatusCode library) will save error messages it intercepts
// before DXE ErrorHandler is available. When it runs out of CMOS storagge (only 3 now) it will
// use vilotile sotrage (PID_ERROR_MESSAGE_CODE_TEMP_STORE). We need to allocate a congiuous block
// here as ErroLogger will iterate from FIRST_CMOS_PID_FOR_MC to LAST_CMOS_PID_FOR_MC
#define PID_PEI_ERROR_MESSAGE_CODE1             0x04AB
    #define FIRST_CMOS_PID_FOR_MC                   PID_PEI_ERROR_MESSAGE_CODE1
#define PID_PEI_ERROR_MESSAGE_CODE1_SEV         0x04AC
#define PID_PEI_ERROR_MESSAGE_CODE2             0x04AD
#define PID_PEI_ERROR_MESSAGE_CODE2_SEV         0x04AE
#define PID_PEI_ERROR_MESSAGE_CODE3             0x04AF
    #define  LAST_CMOS_PID_FOR_MC                   PID_PEI_ERROR_MESSAGE_CODE3
//----
#define PID_PEI_ERROR_MESSAGE_CODE3_SEV         0x04B0
///////////////////////////////////////////////////////////
// Reserved 0x04B1-0x04BE to give us enough space in CMOS for 10 error mesages
///////////////////////////////////////////////////////////

#define PID_ERROR_MESSAGE_CODE_TEMP_STORE      (0x04BF | PT_VOLATILE) // BIOS Log Message Codes before DXE ErroHandler is avaialble but after CMOS store is full

#define PID_TPM_REMOTE_ACTIVATION               0x04C0  // BOOL flag to remember activation request from remote management
#define PID_TPM_INFO                            0x04C2  // TPM flags and ownership information
#define PID_BLACKTOP_MODULE_INSTALLED           0x04C3  //store if blacktop module is installed
    #define VALUE_BT_MODULE_NONE                    0x00
    #define VALUE_BT_MODULE_ARM                     0x01 //Bit 0 set if the ARM module is installed
    #define VALUE_BT_MODULE_FLASH                   0x02 //Bit 1 set if the BT Flash module is installed
#define PID_TPM_PPI_ACPI_SUPPORT                0x04C4  // Flag to override TPM physical presence ACPI interface
#define PID_TPM_PPI_PROV_OVERRIDE               0x04C5  // Flag to override TPM physical presence requirement for provisioning operations
#define PID_TPM_PPI_DEPROV_OVERRIDE             0x04C6  // Flag to override TPM physical presence requirement for de-provisioning operations
// RETIRED - DO NOT USE                         0x04C7
#define PID_TCM_SECURITY                        0x04C8      // TCM Enable/Disable
#define PID_TCM_PRESENT                         0x04C9      // TCM Present
#define PID_TCM_STATE                           0x04CA      // TCM State
    #define VALUE_TCM_STATE_DEACT                   0x00        // TCM De-Activate
    #define VALUE_TCM_STATE_ACT                     0x01        // df Activate
    #define VALUE_TCM_STATE_CLEAR                   0x02        // TCM Clear
#define PID_TCM_FORCE_CLEAR                     0x04CB      // TCM Force Clear
    #define VALUE_TCM_FC_NO                         0x00        // TCM Force Clear = No
    #define VALUE_TCM_FC_YES                        0x01        // TCM Force Clear = Yes
#define PID_TCM_CURR_STATE                      0x04CC      // TCM Current State
    #define VALUE_TCM_CS_DIS_DEACT                  0x00        // TCM Curr State = Disabled Deactivated
    #define VALUE_TCM_CS_DEACT                      0x01        // TCM Curr State = De-Activated
    #define VALUE_TCM_CS_ACT                        0x02        // TCM Curr State = Activated
#define PID_TCM_MOR                             0x04CD      // TCM MOR
#define PID_TPM_CLEAR_AUX                       0x04CE      // TPM/TxT Clear Aux
    #define VALUE_TPM_CLEAR_AUX_NO                  0x00        // TPM/TxT Clear Aux = No
    #define VALUE_TPM_CLEAR_AUX_YES                 0x01        // TPM/TxT Clear Aux = Yes
#define PID_INT1_PRESENT                        0x04CF
//----
#define PID_INT2_PRESENT                        0x04D0
#define PID_FROM_F12_MENU                      (0x04D1 | PT_VOLATILE)

// Panasonic Special Bid Features
// TOKEN A:
//    Admin password has a length range from 6 to 15 chars
//    Sytem password is 4 chars minumum (no chage from default)
//    Passwords can not be removed once both admin and system passwords are installed
//    Allow admin to unlock system password (no change from default)
//    Do not prompt for a system password on POST if "password changes" are disabled in setup
//    Passwords are case insensitive
// TOKEN B:
//    Boot menu is blocked if the system password is installed unless they type in the admin password
// TOKEN C:
//    Flash program bypasses the admin password check
#define PID_PANASONIC_TOKEN_A                   0x04D2      // Set only through an SMBIOS DA call
    #define PANASONIC_MIN_PWD_SIZE                  6           // Minimum length when TOKEN_A is set
    #define PANASONIC_MAX_PWD_SIZE                  15          // Maximum length when TOKEN_A is set
#define PID_PANASONIC_TOKEN_B                   0x04D3      // Set only through an SMBIOS DA call
#define PID_PANASONIC_SKIP_F12                 (0x04D4 | PT_VOLATILE) // Records if the runtime requirements of PANASONIC_TOKEN_B to skip F12 are satisfied
#define PID_PANASONIC_TOKEN_C                   0x04D5      // Set only through an SMBIOS DA call

// BNNP Special Bid Features
// TOKEN A:
//    Switch to the customer's system name instead of the compiled name
#define PID_BNNP_TOKEN_A                        0x04D6        // Set only through an SMBIOS DA call
#define PID_BNNP_ALT_SYS_NAME_STR               0x04D7        // Unicode string of alternate system name

#define PID_SYSTEM_IS_ATG                      (0x04D8|PT_BOOLEAN) // Flag indicating if the system is an ATG system.
#define PID_ABSOLUTE_ROM_IPv4                   0x04D9   // Store Absolute secret for IPV4
#define PID_TAA_MAC_BYTE1                      (0x04DA | PT_WRITE_ONCE) // TAA MAC Address value byte 1
#define PID_TAA_MAC_BYTE2                      (0x04DB | PT_WRITE_ONCE) // TAA MAC Address value byte 2
#define PID_TAA_MAC_BYTE3                      (0x04DC | PT_WRITE_ONCE) // TAA MAC Address value byte 3
#define PID_TAA_MAC_BYTE4                      (0x04DD | PT_WRITE_ONCE) // TAA MAC Address value byte 4
#define PID_TAA_MAC_BYTE5                      (0x04DE | PT_WRITE_ONCE) // TAA MAC Address value byte 5
#define PID_TAA_MAC_BYTE6                      (0x04DF | PT_WRITE_ONCE) // TAA MAC Address value byte 6
//----
#define PID_CHASSIS_INTRUSION_CABLE             0x04E0  // Flag that the Chassis Intrusion Switch was present at one time
#define PID_AUTOPWRON_SUNDAY                    0x04E1
#define PID_AUTOPWRON_MONDAY                    0x04E2
#define PID_AUTOPWRON_TUESDAY                   0x04E3
#define PID_AUTOPWRON_WEDNESDAY                 0x04E4
#define PID_AUTOPWRON_THURSDAY                  0x04E5
#define PID_AUTOPWRON_FRIDAY                    0x04E6
#define PID_AUTOPWRON_SATURDAY                  0x04E7
#define PID_EXTERNAL_MIC_PRESENT                0x04E8  // External Mic Detected saved for S3 resume path
#define PID_CHASSIS_INTRUSION_PET               0x04E9  // Flag used in the intrusion driver to determine if we should send a PET
#define PID_PEAKSHIFT                           0x04EA
#define PID_PEAKSHIFT_BATTERY_THRESHOLD         0x04EB
#define PID_PRIMARY_VIDEO_DEVICE_INDEX          0x04EC
#define PID_ADVANCED_BATTERY_CHARGING_MODE      0x04ED // Appplied to all batteries in the system.  Overrides other charging modes.
#define PID_PEAKSHIFT_SUNDAY_HOURS              0x04EE // 32 bit peak shift hours structure.  See Dell SMBIOS specification for details.
#define PID_PEAKSHIFT_MONDAY_HOURS              0x04EF // 32 bit peak shift hours structure.  See Dell SMBIOS specification for details.
//----
#define PID_PEAKSHIFT_TUESDAY_HOURS             0x04F0 // 32 bit peak shift hours structure.  See Dell SMBIOS specification for details.
#define PID_PEAKSHIFT_WEDNESDAY_HOURS           0x04F1 // 32 bit peak shift hours structure.  See Dell SMBIOS specification for details.
#define PID_PEAKSHIFT_THURSDAY_HOURS            0x04F2 // 32 bit peak shift hours structure.  See Dell SMBIOS specification for details.
#define PID_PEAKSHIFT_FRIDAY_HOURS              0x04F3 // 32 bit peak shift hours structure.  See Dell SMBIOS specification for details.
#define PID_PEAKSHIFT_SATURDAY_HOURS            0x04F4 // 32 bit peak shift hours structure.  See Dell SMBIOS specification for details.
#define PID_ADV_BATT_CHARGING_SUNDAY_HOURS      0x04F5 // 32 bit advanced battery charging working hours structure.  See Sell SMBIOS specification for details.
#define PID_ADV_BATT_CHARGING_MONDAY_HOURS      0x04F6 // 32 bit advanced battery charging working hours structure.  See Sell SMBIOS specification for details.
#define PID_ADV_BATT_CHARGING_TUESDAY_HOURS     0x04F7 // 32 bit advanced battery charging working hours structure.  See Sell SMBIOS specification for details.
#define PID_ADV_BATT_CHARGING_WEDNESDAY_HOURS   0x04F8 // 32 bit advanced battery charging working hours structure.  See Sell SMBIOS specification for details.
#define PID_ADV_BATT_CHARGING_THURSDAY_HOURS    0x04F9 // 32 bit advanced battery charging working hours structure.  See Sell SMBIOS specification for details.
#define PID_ADV_BATT_CHARGING_FRIDAY_HOURS      0x04FA // 32 bit advanced battery charging working hours structure.  See Sell SMBIOS specification for details.
#define PID_ADV_BATT_CHARGING_SATURDAY_HOURS    0x04FB // 32 bit advanced battery charging working hours structure.  See Sell SMBIOS specification for details.
#define PID_BATT_PAGE_GRAYOUT_FLAG              0x04FC // Used for grayout the field in runtime. Not a setup option
#define PID_GPE_VERSION                         0x04FD // Indicates GPE genertation currently active
    #define GPE_VERSION_UNKNOWN                     0x00 // Generation Not Selected
    #define GPE_VERSION_GEN1                        0x01 // Generation 1
    #define GPE_VERSION_GEN2                        0x02 // Generation 2 RTOS


#define PID_ZERO_POWER_ODD                      0x04FE

#define PID_DEBUG_TO_MEMORY                     0x04FF // Enable/Disable rerouting the debug statements to memory
#define PID_PEI_LOG_SIZE                        0x0500 // Size for the PEI log
#define PID_MAX_LOG_SIZE                        0x0501 // Maximum Size for the debug to memory log
#define PID_DEBUG_TO_HECI                       0x0502 // Enable/Disable rerouting the debug statements to the HECI
#define PID_DEBUG_TO_DRIVE                      0x0503 // Enable/Disable rerouting the debug statements to a drive
                                                       // problems occur if you use 0x??? | PT_WRITE_ONCE in .sd files
#define PID_PERM_DIS_EXT_USB_PORT               0x2504 // (0x0504 | PT_WRITE_ONCE)
#define PID_PERM_DIS_FRONT_USB_PORT             0x2505 // (0x0505 | PT_WRITE_ONCE)
#define PID_PERM_DIS_REAR_DUAL_USB_PORT         0x2506 // (0x0506 | PT_WRITE_ONCE)
#define PID_PERM_DIS_REAR_QUAD_USB_PORT         0x2507 // (0x0507 | PT_WRITE_ONCE)
#define PID_PERM_DIS_USB3_PORT                  0x2508 // (0x0508 | PT_WRITE_ONCE)
#define PID_PERM_DIS_WIRELESS_WLAN              0x2509 // (0x0509 | PT_WRITE_ONCE)
#define PID_PERM_DIS_WIRELESS_BT                0x250A // (0x050A | PT_WRITE_ONCE)
#define PID_PERM_DIS_WIRELESS_GPS               0x250B // (0x050B | PT_WRITE_ONCE)
#define PID_PERM_DIS_MIC                        0x250C // (0x050C | PT_WRITE_ONCE)
#define PID_PERM_DIS_ICH_AZALIA                 0x250D // (0x050D | PT_WRITE_ONCE)
#define PID_PERM_DIS_PCCARD_1394                0x250E // (0x050E | PT_WRITE_ONCE)
#define PID_PERM_DIS_CAMERA_FRONT               0x250F // (0x050F | PT_WRITE_ONCE)
#define PID_PERM_DIS_CAMERA_BACK                0x2510 // (0x0510 | PT_WRITE_ONCE)
#define PID_PERM_DIS_ESATA                      0x2511 // (0x0511 | PT_WRITE_ONCE)
#define PID_PERM_DIS_EXPCARD                    0x2512 // (0x0512 | PT_WRITE_ONCE)

#define PID_GPE_CLEAR_BINDING                   0x0513          // Set to clear the RTOS Gpe (GEN2) OSPA Application Bindings
    #define VALUE_GPE_BINDING_CLEAR_DIS             0x00        // Don't clear GPE Bindings
    #define VALUE_GPE_BINDING_CLEAR_EN              0x01        // Clear GPE Bindings

#define PID_DEBUG_TO_SERIAL                     0x0514 // Enable/Disable rerouting the debug statements to the serial port
#define PID_VERBOSE_HOTKEY                      0x0515 // Enable/Disable adding PCI/PMIO/GPIO/Port data to the serial
                                                       // output when the hotkey is used
//#define PID_PTT_PRESENT                         0x8516 // PTT (Firmware TPM) Present [Volatile]
#define PID_PTT_PRESENT                         0x0516 // PTT (Firmware TPM) Present
#define PID_PTT_STATE                           0x0517 // PTT (Firmware TPM) State
    #define PTT_STATE_DISABLE                       0x00 // Disabled
    #define PTT_STATE_ENABLE                        0x01 // Enabled
    #define PTT_STATE_CLEAR                         0x02 // Clear (temporary state until clear operation is done, then change to Enabled)

#define PID_RUGGED_GBE                          0x0518

                                                        // problems occur if you use 0x??? | PT_WRITE_ONCE in .sd files
#define PID_PERM_DIS_GLOBAL_EN                  0x2519  // Atleast one device in system has been permanently disabled
#define PID_PERM_DIS_NIC                        0x251A  // 0 = Permanently Disable Nic
#define PID_PERM_DIS_SERIAL_PORT1               0x251B  // 0 = Permanently Disable Serial Port 1
#define PID_PERM_DIS_SATA_OP                    0x251C  // 0 = Permanently Disable Sata Controller
#define PID_PERM_DIS_SATA_0                     0x251D  // 0 = Permanently Disable Sata Port 0
#define PID_PERM_DIS_SATA_1                     0x251E  // 0 = Permanently Disable Sata Port 1
#define PID_PERM_DIS_SATA_2                     0x251F  // 0 = Permanently Disable Sata Port 2
#define PID_PERM_DIS_SATA_3                     0x2520  // 0 = Permanently Disable Sata Port 3
#define PID_PERM_DIS_SATA_4                     0x2521  // 0 = Permanently Disable Sata Port 4
#define PID_PERM_DIS_SATA_5                     0x2522  // 0 = Permanently Disable Sata Port 5
#define PID_PERM_DIS_PCISLOT_EN                 0x2523  // 0 = Permanently Disable Pci Slot

#define PID_PWR_BTN_HOTKEY                      0x0524  // Enable/Disable writing the log to the serial port when
                                                        // the power button is pressed.

#define PID_PERM_DIS_WWAN                       0x2525  // (0x0525 | PT_WRITE_ONCE)

#define PID_QUIET_BLUETOOTH                     0x0526  // "Quiet Mode" selectable Bluetooth radio  control
#define PID_QUIET_FANS                          0x0527  // "Quiet Mode" selectable system fans      control
#define PID_QUIET_GPS                           0x0528  // "Quiet Mode" selectable GPS radio        control
#define PID_QUIET_LCD                           0x0529  // "Quiet Mode" selectable LCD back light   control
#define PID_QUIET_LEDS                          0x052A  // "Quiet Mode" selectable system LEDs      control
#define PID_QUIET_SPEAKERS                      0x052B  // "Quiet Mode" selectable onboard speakers control
#define PID_QUIET_WLAN                          0x052C  // "Quiet Mode" selectable WLAN radio       control (WiGig radio also)
#define PID_QUIET_WWAN                          0x052D  // "Quiet Mode" selectable WWAN radio       control
// See also PID_QUIET_WIGIG below!

#define PID_FRAME_FILTER                        0x052E  // Filter debug statements based on a frame
#define PID_LINE_FILTER                         0x052F  // Filter debug statements based on line
#define PID_PORT_FILTER                         0x0530  // Filter debug statements based on port code

#define PID_QUIET_WIGIG                         0x0531  // "Quiet Mode" selectable WiGig radio      control

#define PID_RUGGED_DOCK_NIC_PXE                 0x0532
#define PID_SLP20_ORIGINAL                      0x0533  // Original SLP20, before modified by Client ID
#define PID_PM_UNINSTALLLOCK                    0x0534

#define PID_ALLOW_BIOS_DOWNGRADE                0x0535  // Enable/Disable the BIOS Downgrade Option.
    #define VALUE_ALLOW_BIOS_DOWNGRADE_DIS             0x00        // Don't allow BIOS Revision Downgrades
    #define VALUE_ALLOW_BIOS_DOWNGRADE_EN              0x01        // allow BIOS Revision Downgrades

#define PID_LIQUID_COOLING1_PRESENT             0x0536   // Indicates presence of liquid cooler1
     #define VALUE_LIQUID_COOLER1_PRESENT            1
#define PID_LIQUID_COOLING2_PRESENT             0x0537   // indicates presence of liquid cooler2
     #define VALUE_LIQUID_COOLER2_PRESENT            1


//------------------------------------------------------------------------------------------------
//                              Reserved for DellSupportAssist 0x0538-0x0558
//------------------------------------------------------------------------------------------------
#define PID_OS_BOOT_FAIL_THRESHOLD              0x0538
    #define OS_BOOT_FAIL_DISABLED                   0x00
    #define OS_BOOT_FAIL_1                          0x01
    #define OS_BOOT_FAIL_2                          0x02
    #define OS_BOOT_FAIL_3                          0x03
#define PID_SERVICE_OS_DELETE                   0x0539
    #define PRESERVE_4K_STORAGE                     0x00
    #define RESET_4K_STORAGE                        0x01
#define PID_SERVICE_OS_ENABLED                  0x053A
    #define SERVICE_OS_DISABLED                     0x00
    #define SERVICE_OS_ENABLED                      0x01
#define PID_RECOVERY_TOOL_ENABLED               0x053B
    #define RECOVERY_TOOL_DISABLED                  0x00
    #define RECOVERY_TOOL_ENABLED                   0x01
// Major = 00 indicates no SupportAssist support
// Major = 01, Minor = 0x00 to 0x7F indicates Initial Excalibur support (no Service OS)
// Major = 01, Minor = 0x80 to 0xFF indicates Excalibur 1.0 "Full Support".
// Major = 02 indicates Excalibur 2.0 support
#define PID_SUPPORTASSIST_SUPPORT_LEVEL         0x053C

#define PID_PERSISTENCE_AID_ENABLED             0x053D
#define PID_BARE_METAL_TOOL_ENABLED             0x053E
    #define BARE_METAL_TOOL_DISABLED                0x00
    #define BARE_METAL_TOOL_ENABLED                 0x01

#define PID_BIOS_CONNECT_STATE                  0x053F
    #define BIOS_CONNECT_DISABLED                   0x00    // BiosConnect Feature disable
    #define BIOS_CONNECT_ENABLED                    0x01    // BiosConnect Feature enable

#define PID_BIOS_CONNECT_STATUS                 0x0540
    #define BIOS_CONNECT_ACTIVATION_DISABLE         0x00    // BiosConnect show in Setup only
    #define BIOS_CONNECT_ACTIVATION_FULL            0x01    // BiosConnect show in Setup/LaunchPad/BiosDiags
    #define BIOS_CONNECT_ACTIVATION_LAUNCHPAD       0x02    // BiosConnect show in Setup/LauchPad

#define PID_BIOS_CONNECT_CAPABILITY             (0x0541 | PT_VOLATILE)
#define PID_BIOS_CONNECT_VERSION                (0x0542 | PT_VOLATILE)

//------------------------------------------------------------------------------------------------

#define PID_LIQUID_COOLING1_ENABLE              0x0559
     #define VALUE_LIQUID_COOLING1_ENABLE            1
#define PID_LIQUID_COOLING2_ENABLE              0x055A
     #define VALUE_LIQUID_COOLING2_ENABLE            1

#define PID_TPM_EXTENDED_INFO                   (0x055B | PT_VOLATILE)
//Mode Values
    #define VALUE_TPM_MODE_TPM12                    0x12
    #define VALUE_TPM_MODE_TPM20                    0x20
    #define VALUE_TPM_MODE_PTT                      0xF0
    #define VALUE_TPM_MODE_UNKNOWN                  0xFF
//AlgorithmSize Values
    #define VALUE_TPM_HASH_ALGORITHM_SIZE_SHA1      20
    #define VALUE_TPM_HASH_ALGORITHM_SIZE_SHA256    32
    #define VALUE_TPM_HASH_ALGORITHM_SIZE_SHA512    64
    #define VALUE_TPM_HASH_ALGORITHM_SIZE_UNKNOWN   0xFFFF
#define PID_TPM_AUTH                            (0x055C | PT_VOLATILE | PT_BOOT_SERVICE)
#define PID_TPM_OWNED                           0x955D      // (0x055D | PT_VOLATILE | PT_BOOLEAN)
    #define VALUE_TPM_NOT_OWNED                     0x0
    #define VALUE_TPM_OWNED                         0x1
#define PID_DOCK_BATTERY_CHARGE_MODE            0x055E
#define PID_TPM_HASH_ALGORITHM                  0x055F
    #define VALUE_TPM_HASH_ALGORITHM_SHA1           0x00
    #define VALUE_TPM_HASH_ALGORITHM_SHA256         0x01
    #define VALUE_TPM_HASH_ALGORITHM_UNKNOWN        0xFF
#define PID_TPM_20_SH_ENABLE                    0x0560
#define PID_TPM_20_EH_ENABLE                    0x0561

#define PID_BIOS_RECOVERY_FROM_HDD              0x0562

#define PID_TPM_PROVISION_STATE                 0x0563

#define PID_CAPSULE_UPDATE                      0x0564      // Enable/Disable BIOS flashing via UEFI Capsule
#define PID_PERM_DIS_SERIAL_PORT2               0x2565  // (0x0565|PT_WRITE_ONCE) 0 = Permanently Disable Serial Port 2
#define PID_PERM_DIS_SERIAL_PORT3               0x2566  // (0x0566|PT_WRITE_ONCE) 0 = Permanently Disable Serial Port 3
#define PID_PERM_DIS_SERIAL_PORT4               0x2567  // (0x0567|PT_WRITE_ONCE) 0 = Permanently Disable Serial Port 4
#define PID_PERM_DIS_SERIAL_PORT5               0x2568  // (0x0568|PT_WRITE_ONCE) 0 = Permanently Disable Serial Port 5
#define PID_PERM_DIS_SERIAL_PORT6               0x2569  // (0x0569|PT_WRITE_ONCE) 0 = Permanently Disable Serial Port 6

#define PID_PERM_DIS_TOP_USB1                   0x256A  //  (0x056A|PT_WRITE_ONCE)
#define PID_PERM_DIS_TOP_USB2                   0x256B  //  (0x056B|PT_WRITE_ONCE)
#define PID_PERM_DIS_BOTTOM_USB                 0x256C  //  (0x056C|PT_WRITE_ONCE)

#define PID_PERM_DIS_NIC2                       0x256D  //  (0x056D|PT_WRITE_ONCE)
#define PID_PERM_DIS_EXT_USB4                   0x256E   // (0x056E|PT_WRITE_ONCE)
#define PID_PERM_DIS_EXT_USB5                   0x256F  //  (0x056F|PT_WRITE_ONCE)
#define PID_PERM_DIS_EXT_USB6                   0x2570   // (0x0570|PT_WRITE_ONCE)
#define PID_PERM_DIS_CANBUS                     0x2571  //  (0x0571|PT_WRITE_ONCE)

#define PID_M2_PCIE_SSD_0                       0x0572  // M.2 PCIe SSD-0
#define PID_M2_PCIE_SSD_1                       0x0573  // M.2 PCIe SSD-1

#define PID_SNOWFIELD_PEAK_POWER_PULL           0x0574  //  Pull all power from wireless card (8260) when going to Stealth

// PIDs for custom defaults user values of Advanced Battery Charging
#define PID_CD_ADV_BATT_CHARGING_MONDAY_HOURS    0x0575
#define PID_CD_ADV_BATT_CHARGING_TUESDAY_HOURS   0x0576
#define PID_CD_ADV_BATT_CHARGING_WEDNESDAY_HOURS 0x0577
#define PID_CD_ADV_BATT_CHARGING_THURSDAY_HOURS  0x0578
#define PID_CD_ADV_BATT_CHARGING_FRIDAY_HOURS    0x0579
#define PID_CD_ADV_BATT_CHARGING_SATURDAY_HOURS  0x057A
#define PID_CD_ADV_BATT_CHARGING_SUNDAY_HOURS    0x057B

// PIDs for custom defaults user values of Peak Shift
#define PID_CD_PEAKSHIFT_SUNDAY_HOURS            0x057C
#define PID_CD_PEAKSHIFT_MONDAY_HOURS            0x057D
#define PID_CD_PEAKSHIFT_TUESDAY_HOURS           0x057E
#define PID_CD_PEAKSHIFT_WEDNESDAY_HOURS         0x057F
#define PID_CD_PEAKSHIFT_THURSDAY_HOURS          0x0580
#define PID_CD_PEAKSHIFT_FRIDAY_HOURS            0x0581
#define PID_CD_PEAKSHIFT_SATURDAY_HOURS          0x0582

#define PID_SYS_LOW_NITS_PANEL_PWM_BRIGHTNESS    0x0583  // PID to tell EC setting for Low Nits mode

#define PID_EAP_CONFIG_ENABLED                  0x0584
#define PID_MPM_CONFIG                          0x0585

#define PID_BIOS_RECOVERY_AUTO                  0x0586
#define PID_BIOS_INTEGRITY_CHECK                0x0587  // When enabled, integrity check is performed on every boot.
#define PID_DELL_OS_SLEEP_STATE                 0x0588  // Factory/CFI option for Modern Standby (MS) support
	#define MODERN_STANDBY_AUTO_MODE			1       // Unit offers ACPI support for MS and S3 - OS selection
	#define LEGACY_S3							0       // Unit only offers S3 support
#define PID_MAC_ADDRESS_PASS_THROUGH            0x0589
    #define VALUE_MAC_ADDRESS_PASS_THROUGH_SUMA     0x00
    #define VALUE_MAC_ADDRESS_PASS_THROUGH_NIC1     0x01
    #define VALUE_MAC_ADDRESS_PASS_THROUGH_DISABLE  0x02
#define PID_NIC1_MAC_STRING                     0x058A
#define PID_REALTEK_MAC_STRING                  0x058B
#define PID_FORMER_SERVICE_TAG                  0x058C
///////////////////////////////////////////////////////////
// PID 0x0589 TO 0x05FF Available for future use
///////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////
// Setup-based variables begin here.
///////////////////////////////////////////////////////////////////////////////////////////////////

#define PID_WAKE_ON_AC                          0x0600      // Wake on AC Insertion
#define PID_WAKE_ON_USB                         0x0601      // Wake on USB from S3
#define PID_EXPRESSCHARGE                       0x0602      // Dell ExpressCharge feature
    #define VALUE_EXCHG_BAT_NOT_PRESENT             0x00        // battery not present
    #define VALUE_EXCHG_STD                         0x01        // Mode = "Standard"
    #define VALUE_EXCHG_EXCHG                       0x02        // Mode = "ExpressCharge"
    #define VALUE_ONETIME_EXCHG_EXCHG               0x03        // Mode = "OneTimeExpressCharge"
#define PID_CHARGER_BEHAVIOR                    0x0603      // Charger Behavior
#define PID_ADAPTER_WARNINGS                    0x0604      // AC Adapter Warnings
#define PID_KEYPAD_BEHAVIOR                     0x0605      // Laptop Keyboard Keypad Behavior
    #define VALUE_KPD_FN_KEY                        0x00            // Mode = "Fn Key Only"
    #define VALUE_KPD_BY_NUMLOCK                    0x01            // Mode = "By Numlock Only"
#define PID_MOUSE_BEHAVIOR                      0x0606      // Laptop Mouse/Touchpad Bevahior
    #define VALUE_MOUSE_SER                         0x00            // Mode = "SERIAL Mouse"
    #define VALUE_MOUSE_PS2                         0x01            // Mode = "PS/2 Mouse"
    #define VALUE_MOUSE_TP_AND_PS2                  0x02            // Mode = "Touchpad AND PS/2 Mouse"
#define PID_USB_EMULATION                       0x0607      // USB Emulation Mode
#define PID_FN_KEY_EMULATION                    0x0608      // Laptop Fn Key Emulation
#define PID_INT_MODEM_EN                        0x0609      // Internal Modem Enable
#define PID_INT_MODEM_VIZ                       0x060A      // Internal Modem Visible?
#define PID_MODBAY_VIZ                          0x060B      // Modbay Visible?
#define PID_KEYCLICK                            0x060C      // Enable key clicks?
#define PID_SWITCHABLE_VIDEO                    0x060D      // Switchable Graphics Mode
    #define VALUE_SG_UMA                            0x00            // Mode = UMA Gfx Only
    #define VALUE_SG_DISCRETE                       0x01            // Mode = Discrete Gfx Only
    #define VALUE_SG_SWITCHABLE                     0x02            // Mode = Switchable Graphics
#define PID_CB_1394_VISIBILITY                  0x060E      // Cardbus,1394, etc enable.
#define PID_SERR                                0x060F      // SERR Messages enable/disable
//----
#define PID_MOD_BAY_ENABLE                      0x0610      // Internal Module Bay Enable
#define PID_PCCARD_1394_ENABLE                  0x0611      // PC Card/1394 Enable
    #define VAL_MF_DISABLE_ALL                      0x00        // Disable all MF Functions
    #define MF_BITFIELD_UNSUPPORTED                (0x00)
    #define MF_BITFIELD_PCCARD                     (0x01 << 0)
    #define MF_BITFIELD_MC                         (0x01 << 1)
    #define MF_BITFIELD_SD                         (0x01 << 1)  // Intentionally the same as SD
    #define MF_BITFIELD_1394                       (0x01 << 2)
    #define MF_BITFIELD_XD                         (0x01 << 3)
    #define MF_BITFIELD_MS                         (0x01 << 4)
    #define MF_BITFIELD_SD2                        (0x01 << 5)
    #define VAL_MF_PCCARD_1394_MC                   0x1F    //(MF_BITFIELD_PCCARD | MF_BITFIELD_MC | MF_BITFIELD_1394 | MF_BITFIELD_XD |MF_BITFIELD_MS)  // Enable all MF Functions
    #define VAL_MF_ENABLE_ALL                       VAL_MF_PCCARD_1394_MC         // Enable all MF Functions
    // Brooks is the only platform supports XD, redefines VAL_MF_MC to 0x0A would work for Brooks, but may breaks other platforms and SMBIOS tools.
    // VAL_MF_PCCARD_1394_MC has already broken SMBIOS tools once when added MF_BITFIELD_XD
    // Add a dedicated VAL_MF_MC_XD and SMBIOS token just for Brooks.
    #define VAL_MF_MC_XD                            0x0A    //(MF_BITFIELD_MC | MF_BITFIELD_XD)             // Enable only MC and XD
    #define VAL_MF_PCCARD_1394                      0x05    //(MF_BITFIELD_PCCARD | MF_BITFIELD_1394)       // Enable only PCCARD and 1394
    #define VAL_MF_1394_MC                          0x06    //(MF_BITFIELD_MC | MF_BITFIELD_1394)           // Enable only MC and 1394
    #define VAL_MF_PCCARD_MC                        0x03    //(MF_BITFIELD_PCCARD | MF_BITFIELD_MC)         // Enable only MC and PCCARD
    #define VAL_MF_MC                               0x02    //(MF_BITFIELD_MC)                              // Enable only MC
    #define VAL_MF_PCCARD                           0x01    //(MF_BITFIELD_PCCARD)                          // Enable only PCCARD
    #define VAL_MF_1394_MC_DIS                      (UINT8)(VAL_MF_ENABLE_ALL & ~(VAL_MF_1394_MC))          // Disable 1394 and MC
    #define VAL_MF_PCCARD_1394_DIS                  (UINT8)(VAL_MF_ENABLE_ALL & ~(VAL_MF_PCCARD_1394))      // Disable PCCard and 1394

#define PID_EXT_USB_PORT_EN                     0x0612      // External Laptop USB port enable
#define PID_MIC_ENABLE                          0x0613      // Microphone Enable
#define PID_ESATA_ENABLE                        0x0614      // eSATA Ports Enable
#define PID_POWERSHARE_ENABLE                   0x0615      // PowerShare Enable
#define PID_POWERSHARE_PERCENTAGE               0x0616      // PowerShare Percentage
    #define VALUE_POWERSHARE_0                      0x00        // PowerShare Percentage = 0%
    #define VALUE_POWERSHARE_3                      0x01        // PowerShare Percentage = 3%
    #define VALUE_POWERSHARE_10                     0x02        // PowerShare Percentage = 10%
    #define VALUE_POWERSHARE_25                     0x03        // PowerShare Percentage = 25%
    #define VALUE_POWERSHARE_50                     0x04        // PowerShare Percentage = 50%
    #define VALUE_POWERSHARE_75                     0x05        // PowerShare Percentage = 75%
#define PID_ASSET_TAG                           0x0617      // Asset Tag
#define PID_SERVICE_TAG                         0x2618      // Service Tag (0x0618 | PT_WRITE_ONCE)
#define PID_WIFI_CATCHER                        0x0619      // WIFI Catcher Enable
    #define VALUE_WIFI_CATCHER_DIS                  0x00        // WIFI Catcher Disable
    #define VALUE_WIFI_CATCHER_EN                   0x01        // WIFI Catcher Enable
    #define VALUE_WIFI_CATCHER_RTB                  0x02        // WIFI Catcher Reset to Basic Mode
#define PID_WIRELESS_SW_WWAN                    0x061A      // Wireless switch - WWAN
#define PID_OWNER_TAG                           0x061B      // Owner Tag
#define PID_CAMERA_ENABLE                       0x061C      // Camera Enable
#define PID_CAMERA_VISIBILITY                   0x061D      // Camera field visibility
#define PID_CAMERA_DEV_VEN                     (0x061E | PT_VOLATILE | PT_BOOT_SERVICE)       // Camera Device/Vendor ID

// This is SetupData->PrimaryDisplay MRC/Core code uses this don't change definition
#define PID_PRIMARY_DISPLAY                    0x061F
    #define VALUE_PD_UMA                            0x0
    #define VALUE_PD_PEG                            0x1
    #define VALUE_PD_PCI                            0x2
    #define VALUE_PD_AUTO                           0x3
    #define VALUE_PD_HYBRID                         0x4
//----
#define PID_WIRELESS_SW_WLAN                    0x0620      // Wireless switch - WLAN
#define PID_WIRELESS_SW_BT                      0x0621      // Wireless switch - Bluetooth
#define PID_WIRELESS_EN_WLAN                    0x0622      // Wireless Enable - WLAN
#define PID_WIRELESS_EN_WWAN                    0x0623      // Wireless Enable - WWAN
#define PID_WIRELESS_EN_BT                      0x0624      // Wireless Enable - Bluetooth
#define PID_WIRELESS_SUPP_WWAN                  0x0625      // Wireless Supported - WWAN
#define PID_EXPCARD_ENABLE                      0x0626
#define PID_EXPCARD_VISIBILITY                  0x0627
#define PID_VIZ_CTRL_HYBRID_GRAPHICS            0x0628
#define PID_WIRELESS_EN_UWB                     0x0629      // Wireless Enable - UWB
#define PID_WIRELESS_SW_UWB                     0x062A      // Wireless switch - UWB
#define PID_WIRELESS_SUPP_UWB                   0x062B      // Wireless Supported - UWB
#define PID_MINICARD_SSD_ENABLE                 0x062C      // Minicard SSD Enable
#define PID_PCCARD_VISIBILITY                   0x062D      // PC Card VISIBILITY
#define PID_CAMERA_CONTROL                      0x062E      // Camera Hardware Control
    #define VALUE_CAMERA_CONTROL_OFF                0x00
    #define VALUE_CAMERA_CONTROL_ON                 0x01
    #define VALUE_CAMERA_CONTROL_UNKNOWN            0xff
#define PID_MFG_REBOOT_FLAG                     0x062F      // Flags variable used internally by the DellMfgToolsSmm driver
//----
// Dell Security Variables
#define PID_INT_HDD_PW                          0x0630      // Internal HDD Password
#define PID_MODBAY_HDD_PW                       0x0631      // Module Bay HDD Password
#define PID_DOCK_HDD_PW                         0x0632      // Dock eSATA HDD Password
#define PID_SYS_ESATA_HDD_PW                    0x0633      // System eSATA HDD Password
#define PID_MINICARD_SSD_PW                     0x0634      // MiniCard SSD Password
#define PID_SIGNED_FW_UPDATE                    0x2635      // (PT_WRITE_ONCE) Vfr Can't expand OR operator so the W/O bit is hard-coded
#define PID_KEYBOARD_BACKLIGHT_MODE             0x0636      // Keyboard Backlight Control
    #define VALUE_KBD_BACKLIGHT_OFF                 0x0000      // Keyboard backlight OFF (BIT0)
    #define VALUE_KBD_BACKLIGHT_ON                  0x0001      // Keyboard backlight On (no ALS) (BIT1)
    #define VALUE_KBD_BACKLIGHT_ALS                 0x0002      // Keyboard backlight On w/ALS (BIT2)
    #define VALUE_KBD_BACKLIGHT_ALS_ON_INP_OFF      0x0003      // Keyboard backlight On w/ALS input activity off (BIT3)
    #define VALUE_KBD_BACKLIGHT_INP_ON_INP_OFF      0x0004      // Keyboard backlight On input activity on/off (no ALS) (BIT4)
    #define VALUE_KBD_BACKLIGHT_25P                 0x0005      // Keyboard backlight On at 25% Brightness (no ALS) (BIT5)
    #define VALUE_KBD_BACKLIGHT_50P                 0x0006      // Keyboard backlight On at 50% Brightness (no ALS) (BIT6)
    #define VALUE_KBD_BACKLIGHT_75P                 0x0007      // Keyboard backlight On at 75% Brightness (no ALS) (BIT7)
    #define VALUE_KBD_BACKLIGHT_100P                0x0008      // Keyboard backlight On at 100% Brightness (no ALS) (BIT8)

#define PID_VIZ_CTRL_ALS                        0x0637      // Display control for ALS Enable
#define PID_VIZ_CTRL_KBD_BKLIGHT                0x0638      // Display control for Keyboard Backlight
#define PID_VIZ_CTRL_KBD_BKLIGHT_ALS            0x0639      // Display control for Keyboard Backlight w/ALS
#define PID_VIZ_CTRL_OLD_ADMIN_PWD              0x063A      // Display control for OLD ADMIN PWD
#define PID_ALLOW_NON_ADMIN_CATCHER             0x063B      // Allow Non-Admin Setup changes to the wireless catcher
#define PID_ALLOW_NON_ADMIN_SWITCH              0x063C      // Allow Non-Admin Setup changes to the wireless switch
#define PID_DELL_SETUP_HII_HANDLE              (0x063D | PT_VOLATILE | PT_BOOT_SERVICE)      // The Hii Handle for the Dell Setup formset
#define PID_ENABLE_CIRA                         0x063E      // Enable CIRA/Help Desk
#define PID_ENABLE_CIRA_VISIBILITY              0x063F      // Visibility variable for Enable CIRA/Help Desk
//----
#define PID_SYSTEM_MANAGEMENT                   0x0640      // System managebility setting (controlled by user in setup)
    #define VALUE_ASF_PETS_ONLY                     0x1         //PETS only (ASF 1.0)
    #define VALUE_ASF_FULL                          0x2         //all PETS and RMCP (ASF 2.0)
    #define VALUE_DASH_ENABLED                      0x3         //DASH (Bios Management) and ASF 2.0
// RETIRED - DO NO USE                          0x0641
// RETIRED - DO NO USE                          0x0642
#define PID_PWD_BYPASS                          0x0643      // Password Bypass
    #define VALUE_PWD_BYP_DIS                       0x00        // Password Bypass "Disabled"
    #define VALUE_PWD_BYP_REBOOT                    0x01        // Password Bypass "Reboot Bypass"
    #define VALUE_PWD_BYP_RESUME                    0x02        // Password Bypass "Resume Bypass"
    #define VALUE_PWD_BYP_REBRES                    0x03        // Password Bypass "Reboot & Resume Bypass"
#define PID_PWD_CHANGE                          0x0644      // Password Change
#define PID_COMPUTRACE_OKTOCHANGE               0x0645      // Computrace OK to change
    #define VALUE_COMPUTRACE_OKTOCHANGE_NO          0x00        // Answer = No
    #define VALUE_COMPUTRACE_OKTOCHANGE_YES         0x01        // Answer = Yes
#define PID_LOG_CLEAR_POWER                     0x0646      // Clear Power Log Button
#define PID_LOG_CLEAR_BIOS                      0x0647      // Clear BIOS Log Button
#define PID_LOG_CLEAR_THERMAL                   0x0648      // Clear Thermal Log Button
#define PID_FFS_ENABLE                          0x0649      // Free Fall Sensor enable/disable
#define PID_BLACKTOP_FLASH_ENABLE               0x064A      // Blacktop Flash Hardware based Setup Property. DA token 2B1/2B2h
#define PID_BLACKTOP_READER_ENABLE              0x064B      // Blacktop Reader based Setup Property. DA token 28Ch/28Dh
#define PID_BLACKTOP_ARM_ENABLE                 0x064C      // Blacktop ARM (hardware) Enable/Disable Associated with DA Token 259h/25Ah
#define PID_BLACKTOP_INSTANT_ON_ENABLE          0x064D      // Blacktop ARM (Hardware) "Instant On" feature enable/disable. Stored on EC Cmos location
#define PID_BLACKTOP_SETUP_ENABLE               0x064E      // Setup Enable / Disable Property. Controls Blacktop ON Button
#define PID_BLACKTOP_SETUP_VISIBILITY           0x064F      // Setup Screen suppressif variable
//----
#define PID_BLACKTOP_INSTANT_ON_VISIBILITY      0x0650      // Setup Screen suppressif variable
#define PID_BLACKTOP_REBOOT_REQUIRED           (0x0651|PT_VOLATILE) //Reboot flag Set if BKT HW Change requires reboot (only applies if HW was changed and BKT boot was initiated on first boot)
#define PID_ENABLE_ADMIN_SETUP_LOCKOUT          0x0652      // Enable the Admin Setup Lockout feature
#define PID_ENABLE_STRONG_PASSWORDS             0x0653      // Enable Strong Passwords
#define PID_ADMIN_PWD_MIN_LEN                   0x0654      // User-selectable Password Min Len
#define PID_ADMIN_PWD_MAX_LEN                   0x0655      // User-selectable Password Min Len
#define PID_SYS_PWD_MIN_LEN                     0x0656      // User-selectable Password Min Len
#define PID_SYS_PWD_MAX_LEN                     0x0657      // User-selectable Password Min Len
#define PID_FRONT_USB_PORT_EN                   0x0658      // Enable Desktop Front USB Ports
#define PID_REAR_DUAL_USB_PORT_EN               0x0659      // Enable Desktop Rear Dual USB Ports
#define PID_REAR_QUAD_USB_PORT_EN               0x065A      // Enable Desktop Read Quad USB Ports
#define PID_ENABLE_OPTIMUS                      0x065B      // Setup Enable/Disable property for Optimus
#define PID_OPTIMUS_FLAGS                       0x065C      // Optimus flags (mainly used to enable/disable HDA)

#define PID_HDD_PROTECTION_AVAILABLE            0x265D //(0x065D | PT_WRITE_ONCE) // Hard drive protection is available //Vfr Can't expand OR operator so the W/O bit is hard-coded
#define PID_HDD_PROTECTION_ENABLE               0x065E      // Hard drive protection is enabled
#define PID_ENABLE_MULTIDISPLAY                 0x065F      // Setup Enable/Disable property for Multi-Display
//----
#define PID_WIRELESS_SUPP_WLAN                  0x0660      // Wireless Supported - WLAN
#define PID_OROM_KB_ACCESS                      0x0661      // ORom Keyboard Access
    #define VALUE_OROM_KB_ACCESS_DISABLE            0x00        // Orom Keyboard Access "Disabled"
    #define VALUE_OROM_KB_ACCESS_ENABLE             0x01        // Orom Keyboard Access "Enabled"
    #define VALUE_OROM_KB_ONETIMEACCESS             0x02        // Orom Keyboard Access Time Enable"
#define PID_RESUME_ON_PEN_DISABLE               0x0662      // Resume on Pen removal
#define PID_BLINK_MISSING_PEN_DISABLE           0x0663      // Blink on Pen missing
#define PID_TABLET_BUTTON_DISABLE               0x0664      // Tablet button
#define PID_DELL_NUMA                           0x0665      // NUMA/SMP support
#define PID_ENABLE_FX100                        0x0666      // Enable Dell FX100
#define PID_ENABLE_FX100_VISIBILITY             0x0667      // Visibility variable for Enable Dell FX100
#define PID_USB3_PORT_EN                        0x0668      // Enable USB3 Ports
#define PID_DELL_FTM                            0x0669      // Enable Fault-Tolerant Memory
#define PID_OROM_KB_ACCESS_BOOT_TIME           (0x066A|PT_VOLATILE) //Will be set when OROM keyboard access driver load, valid with one boot
#define PID_ENABLE_P25                          0x066B      // Enable Dell P25
#define PID_ENABLE_P25_VISIBILITY               0x066C      // Visibility variable for Enable Dell P25
#define PID_PREV_PSU_PSU_STATE                  0x066D      // Previous boot PSU PSU (Redundant Power Supply)state
    #define VALUE_PREV_PSU_PSU_STATE_PRIMARY        0x00    // Primary/Single power supply configuration
    #define VALUE_PREV_PSU_PSU_STATE_SECONDARY      0x01    // Secondary/Single power supply configuration
    #define VALUE_PREV_PSU_PSU_STATE_REDUNDANT      0x02    // Redundant power supply configuration
#define PID_WIRELESS_SW_WIGIG                   0x066E      // Wireless switch - WIGIG
#define PID_AC_KEYBOARD_BACKLIGHT_ENABLE        0x066F      // Keyboard Backlight Control when AC is connected (see PID_KEYBOARD_BACKLIGHT_MODE 0x0636)
//----
#define PID_HDD_REMOTE_WIPE_0                   0x0670      // GL Hdd Remote Wipe state
#define PID_INT_USB_PORT_EN                     0x0671      // Internal USB port enable
#define PID_DOCK_DP_GRAPHICS                    0x0672      // Enable DP port on Dock
#define PID_SPEAKER_ENABLE                      0x0673      // Speaker Enable
#define PID_NFC_ENABLE                          0x0674      // Near Field Communication device enable
#define PID_WIRELESS_ACTIVITY_LED_EN            0x0675      // Control lid-mounted wireless activity LED
#define PID_GLOBAL_MIC_MUTE_LED                 0x0676      // global McMute LED enable/disable
#define PID_WIRELESS_SW_WLANWIGIG               0x0677      // Wireless switch - WLAN+WiGig on M.2 card
#define PID_WIRELESS_SW_GPS_ON_WWAN             0x0678      // Wireless Switch - GPS on WWAN
#define PID_2ND_REAR_DUAL_USB_EN                0x0679
#define PID_DEDI_GPS                            0x067A      // Enable/Disable Dedicated GPS
#define PID_FN_LOCK                             0x067B      // Allow hot key sequence <Fn>+<Esc> to flip meaning of <Fn> key
#define PID_CAMERA2_ENABLE                      0x067C      // Back Camera Enable
#define PID_CAMERA2_VISIBILITY                  0x067D      // Back Camera field visibility
#define PID_CAMERA2_DEV_VEN                     (0x067E | PT_VOLATILE | PT_BOOT_SERVICE)  // Back Camera Device/Vendor ID
#define PID_CAMERA2_CONTROL                     0x067F      // Camera Hardware Control
//----
#define PID_FN_LOCK_MODE                        0x0680      // Initial/current setting of <Fn> key mode (standard or secondary)
//<PROJECT_CHANGE>* 2016/09/05 DellPublicProductionPkg_dpf1.111.0 exchange the value, keep original >>>
    #define VALUE_STANDARD                      0           // Fn keys default as normal, Fn key provides access to secondary functions
    #define VALUE_SECONDARY                     1           // Fn keys default as secondary, Fn key provides access to standard functions
//<PROJECT_CHANGE>* 2016/09/05 DellPublicProductionPkg_dpf1.111.0 exchange the value, keep original <<<

// This section contains the PIDS for the EC Backed RGB Keyboard Backlight data.
#define PID_RGB_KEYBOARD_BACKLIGHT_ACTIVE       0x0681      // Keyboard RGB Backlight Active Color Control
    #define VALUE_RGB_KBD_BACKLIGHT_WHITE           0x0000  // Keyboard RGB Backlight Active Color is White
    #define VALUE_RGB_KBD_BACKLIGHT_RED             0x0001  // Keyboard RGB Backlight Active Color is Red
    #define VALUE_RGB_KBD_BACKLIGHT_GREEN           0x0002  // Keyboard RGB Backlight Active Color is Green
    #define VALUE_RGB_KBD_BACKLIGHT_BLUE            0x0003  // Keyboard RGB Backlight Active Color is Blue
    #define VALUE_RGB_KBD_BACKLIGHT_CUSTOM1         0x0004  // Keyboard RGB Backlight Active Color is Custom1
    #define VALUE_RGB_KBD_BACKLIGHT_CUSTOM2         0x0005  // Keyboard RGB Backlight Active Color is Custom2
    #define DEF_RGB_KBD_BACKLIGHT_ACTIVE            VALUE_RGB_KBD_BACKLIGHT_WHITE
    #define RGB_KBD_BACKLIGHT_FIXED_COLORS          4       // Number of fixed colors
    #define RGB_KBD_BACKLIGHT_CUSTOM_COLORS         2       // Number of custom colors
#define PID_RGB_KBD_BACKLIGHT_ENABLE            0x0682      // Keyboard RGB Backlight Color Enable
    #define MASK_RGB_KBD_BACKLIGHT_ENABLE_WHITE     0x0001  // Keyboard RGB Backlight Color Enable Mask for White
    #define MASK_RGB_KBD_BACKLIGHT_ENABLE_RED       0x0002  // Keyboard RGB Backlight Color Enable Mask for Red
    #define MASK_RGB_KBD_BACKLIGHT_ENABLE_GREEN     0x0004  // Keyboard RGB Backlight Color Enable Mask for Green
    #define MASK_RGB_KBD_BACKLIGHT_ENABLE_BLUE      0x0008  // Keyboard RGB Backlight Color Enable Mask for Blue
    #define MASK_RGB_KBD_BACKLIGHT_ENABLE_CUSTOM1   0x0010  // Keyboard RGB Backlight Color Enable Mask for Custom Color #1
    #define MASK_RGB_KBD_BACKLIGHT_ENABLE_CUSTOM2   0x0020  // Keyboard RGB Backlight Color Enable Mask for Custom Color #2
    #define VALUE_RGB_KBD_BACKLIGHT_ENABLE_MIN      0x00    // Minimum value for RGB Keyboard backlight enable
    #define VALUE_RGB_KBD_BACKLIGHT_ENABLE_MAX      0x3F    // Maximum value for RGB Keyboard backlight enable
    #define DEF_RGB_KBD_BACKLIGHT_ENABLE_WHITE      0x01    // By default white   is enabled  in the FN-C sequence
    #define DEF_RGB_KBD_BACKLIGHT_ENABLE_RED        0x01    // By default red     is enabled  in the FN-C sequence
    #define DEF_RGB_KBD_BACKLIGHT_ENABLE_GREEN      0x01    // By default green   is enabled  in the FN-C sequence
    #define DEF_RGB_KBD_BACKLIGHT_ENABLE_BLUE       0x01    // By default blue    is enabled  in the FN-C sequence
    #define DEF_RGB_KBD_BACKLIGHT_ENABLE_CUSTOM1    0x00    // By default custom1 is disabled in the FN-C sequence
    #define DEF_RGB_KBD_BACKLIGHT_ENABLE_CUSTOM2    0x00    // By default custom2 is disabled in the FN-C sequence
    #define DEF_RGB_KBD_BACKLIGHT_ENABLE           (DEF_RGB_KBD_BACKLIGHT_ENABLE_WHITE+(DEF_RGB_KBD_BACKLIGHT_ENABLE_RED<<1)+(DEF_RGB_KBD_BACKLIGHT_ENABLE_GREEN<<2)+(DEF_RGB_KBD_BACKLIGHT_ENABLE_BLUE<<3)+(DEF_RGB_KBD_BACKLIGHT_ENABLE_CUSTOM1<<4)+(DEF_RGB_KBD_BACKLIGHT_ENABLE_CUSTOM2<<5))
#define PID_RGB_KBD_BACKLIGHT_CUSTOM1           0x0683      // Keyboard RGB Backlight Custom Color #1
#define PID_RGB_KBD_BACKLIGHT_CUSTOM2           0x0684      // Keyboard RGB Backlight Custom Color #2
   #define VALUE_RGB_KBD_BACKLIGHT_CUSTOM_MIN      0x000000 // Minimum value for a custom color value
   #define VALUE_RGB_KBD_BACKLIGHT_CUSTOM_MAX      0xFFFFFF // Maximum value for a custom color value
   #define RGB_KBD_BACKLIGHT_COLOR_COMPONENTS      3        // Number of components in a custom color
   #define DEF_RGB_KBD_BACKLIGHT_CUSTOM1_RED       0xFF     // Default red   component value for custom color #1
   #define DEF_RGB_KBD_BACKLIGHT_CUSTOM1_GREEN     0xFF     // Default green component value for custom color #1
   #define DEF_RGB_KBD_BACKLIGHT_CUSTOM1_BLUE      0x00     // Default blue  component value for custom color #1
   #define DEF_RGB_KBD_BACKLIGHT_CUSTOM1           ((DEF_RGB_KBD_BACKLIGHT_CUSTOM1_RED<<16)+(DEF_RGB_KBD_BACKLIGHT_CUSTOM1_GREEN<<8)+DEF_RGB_KBD_BACKLIGHT_CUSTOM1_BLUE)
   #define DEF_RGB_KBD_BACKLIGHT_CUSTOM2_RED       0xFF     // Default red   component value for custom color #1
   #define DEF_RGB_KBD_BACKLIGHT_CUSTOM2_GREEN     0xFF     // Default green component value for custom color #1
   #define DEF_RGB_KBD_BACKLIGHT_CUSTOM2_BLUE      0x00     // Default blue  component value for custom color #1
   #define DEF_RGB_KBD_BACKLIGHT_CUSTOM2           ((DEF_RGB_KBD_BACKLIGHT_CUSTOM2_RED<<16)+(DEF_RGB_KBD_BACKLIGHT_CUSTOM2_GREEN<<8)+DEF_RGB_KBD_BACKLIGHT_CUSTOM2_BLUE)

// This PID is the write-once upsell PID that enables (if present and set to 1)
// or disables (if not present or not set to 1) the entire RGB Keyboard Backlight feature.
#define PID_RGB_KBD_BACKLIGHT_CONTROL           0x2685      // (PT_WRITE_ONCE) Display control for Keyboard Backlight

#define PID_GSET_ENTRY_DETECT                  (0x0686 | PT_VOLATILE | PT_BOOT_SERVICE)       // Inside Gset?
    #define VALUE_GSET_ENTRY_DETECT_USER            0x01    // User level privileges
    #define VALUE_GSET_ENTRY_DETECT_ADMIN           0x10    // Admin level privileges

// This section contains the PIDS for the non-EC Backed RGB Keyboard Backlight data.
// These PIDs are all portions of the their similarly named EC backed counterparts.
// These PIDs all use accessor functions to interact with the EC backed values.
#define PID_RGB_KBD_BACKLIGHT_ENABLE_WHITE      0x0687      // Keyboard RGB Backlight White Color     Enable
#define PID_RGB_KBD_BACKLIGHT_ENABLE_RED        0x0688      // Keyboard RGB Backlight Red   Color     Enable
#define PID_RGB_KBD_BACKLIGHT_ENABLE_GREEN      0x0689      // Keyboard RGB Backlight Green Color     Enable
#define PID_RGB_KBD_BACKLIGHT_ENABLE_BLUE       0x068A      // Keyboard RGB Backlight Blue  Color     Enable
#define PID_RGB_KBD_BACKLIGHT_ENABLE_CUSTOM1    0x068B      // Keyboard RGB Backlight Custom Color #1 Enable
#define PID_RGB_KBD_BACKLIGHT_ENABLE_CUSTOM2    0x068C      // Keyboard RGB Backlight Custom Color #2 Enable
    #define VALUE_RGB_KBD_BACKLIGHT_COLOR_DISABLED  0x0000  // RGB Keyboard Backlight color is disabled in the FN-C sequence
    #define VALUE_RGB_KBD_BACKLIGHT_COLOR_ENABLED   0x0001  // RGB Keyboard Backlight color is enabled  in the FN-C sequence
#define PID_RGB_KBD_BACKLIGHT_CUSTOM1_RED       0x868D      // (PT_VOLATILE) Keyboard RGB Backlight Custom Color #1 Red   Component Value
#define PID_RGB_KBD_BACKLIGHT_CUSTOM1_GREEN     0x868E      // (PT_VOLATILE) Keyboard RGB Backlight Custom Color #1 Green Component Value
#define PID_RGB_KBD_BACKLIGHT_CUSTOM1_BLUE      0x868F      // (PT_VOLATILE) Keyboard RGB Backlight Custom Color #1 Blue  Component Value
//----
#define PID_RGB_KBD_BACKLIGHT_CUSTOM2_RED       0x8690      // (PT_VOLATILE) Keyboard RGB Backlight Custom Color #1 Red   Component Value
#define PID_RGB_KBD_BACKLIGHT_CUSTOM2_GREEN     0x8691      // (PT_VOLATILE) Keyboard RGB Backlight Custom Color #1 Green Component Value
#define PID_RGB_KBD_BACKLIGHT_CUSTOM2_BLUE      0x8692      // (PT_VOLATILE) Keyboard RGB Backlight Custom Color #1 Blue  Component Value
   #define VALUE_RGB_KBD_BACKLIGHT_COMPONENT_MIN    0x00    // Minimum value for any custom color component value
   #define VALUE_RGB_KBD_BACKLIGHT_COMPONENT_MAX    0xFF    // Maximum value for any custom color component value

// These PIDs are special PIDs for setting and cancelling an override of the active RGB Keyboard Backlight color.
// They are used to give the used visual feedback when they are configuring the custom colors.
#define PID_RGB_KBD_BACKLIGHT_OVERRIDE_SET      0x8693      // (PT_VOLATILE) Allows for the RGB keyboard backlight color to be overridden
#define PID_RGB_KBD_BACKLIGHT_OVERRIDE_CLEAR    0x8694      // (PT_VOLATILE) Cancels the RGB keyboard backlight override

#define PID_MIC_EN_VISIBILITY                   0x0695      //
#define PID_SPEAKER_EN                          0x0696      // Deprecated/Retired - Do not use. Definition kept for D7 platforms. Should be freed when possible.
#define PID_SPEAKER_EN_VISIBILITY               0x0697      // Internal Speaker Visible
#define PID_USB_DOCK_DEVICES_DIS                0x0698      // Disable ports and devices that are on the Docking station
#define PID_TOUCHSCREEN                         0x0699      // Touchscreen
#define PID_REAR_USB_PORT1_EN                   0x069A      // individual usb port disablement
#define PID_REAR_USB_PORT2_EN                   0x069B      // individual usb port disablement
#define PID_REAR_USB_PORT3_EN                   0x069C      // individual usb port disablement
#define PID_REAR_USB_PORT4_EN                   0x069D      // individual usb port disablement
#define PID_REAR_USB_PORT5_EN                   0x069E      // individual usb port disablement
#define PID_REAR_USB_PORT6_EN                   0x069F      // individual usb port disablement
//----
#define PID_SIDE_USB_PORT_EN                    0x06A0      // individual usb port disablement
#define PID_SIDE_USB_PORT1_EN                   0x06A1      // individual usb port disablement
#define PID_SIDE_USB_PORT2_EN                   0x06A2      // individual usb port disablement
#define PID_FRONT_USB_PORTS_EN                  0x06A3      // individual usb port disablement
#define PID_FRONT_USB_PORT1_EN                  0x06A4      // individual usb port disablement
#define PID_FRONT_USB_PORT2_EN                  0x06A5      // individual usb port disablement
#define PID_REAR_HEXA_USB_PORT_EN               0x06A6      // Enable Desktop Read HEXA USB Ports
#define PID_REAR_USB_PORTS_EN                   0x06A7      // individual usb port disablement
#define PID_PCI_MMIO_SIZE                       0x06A8      // Memory space available for PCI MMIO
    #define PCI_MMIO_SMALL                      0x00        // Small PCI MMIO Size
    #define PCI_MMIO_LARGE                      0x01        // Large PCI MMIO Size
#define PID_THUNDERBOLT                         0x06A9      // Enable Thunderbolt support
    #define VALUE_TBT_DIS                           0
    #define VALUE_TBT_EN                            1
#define PID_THUNDERBOLT_SECURITY_LEVEL          0x06AA      // Thunderbolt security level
    #define VALUE_TBT_SEC_LVL_1                     1
    #define VALUE_TBT_SEC_LVL_2                     2
    #define VALUE_TBT_SEC_LVL_3                     3
    #define VALUE_TBT_SEC_LVL_4                     4
#define PID_UNMANAGED_NIC                       0x06AB      // Enable Unmanaged NIC (USB network card)
    #define VALUE_NIC_DIS                           0
    #define VALUE_NIC_EN                            1
    #define VALUE_NIC_PXE                           2
#define PID_GSET_DATA_WIPE_ENABLE               0xC6AC      // To be used in GSET as an indicator for data wipe checkbox
#define PID_DATA_WIPE_ALL_DEVICES               0x06AD      // Schedule Data Wipe for all internal storage devices
#define PID_WLAN_COUNTRY_CODE                   0x26AE      // (0x06AE | PT_WRITE_ONCE) // Enable WLAN Country Code
    #define WLAN_COUNTRY_CODE_IND               0x4944      // "ID" - Indonesia (Byte 0 = 'I', Byte 1 = 'D')
    #define WLAN_COUNTRY_CODE_OTHER             0x4150      // "AP" - Rest of world (Byte 0 = 'A', Byte 1 = 'P')
                                                            // note AP is for "African Regional Intellectual Property Organization" ISO 3166-1
                                                            // By spec we are to use this for the rest of the world
#define PID_REAR_USB_PORT7_EN                   0x06AF      // individual usb port disablement
//----
#define PID_REAR_USB_PORT8_EN                   0x06B0      // individual usb port disablement
#define PID_REAR_USB_PORT9_EN                   0x06B1      // individual usb port disablement
#define PID_REAR_USB_PORT10_EN                  0x06B2      // individual usb port disablement
#define PID_SIDE_USB_PORT3_EN                   0x06B3      // individual usb port disablement
#define PID_SIDE_USB_PORT4_EN                   0x06B4      // individual usb port disablement
#define PID_SIDE_USB_PORT5_EN                   0x06B5      // individual usb port disablement
#define PID_SIDE_USB_PORT6_EN                   0x06B6      // individual usb port disablement
#define PID_SIDE_USB_PORT7_EN                   0x06B7      // individual usb port disablement
#define PID_SIDE_USB_PORT8_EN                   0x06B8      // individual usb port disablement
#define PID_SIDE_USB_PORT9_EN                   0x06B9      // individual usb port disablement
#define PID_SIDE_USB_PORT10_EN                  0x06BA      // individual usb port disablement
#define PID_FRONT_USB_PORT3_EN                  0x06BB      // individual usb port disablement
#define PID_FRONT_USB_PORT4_EN                  0x06BC      // individual usb port disablement
#define PID_FRONT_USB_PORT5_EN                  0x06BD      // individual usb port disablement
#define PID_FRONT_USB_PORT6_EN                  0x06BE      // individual usb port disablement
#define PID_FRONT_USB_PORT7_EN                  0x06BF      // individual usb port disablement
//----
#define PID_FRONT_USB_PORT8_EN                  0x06C0      // individual usb port disablement
#define PID_FRONT_USB_PORT9_EN                  0x06C1      // individual usb port disablement
#define PID_FRONT_USB_PORT10_EN                 0x06C2      // individual usb port disablement
#define PID_PERM_DIS_SIDE_USB_PORT              0x26C3      // (PT_WRITE_ONCE | 0x06C3) -- PID is used in VFR
#define PID_PERM_DIS_REAR_USB_PORT              0x26C4      // (PT_WRITE_ONCE | 0x06C4) -- PID is used in VFR
#define PID_INTEL_IRMT                          0x06C5
#define PID_SD_CARD_READ_ONLY                   0x06C6
#define PID_DELL_SNOOP_MODE                     0x06C7      // CPU snoop policy for dual-CPU systems
    #define VALUE_HOME_SNOOP                    0x00
    #define VALUE_EARLY_SNOOP                   0x01
#define PID_DELL_ISOC_MODE                      0x06C8      // Optimize for memory bandwidth vs latency
    #define VALUE_SYS_ISOC_DIS                  0x00
    #define VALUE_SYS_ISOC_ENA                  0x01
#define PID_SGX_EPOCH                           0x06C9
#define PID_AC_KEYBOARD_BACKLIGHT           0x06CA
#define PID_BATT_KEYBOARD_BACKLIGHT         0x06CB
    #define VALUE_KBLT_05SEC                0x05 // 5 seconds
    #define VALUE_KBLT_10SEC                0x0A // 10 seconds
    #define VALUE_KBLT_15SEC                0x0F // 15 seconds
    #define VALUE_KBLT_30SEC                0x1E // 30 seconds
    #define VALUE_KBLT_01MIN                0x41 // 1 minute
    #define VALUE_KBLT_05MIN                0x45 // 5 minutes
    #define VALUE_KBLT_15MIN                0x4F // 15 minutes
    #define VALUE_KBLT_NEVER                0xBF // never, KB backlight always stays on
#define PID_SGX_ENABLE                          0x06CC
    #define VALUE_SGX_DISABLE               0    // SGX Disable
    #define VALUE_SGX_ENABLE                1    // SGX Enable
    #define VALUE_SGX_SW_CONTROL            2    // Software Control
#define PID_SGX_PRM_SIZE                        0x06CD
    #define PID_SGX_PRM_SIZE_32MB               0
    #define PID_SGX_PRM_SIZE_64MB               1
    #define PID_SGX_PRM_SIZE_128MB              2
#define PID_MEDIA_CARD_ENABLE                   0x06CE
#define PID_DATA_WIPE_VISIBILITY                0x06CF      // Data wipe token visibility
//----
#define PID_TOKEN_DATA_WIPE_ENABLE              0x06D0      // Token initiated Data wipe
#define PID_PERM_DIS_MEDIA_CARD                 0x26D1      // (0x06D1 | PT_WRITE_ONCE)
#define PID_HEADLESS_OPERATION                  0x06D2
    #define VALUE_HEADLESS_DISABLE                 0x0
    #define VALUE_HEADLESS_WARNINGS                0x1
    #define VALUE_HEADLESS_ERRORS                  0x2
#define PID_GPS_ON_WWAN_RADIO                   0x06D3      // embedded GPS-on-WWAN radio
#define PID_HOT_SWAP_BATTERY_INFO               0x06D4
#define PID_PRE_1ST_PWR_ON_DATE_CHARGE_LIMITED  0x06D5
#define PID_DP_PORT_D_SELECTION                 0x06D6      // display output selection on DisplayPort#D
#define PID_OVERRIDE_BATTERY_CHARGING_LIMIT     0x06D7
#define PID_ADVANCED_SETUP                      0x06D8
#define PID_OVERRIDE_BATTERY_CHARGING_LIMIT_INIT    0x06D9
#define PID_SEC_UEFI_BOOT_PATHS                 0x06DA
    #define VALUE_SEC_UEFI_BOOT_PATH_NEVER         0x0
    #define VALUE_SEC_UEFI_BOOT_PATH_ALWAYS        0x1
    #define VALUE_SEC_UEFI_BOOT_PATH_EXCPT_INT_HDD 0x2

#define PID_ATTEMPT_LEGACY_BOOT                 0x06DB
#define PID_MFG_MODE_PXE_ATTRIBUTE              0x06DC
    #define VALUE_MFG_MODE_PXE_RSVD             0x00
    #define VALUE_MFG_MODE_LEGACY_LOM           0x01
    #define VALUE_MFG_MODE_LEGACY_USB           0x02
    #define VALUE_MFG_MODE_UEFI_LOM             0x03
    #define VALUE_MFG_MODE_UEFI_USB             0x04

#define PID_SEC_AUDIT_DISPLAY_DISABLE           0x06DD

#define PID_TYPEC_POWER_SELECTION_OPTION               0x06DE
    #define VALUE_TYPEC_POWER_SELECTION_OPTION_7W5          0
    #define VALUE_TYPEC_POWER_SELECTION_OPTION_15W          1

#define PID_MEMORY_PERFORMANCE_MONITOR          0x06DF
//----
#define PID_SD_CARD_BOOT                        0x06E0
#define PID_FULL_SCREEN_LOGO                    0x06E1  // Show full screen logo during the BIOS POST
#define PID_CHINA_SKU                          (0x06E2 | PT_WRITE_ONCE)    // Indicates the China SKU has been selected, primarily for the China HDD Protection feature
#define PID_CHINA_HDD_PROTECT_PRESENT           0x06E3  // Indicates if China HDD protection module is present
#define PID_DELL_CLEAR_RMT_LOG                  0x06E4      // Clear Log Memory
//----
// RSA (Reliablbility Availability Serviceability) support for Precision products
#define PID_RAS_MEMORY                          0x06E5  
#define PID_RAS_PCIE                            0x06E6
#define PID_RAS_CPU                             0x06E7

///////////////////////////////////////////////////////////
// PID 0x06E8 TO 0x06FF Available for future use
///////////////////////////////////////////////////////////

// Some Suppress/Grayout variable defs
#define PID_LPT_VISIBILITY                      0x0700       // Suppressif variable for the LPT port
#define PID_SERIAL_VISIBILITY                   0x0701       // Suppressif variable for the Serial port
#define PID_FFS_VISIBILITY                      0x0702       // Free Fall Sensor visibility
#define PID_TEMP_ME_DISABLE                     0x0703       // Temporarily disable the ME on the next boot
    #define VALUE_TEMP_ME_DISABLE_CLEAR             0x00        // ME not disabled
    #define VALUE_TEMP_ME_DISABLE_SET               0x01        // ME disabled
#define PID_DELAYED_ME_BIOSACTION               0x0704       // Delay ME NPCR reset until after EOP message
    #define VALUE_ME_RESET_DONE                     0x00        // ME NPCR not needed
    #define VALUE_ME_RESET_PENDING                  0x01        // ME NPCR should be done after EOP
#define PID_IMGSER_LOOKUP_METHOD                0x0705      // Image Server Lookup Method
    #define VALUE_IMGSER_STATIC_IP                  0x00
    #define VALUE_IMGSER_DNS                        0x01
#define PID_IMGSER_CLIENT_DHCP                  0x0706      // Image Server Client DHCP
    #define VALUE_IMGSER_CLNT_STATIC_IP             0x00
    #define VALUE_IMGSER_CLNT_DHCP_IP               0x01
#define PID_FAN0_PRESENT_STATUS                 0x0707      // Fan0 present status
#define PID_FAN1_PRESENT_STATUS                 0x0708      // Fan1 present status
#define PID_FAN2_PRESENT_STATUS                 0x0709      // Fan2 present status
#define PID_FAN3_PRESENT_STATUS                 0x070A      // Fan3 present status
#define PID_FAN4_PRESENT_STATUS                 0x070B      // Fan4 present status
    #define SM_COOL_DEV_TYPE_FAN                    0x03        // Device type fan
    #define SM_COOL_DEV_TYPE_PWR                    0x07        // Device type pwr supply fan
    #define SM_COOL_STATUS_OK                       0x60        // Cooling status ok
    #define SM_COOL_STATUS_NONCRIT                  0x80        // Cooling status warning
    #define SM_COOL_STATUS_CRIT                     0xA0        // Cooling status warning
                                                                // 4:0  device type
                                                                //      00001  other
                                                                //      00010  unknown
                                                                //      00011  fan
                                                                //      00100  centrifugal blower
                                                                //      00101  chip fan
                                                                //      00110  cabinet fan
                                                                //      00111  power supply fan
                                                                //      01000  heat pipe
                                                                //      01001  integrated refrigeration
                                                                //      10100  active cooling
                                                                //      10101  passive cooling
                                                                // 7:5  status
                                                                //      001    other (do not use)
                                                                //      010    unknown (do not use)
                                                                //      011    ok (within thresholds)
                                                                //      100    non-critical (warning)
                                                                //      101    critical (pwr-off necessary)
                                                                //      110    non-recoverable (probe failure)
    // For some reason, the SMBIOS fan status is reported differently in the 1Bh structure than in the PresentStatus
    // token.  The token reports only the status in bits [2:0].  The structure reports the status in bits [7:5] and
    // the cooling device type in bits [4:0]. Use the SM_STATUS_BIT_START definition to move the status up or down,
    // depending on your reference.
    #define SM_STATUS_BIT_START                     5       // Shift right 5 bits to get just the status
    #define SM_COOL_TOKEN_STATUS_OK                (SM_COOL_STATUS_OK >> SM_STATUS_BIT_START)
    #define SM_COOL_TOKEN_STATUS_NONCRIT           (SM_COOL_STATUS_NONCRIT >> SM_STATUS_BIT_START)
    #define SM_COOL_TOKEN_STATUS_CRIT              (SM_COOL_STATUS_CRIT >> SM_STATUS_BIT_START)

#define PID_GSET_TEST1                          0x070C      // GSet Test 1
#define PID_GSET_TEST2                          0x070D      // GSet Test 2
#define PID_GSET_TEST3                          0x070E      // GSet Test 3
#define PID_GSET_TEST4                          0x070F      // GSet Test 4

#define PID_PRI_BAT_CHARGE_MODE                 0x0710     // Primary battery charging mode
    #define BAT_MODE_STD                            1      // Standard Charge
    #define BAT_MODE_EXP                            2      // Express Charge
    #define BAT_MODE_AC                             3      // Predominately AC use
    #define BAT_MODE_AUTO                           4      // Auto Mode
    #define BAT_MODE_CUSTOM                         5      // Custom Mode
    #define BAT_MODE_PERM_LONG_LIFE                 6      // Permanent long life mode (one time factory setting)
    #define BAT_MODE_ADVANCED                       7      // Advanced Charging Mode
#define PID_PRI_BAT_CHARGE_LOWER_LIMIT          0x0711     // Primary battery custom charge lower limit (BCD value)
#define PID_PRI_BAT_CHARGE_UPPER_LIMIT          0x0712     // Primary battery custom charge upper limit (BCD value)

#define PID_SLICE_BAT_CHARGE_MODE               0x0713     // Battery slice charging mode
    #define SLICE_BAT_STANDARD_CHARGE               0x01
    #define SLICE_BAT_EXPRESS_CHARGE                0x02
#define PID_SLICE_BAT_CHARGE_LOWER_LIMIT        0x0714     // Battery slice custom charge lower limit
#define PID_SLICE_BAT_CHARGE_UPPER_LIMIT        0x0715     // Battery slice custom charge upper limit

#define PID_BAY_BAT_CHARGE_MODE                 0x0716     // Module bay battery charging mode
#define PID_BAY_BAT_CHARGE_LOWER_LIMIT          0x0717     // Module bay battery custom charge lower limit
#define PID_BAY_BAT_CHARGE_UPPER_LIMIT          0x0718     // Module bay battery custom charge upper limit
#define PID_IFFS_BATT_WAKE_LIMIT                0x0719     // Intel Radip Start critical battery wake
#define PID_IFFS_TIMER_WAKE_LIMIT               0x071A     // Intel Radip Start S3 wake time
#define PID_PRIM_BATT_REV                       0x071B
    #define VALUE_LEGACY                            0
    #define VALUE_BATTMAN                           1
    #define VALUE_ROBIN                             2

#define PID_PRI_BAT_PREM_LONG_LIFE_MODE         0x071C     // enable / disable the primary battery permanent long life mode.

#define PID_DOCK_BAT_CHARGE_MODE                0x071D     // Dock battery charging mode
#define PID_DOCK_BAT_CHARGE_LOWER_LIMIT         0x071E     // Dock battery custom charge lower limit (BCD value)
#define PID_DOCK_BAT_CHARGE_UPPER_LIMIT         0x071F     // Dock battery custom charge upper limit (BCD value)

#define PID_WAKE_ON_USB_FROM_S4                 0x0720      // Wake on USB From S4

#define PID_SYS_AUTH_TAG                        0x0721      // System Authentication Tag

#define PID_TRINITY_DOCK_THUNDERBOLT_BOOT_SUPPORT           0x0722  // Enable Thunderbolt Boot Support
#define PID_TRINITY_DOCK_THUNDERBOLT_PREBOOT_OROM_SUPPORT   0x0723  // Enable Pre-boot Modules for Thunderbolt (and PCIe devices behind Thunderbolt)
#define PID_TRINITY_DOCK_ALWAYS_ENABLE_DELL_TBT_DOCK        0x0724  // Enable Dell Type-C Thunderbolt Docks Even When Thunderbolt is Disabled
#define PID_AUTO_BOOT_ON_TRINITY_DOCK_ATTACH                0x0725
#define PID_SEC_BAT_PREM_LONG_LIFE_MODE         0x0726     // enable / disable the secondary battery permanent long life mode
// DIFFERS FROM GEN6B!!  #define PID_SECD_BATT_REV                       0x0727
#define PID_WYSE_MAC_STRING                     0x0727      // Wyse Mac String
#define PID_WYSE_SECURITY_STRING                0x0728      // Wyse Security String
#define PID_WYSE_HARDWARE_REVISION_STRING       0x0729      // Wyse Hardware Revision String
#define PID_WYSE_SERIAL_NUMBER_STRING           0x072A      // Wyse Serial Number String
#define PID_WYSE_FLAG                           0x072B      // Wyse Flag
#define PID_WYSE_PRODUCT_TYPE                   0x072C      // Wyse Product Type
#define PID_SFP_ENABLE                          0x072D      // Wyse SFP enable
#define PID_SFP_WOL_ENABLE                      0x072E      // Wyse SFP WOL enable

#define PID_SERIAL1_VISIBILITY                  0x072F      // Suppressif variable for the Serial 1 port (AMI needed)
#define PID_SERIAL2_VISIBILITY                  0x0730      // Suppressif variable for the Serial 2 port (AMI needed)

#define PID_GRAPHIC_SPEC_MODE                   0x0731       // Dell Graphics Beahvior Specification Addendum of Display Implementation for Miramar
#define PID_USB_PROVISION                       0x0732      // Enable/Disable USB Key Provisioning

#define PID_MASTER_PASSWORD_LOCKOUT             0x0733

///////////////////////////////////////////////////////////
// PID 0x0734 TO 0x08FF Available for future use
///////////////////////////////////////////////////////////

/*
********************************************************************************************
********************************************************************************************
** PLATFORM BUILDS MUST NOT MODIFY THIS FILE.  PLATFORM BUILDS MUST NOT MODIFY THIS FILE. **
**                                                                                        **
** These definitions must maintain uniqueness.                                            **
**                                                                                        **
** Dell Provided Features and Independent BIOS Vendor and Independent Hardware Vendor    **
**  must all make use of this file to build against, and the golden master will be        **
**  maintained by Dell because the Dell Property ID is subject to Dell governance.        **
**                                                                                        **
** Please submit any required changes back to Dell Provided Features for inclusion, which **
**  will permit "locking" the file. The intention of this requriement is not to impede    **
**  access but to guarantee that no two properties collide.                               **
********************************************************************************************
********************************************************************************************
*/

// ACPI Variables
#define PID_ACPI_AUTO                           0x0900      // ACPI Auto
#define PID_ACPI_HIBERNATE                      0x0901      // ACPI Hibernate
#define PID_ACPI_PTID_SUPP                      0x0902      // ACPI PTID Support
#define PID_ACPI_SLEEP_STATE                    0x0903      // ACPI Sleep State
#define PID_ACPI_S3_RSM_VID_REP                 0x0904      // ACPI S3 Resume Video Repost
#define PID_ACPI_PCIE_NATIVE_MODE               0x0905      // ACPI PCI Express Native Mode
#define PID_ACPI_NATIVE_ASPM_EN                 0x0906      // ACPI Native ASPM Enable

///////////////////////////////////////////////////////////
// PID 0x0907 TO 0x09FF Available for future use
///////////////////////////////////////////////////////////

// ICH Variables
#define PID_ICH_LAN_EN                          0x0A00
#define PID_ICH_PXE_ROM                         0x0A01
#define PID_ICH_HPET_EN                         0x0A02
#define PID_ICH_HPET_BOOT_TIME                  0x0A03
#define PID_ICH_SMBUS_EN                        0x0A04
#define PID_ICH_FN_4_EN                         0x0A05
#define PID_ICH_PCI_CLKRUN                      0x0A06
#define PID_ICH_AZALIA_EN                       0x0A07
    #define     ICH_AZALIA_DISABLE                  0x00
    #define     ICH_AZALIA_ENABLE                   0x01
    #define     ICH_AZALIA_AUTO                     0x02
#define PID_ICH_AZALIA_PME                      0x0A08
#define PID_ICH_AZALIA_VCI_EN                   0x0A09

///////////////////////////////////////////////////////////
// PID 0x0A0A TO 0x0A0F Available for future use
///////////////////////////////////////////////////////////

#define PID_ICH_USB_11_1_EN                     0x0A10
#define PID_ICH_USB_11_2_EN                     0x0A11
#define PID_ICH_USB_11_3_EN                     0x0A12
#define PID_ICH_USB_11_4_EN                     0x0A13
#define PID_ICH_USB_11_5_EN                     0x0A14
#define PID_ICH_USB_11_6_EN                     0x0A15
#define PID_ICH_USB_11_6_REMAP                  0x0A16

///////////////////////////////////////////////////////////
// PID 0x0A17 TO 0x0A1F Available for future use
///////////////////////////////////////////////////////////

#define PID_ICH_USB20_1                         0x0A20
#define PID_ICH_USB20_2                         0x0A21
#define PID_ICH_USB_PER_PORT_CTRL               0x0A22

///////////////////////////////////////////////////////////
// PID 0x0A23 TO 0x0A2F Available for future use
///////////////////////////////////////////////////////////

#define PID_ICH_USB_PORT0_EN                    0x0A30
#define PID_ICH_USB_PORT1_EN                    0x0A31
#define PID_ICH_USB_PORT2_EN                    0x0A32
#define PID_ICH_USB_PORT3_EN                    0x0A33
#define PID_ICH_USB_PORT4_EN                    0x0A34
#define PID_ICH_USB_PORT5_EN                    0x0A35
#define PID_ICH_USB_PORT6_EN                    0x0A36
#define PID_ICH_USB_PORT7_EN                    0x0A37
#define PID_ICH_USB_PORT8_EN                    0x0A38
#define PID_ICH_USB_PORT9_EN                    0x0A39
#define PID_ICH_USB_PORT10_EN                   0x0A3A
#define PID_ICH_USB_PORT11_EN                   0x0A3B

///////////////////////////////////////////////////////////
// PID 0x0A3C TO 0x0A4F Available for future use
///////////////////////////////////////////////////////////

#define PID_ICH_HDC_MODE                        0x0A50
#define PID_ICH_HDC_HOT_PLUG_P0                 0x0A51
#define PID_ICH_HDC_MULT_P0                     0x0A52
#define PID_ICH_HDC_HOT_PLUG_P1                 0x0A53
#define PID_ICH_HDC_MULT_P1                     0x0A54
#define PID_ICH_HDC_INTERLOCK_P1                0x0A55
#define PID_ICH_HDC_ESATA_P4                    0x0A56
#define PID_ICH_HDC_MULT_P4                     0x0A57
#define PID_ICH_HDC_HOT_PLUG_P4                 0x0A58
#define PID_ICH_HDC_ESATA_P5                    0x0A59
#define PID_ICH_HDC_HOT_PLUG_P5                 0x0A5A
#define PID_ICH_HDC_MULT_P5                     0x0A5B
#define PID_ICH_CLK_SS_EN                       0x0A5C
#define PID_ICH_CRID_EN                         0x0A5D
#define PID_ICH_STATE_AFT_G3                    0x0A5E
#define PID_ICH_CRID_KEY                        0x0A5F

///////////////////////////////////////////////////////////
// PID 0x0A60 TO 0x0A6F Available for future use
///////////////////////////////////////////////////////////

#define PID_ICH_PCIROOTPORTEN_0                 0x0A70
#define PID_ICH_PCIROOTPORTASPM_0               0x0A71
#define PID_ICH_PCIROOTPORTVC1_0                0x0A72
#define PID_ICH_PCIROOTPORTASPMAUTO_0           0x0A73
#define PID_ICH_PCIROOTPORTASPML0S_0            0x0A74
#define PID_ICH_PCIROOTPORTASPML1_0             0x0A75
#define PID_ICH_PCIROOTPORTEXTSYNCH_0           0x0A76
#define PID_ICH_PCIROOTPORTURE_0                0x0A77
#define PID_ICH_PCIROOTPORTFEE_0                0x0A78
#define PID_ICH_PCIROOTPORTNFE_0                0x0A79
#define PID_ICH_PCIROOTPORTCEE_0                0x0A7A
#define PID_ICH_PCIROOTPORTCTD_0                0x0A7B
#define PID_ICH_PCIROOTPORTPIE_0                0x0A7C
#define PID_ICH_PCIROOTPORTSFE_0                0x0A7D
#define PID_ICH_PCIROOTPORTSNE_0                0x0A7E
#define PID_ICH_PCIROOTPORTSCE_0                0x0A7F
//----
#define PID_ICH_PCIROOTPORTPMCE_0               0x0A80
#define PID_ICH_PCIROOTPORTHPCE_0               0x0A81
#define PID_ICH_PCIROOTPORTTC_0                 0x0A82
#define PID_ICH_EXTRABUSRSVD_0                  0x0A83
#define PID_ICH_PCIEMEMRSVD_0                   0x0A84
#define PID_ICH_PCIEIORSVD_0                    0x0A85
#define PID_ICH_EXTRABUSRSV2_0                  0x0A86
#define PID_ICH_PCIROOTPORTEN_1                 0x0A87
#define PID_ICH_PCIROOTPORTASPM_1               0x0A88
#define PID_ICH_PCIROOTPORTVC1_1                0x0A89
#define PID_ICH_PCIROOTPORTASPMAUTO_1           0x0A8A
#define PID_ICH_PCIROOTPORTASPML0S_1            0x0A8B
#define PID_ICH_PCIROOTPORTASPML1_1             0x0A8C
#define PID_ICH_PCIROOTPORTEXTSYNCH_1           0x0A8D
#define PID_ICH_PCIROOTPORTURE_1                0x0A8E
#define PID_ICH_PCIROOTPORTFEE_1                0x0A8F
//----
#define PID_ICH_PCIROOTPORTNFE_1                0x0A90
#define PID_ICH_PCIROOTPORTCEE_1                0x0A91
#define PID_ICH_PCIROOTPORTCTD_1                0x0A92
#define PID_ICH_PCIROOTPORTPIE_1                0x0A93
#define PID_ICH_PCIROOTPORTSFE_1                0x0A94
#define PID_ICH_PCIROOTPORTSNE_1                0x0A95
#define PID_ICH_PCIROOTPORTSCE_1                0x0A96
#define PID_ICH_PCIROOTPORTPMCE_1               0x0A97
#define PID_ICH_PCIROOTPORTHPCE_1               0x0A98
#define PID_ICH_PCIROOTPORTTC_1                 0x0A99
#define PID_ICH_EXTRABUSRSVD_1                  0x0A9A
#define PID_ICH_PCIEMEMRSVD_1                   0x0A9B
#define PID_ICH_PCIEIORSVD_1                    0x0A9C
#define PID_ICH_EXTRABUSRSV2_1                  0x0A9D
#define PID_ICH_PCIROOTPORTEN_2                 0x0A9E
#define PID_ICH_PCIROOTPORTASPM_2               0x0A9F
//----
#define PID_ICH_PCIROOTPORTVC1_2                0x0AA0
#define PID_ICH_PCIROOTPORTASPMAUTO_2           0x0AA1
#define PID_ICH_PCIROOTPORTASPML0S_2            0x0AA2
#define PID_ICH_PCIROOTPORTASPML1_2             0x0AA3
#define PID_ICH_PCIROOTPORTEXTSYNCH_2           0x0AA4
#define PID_ICH_PCIROOTPORTURE_2                0x0AA5
#define PID_ICH_PCIROOTPORTFEE_2                0x0AA6
#define PID_ICH_PCIROOTPORTNFE_2                0x0AA7
#define PID_ICH_PCIROOTPORTCEE_2                0x0AA8
#define PID_ICH_PCIROOTPORTCTD_2                0x0AA9
#define PID_ICH_PCIROOTPORTPIE_2                0x0AAA
#define PID_ICH_PCIROOTPORTSFE_2                0x0AAB
#define PID_ICH_PCIROOTPORTSNE_2                0x0AAC
#define PID_ICH_PCIROOTPORTSCE_2                0x0AAD
#define PID_ICH_PCIROOTPORTPMCE_2               0x0AAE
#define PID_ICH_PCIROOTPORTHPCE_2               0x0AAF
//----
#define PID_ICH_PCIROOTPORTTC_2                 0x0AB0
#define PID_ICH_EXTRABUSRSVD_2                  0x0AB1
#define PID_ICH_PCIEMEMRSVD_2                   0x0AB2
#define PID_ICH_PCIEIORSVD_2                    0x0AB3
#define PID_ICH_EXTRABUSRSV2_2                  0x0AB4
#define PID_ICH_PCIROOTPORTEN_3                 0x0AB5
#define PID_ICH_PCIROOTPORTASPM_3               0x0AB6
#define PID_ICH_PCIROOTPORTVC1_3                0x0AB7
#define PID_ICH_PCIROOTPORTASPMAUTO_3           0x0AB8
#define PID_ICH_PCIROOTPORTASPML0S_3            0x0AB9
#define PID_ICH_PCIROOTPORTASPML1_3             0x0ABA
#define PID_ICH_PCIROOTPORTEXTSYNCH_3           0x0ABB
#define PID_ICH_PCIROOTPORTURE_3                0x0ABC
#define PID_ICH_PCIROOTPORTFEE_3                0x0ABD
#define PID_ICH_PCIROOTPORTNFE_3                0x0ABE
#define PID_ICH_PCIROOTPORTCEE_3                0x0ABF
//----
#define PID_ICH_PCIROOTPORTCTD_3                0x0AC0
#define PID_ICH_PCIROOTPORTPIE_3                0x0AC1
#define PID_ICH_PCIROOTPORTSFE_3                0x0AC2
#define PID_ICH_PCIROOTPORTSNE_3                0x0AC3
#define PID_ICH_PCIROOTPORTSCE_3                0x0AC4
#define PID_ICH_PCIROOTPORTPMCE_3               0x0AC5
#define PID_ICH_PCIROOTPORTHPCE_3               0x0AC6
#define PID_ICH_PCIROOTPORTTC_3                 0x0AC7
#define PID_ICH_EXTRABUSRSVD_3                  0x0AC8
#define PID_ICH_PCIEMEMRSVD_3                   0x0AC9
#define PID_ICH_PCIEIORSVD_3                    0x0ACA
#define PID_ICH_EXTRABUSRSV2_3                  0x0ACB
#define PID_ICH_PCIROOTPORTEN_4                 0x0ACC
#define PID_ICH_PCIROOTPORTASPM_4               0x0ACD
#define PID_ICH_PCIROOTPORTVC1_4                0x0ACE
#define PID_ICH_PCIROOTPORTASPMAUTO_4           0x0ACF
//----
#define PID_ICH_PCIROOTPORTASPML0S_4            0x0AD0
#define PID_ICH_PCIROOTPORTASPML1_4             0x0AD1
#define PID_ICH_PCIROOTPORTEXTSYNCH_4           0x0AD2
#define PID_ICH_PCIROOTPORTURE_4                0x0AD3
#define PID_ICH_PCIROOTPORTFEE_4                0x0AD4
#define PID_ICH_PCIROOTPORTNFE_4                0x0AD5
#define PID_ICH_PCIROOTPORTCEE_4                0x0AD6
#define PID_ICH_PCIROOTPORTCTD_4                0x0AD7
#define PID_ICH_PCIROOTPORTPIE_4                0x0AD8
#define PID_ICH_PCIROOTPORTSFE_4                0x0AD9
#define PID_ICH_PCIROOTPORTSNE_4                0x0ADA
#define PID_ICH_PCIROOTPORTSCE_4                0x0ADB
#define PID_ICH_PCIROOTPORTPMCE_4               0x0ADC
#define PID_ICH_PCIROOTPORTHPCE_4               0x0ADD
#define PID_ICH_PCIROOTPORTTC_4                 0x0ADE
#define PID_ICH_EXTRABUSRSVD_4                  0x0ADF
//----
#define PID_ICH_PCIEMEMRSVD_4                   0x0AE0
#define PID_ICH_PCIEIORSVD_4                    0x0AE1
#define PID_ICH_EXTRABUSRSV2_4                  0x0AE2
#define PID_ICH_PCIROOTPORTEN_5                 0x0AE3
#define PID_ICH_PCIROOTPORTASPM_5               0x0AE4
#define PID_ICH_PCIROOTPORTVC1_5                0x0AE5
#define PID_ICH_PCIROOTPORTASPMAUTO_5           0x0AE6
#define PID_ICH_PCIROOTPORTASPML0S_5            0x0AE7
#define PID_ICH_PCIROOTPORTASPML1_5             0x0AE8
#define PID_ICH_PCIROOTPORTEXTSYNCH_5           0x0AE9
#define PID_ICH_PCIROOTPORTURE_5                0x0AEA
#define PID_ICH_PCIROOTPORTFEE_5                0x0AEB
#define PID_ICH_PCIROOTPORTNFE_5                0x0AEC
#define PID_ICH_PCIROOTPORTCEE_5                0x0AED
#define PID_ICH_PCIROOTPORTCTD_5                0x0AEE
#define PID_ICH_PCIROOTPORTPIE_5                0x0AEF
//----
#define PID_ICH_PCIROOTPORTSFE_5                0x0AF0
#define PID_ICH_PCIROOTPORTSNE_5                0x0AF1
#define PID_ICH_PCIROOTPORTSCE_5                0x0AF2
#define PID_ICH_PCIROOTPORTPMCE_5               0x0AF3
#define PID_ICH_PCIROOTPORTHPCE_5               0x0AF4
#define PID_ICH_PCIROOTPORTTC_5                 0x0AF5
#define PID_ICH_EXTRABUSRSVD_5                  0x0AF6
#define PID_ICH_PCIEMEMRSVD_5                   0x0AF7
#define PID_ICH_PCIEIORSVD_5                    0x0AF8
#define PID_ICH_EXTRABUSRSV2_5                  0x0AF9
#define PID_ICH_PCIROOTPORTEN_6                 0x0AFA
#define PID_ICH_PCIROOTPORTASPM_6               0x0AFB
#define PID_ICH_PCIROOTPORTVC1_6                0x0AFC
#define PID_ICH_PCIROOTPORTASPMAUTO_6           0x0AFD
#define PID_ICH_PCIROOTPORTASPML0S_6            0x0AFE
#define PID_ICH_PCIROOTPORTASPML1_6             0x0AFF
//----
#define PID_ICH_PCIROOTPORTEXTSYNCH_6           0x0B00
#define PID_ICH_PCIROOTPORTURE_6                0x0B01
#define PID_ICH_PCIROOTPORTFEE_6                0x0B02
#define PID_ICH_PCIROOTPORTNFE_6                0x0B03
#define PID_ICH_PCIROOTPORTCEE_6                0x0B04
#define PID_ICH_PCIROOTPORTCTD_6                0x0B05
#define PID_ICH_PCIROOTPORTPIE_6                0x0B06
#define PID_ICH_PCIROOTPORTSFE_6                0x0B07
#define PID_ICH_PCIROOTPORTSNE_6                0x0B08
#define PID_ICH_PCIROOTPORTSCE_6                0x0B09
#define PID_ICH_PCIROOTPORTPMCE_6               0x0B0A
#define PID_ICH_PCIROOTPORTHPCE_6               0x0B0B
#define PID_ICH_PCIROOTPORTTC_6                 0x0B0C
#define PID_ICH_EXTRABUSRSVD_6                  0x0B0D
#define PID_ICH_PCIEMEMRSVD_6                   0x0B0E
#define PID_ICH_PCIEIORSVD_6                    0x0B0F
//----
#define PID_ICH_EXTRABUSRSV2_6                  0x0B10

///////////////////////////////////////////////////////////
// PID 0x0B11 TO 0x0BFF Available for future use
///////////////////////////////////////////////////////////

// Northbridge Variables
#define PID_MCH_IGDBOOTTYPE                     0x0C00
#define PID_MCH_LCDPANELTYPE                    0x0C01
#define PID_MCH_LCDPANELSCALING                 0x0C02
#define PID_MCH_ENABLERS2                       0x0C03
#define PID_MCH_ENABLEGFXTHERMAL                0x0C04
#define PID_MCH_IGDLCDIGMCHBLC                  0x0C05
#define PID_MCH_IGDLCDIBIA                      0x0C06
#define PID_MCH_IGDLCDSSCC                      0x0C07
#define PID_MCH_IGDTV1STANDARD                  0x0C08
#define PID_MCH_IGDTV2STANDARD                  0x0C09
#define PID_MCH_ALSENABLE                       0x0C0A
#define PID_MCH_IGDHDCPENABLE                   0x0C0B
#define PID_MCH_HDCPALGORITHM                   0x0C0C
#define PID_MCH_PAVPMODE                        0x0C0D
#define PID_MCH_LOWPOWERMODE                    0x0C0E
#define PID_MCH_PEGASPM                         0x0C0F
//----
#define PID_MCH_PEGASPMAUTO                     0x0C10
#define PID_MCH_PEGASPML0S                      0x0C11
#define PID_MCH_PEGASPML0SAGGRESSION            0x0C12
#define PID_MCH_PEGASPML1                       0x0C13
#define PID_MCH_PEGEXTSYNCH                     0x0C14
#define PID_MCH_PEGFORCEX1                      0x0C15
#define PID_MCH_ALWAYSENABLEPEG                 0x0C16
#define PID_MCH_MESETTING                       0x0C17
#define PID_MCH_TMRCMODE                        0x0C18
#define PID_MCH_TSONDIMMENABLE                  0x0C19
#define PID_MCH_TMLOCKENABLE                    0x0C1A
#define PID_MCH_IGDDVMT50PREALLOC               0x0C1B
#define PID_MCH_IGDDVMT50TOTALALLOC             0x0C1C
#define PID_MCH_GMCHDEVICE7                     0x0C1D
#define PID_MCH_GMCHCHIPSETTYPE                 0x0C1E
#define PID_MCH_ENABLEVTD                       0x0C1F
//----
#define PID_MCH_DMIASPM                         0x0C20
#define PID_MCH_DMIASPMAUTO                     0x0C21
#define PID_MCH_DMIASPML0S                      0x0C22
#define PID_MCH_DMIASPML0SL1                    0x0C23
#define PID_MCH_AUTONSG                         0x0C24
#define PID_MCH_NUMSTOPGRANT                    0x0C25
#define PID_MCH_PRIMARYDISPLAY                  0x0C26
#define PID_MCH_PREVPRIMARYDISPLAY              0x0C27
#define PID_MCH_MAXTOLUD                        0x0C28
#define PID_MCH_RESERVED_IGD_FRAMEBUFFERSIZE    0x0C29 // DWORD size

///////////////////////////////////////////////////////////
// PID 0x0C2A TO 0x0C6F Available for future use
///////////////////////////////////////////////////////////

// CPU Variables
#define PID_CPU_XDBIT                           0x0C70
#define PID_CPU_HTD                             0x0C71
#define PID_CPU_LIMITCPUID                      0x0C72
#define PID_CPU_ENHANCEDDEBUG                   0x0C73
#define PID_CPU_ENABLEGV                        0x0C74
#define PID_CPU_BOOTPSTATE                      0x0C75
#define PID_CPU_ENABLECX                        0x0C76
#define PID_CPU_ENABLECXE                       0x0C77
#define PID_CPU_ENABLEHARDC4E                   0x0C78
#define PID_CPU_ENABLETM1                       0x0C79
#define PID_CPU_ENABLETM2                       0x0C7A
#define PID_CPU_ENABLECMP                       0x0C7B
#define PID_CPU_ENABLETURBOMODE                 0x0C7C
#define PID_CPU_ENABLEXD                        0x0C7D
#define PID_CPU_ENABLEDEEPC4                    0x0C7E
#define PID_CPU_ENABLEC6                        0x0C7F
//----
#define PID_CPU_ENABLEDIGITALTHERMALSENSOR      0x0C80
#define PID_CPU_TSTATESENABLE                   0x0C81
#define PID_CPU_ENABLEPROCHOT                   0x0C82
#define PID_CPU_ENABLESMRR                      0x0C83
#define PID_CPU_VT                              0x0C84
#define PID_CPU_TXT                             0x0C85
#define PID_CPU_ENABLEDYNAMICFSB                0x0C86
#define PID_CPU_CUSTOMVIDNUMBER                 0x0C87
#define PID_CPU_CPUFAMILYMODEL                  0x0C88
#define PID_CPU_CPUEXTENDEDFAMILYMODEL          0x0C89
#define PID_CPU_CXPOPUPENABLE                   0x0C8A
#define PID_CPU_C4EXIT                          0x0C8B
#define PID_CPU_FORCESLOWC4EXIT                 0x0C8C
#define PID_CPU_ENABLEEMTTM                     0x0C8D
#define PID_CPU_ENABLEC3                        0x0C8E
#define PID_CPU_ENABLEC7                        0x0C8F
//----
#define PID_CPU_CUSTOM_STATE_RATIO_1            0x0C90
#define PID_CPU_CUSTOM_STATE_VID_1              0x0C91
#define PID_CPU_CUSTOM_STATE_RATIO_2            0x0C92
#define PID_CPU_CUSTOM_STATE_VID_2              0x0C93
#define PID_CPU_CUSTOM_STATE_RATIO_3            0x0C94
#define PID_CPU_CUSTOM_STATE_VID_3              0x0C95
#define PID_CPU_CUSTOM_STATE_RATIO_4            0x0C96
#define PID_CPU_CUSTOM_STATE_VID_4              0x0C97
#define PID_CPU_CUSTOM_STATE_RATIO_5            0x0C98
#define PID_CPU_CUSTOM_STATE_VID_5              0x0C99
#define PID_CPU_CUSTOM_STATE_RATIO_6            0x0C9A
#define PID_CPU_CUSTOM_STATE_VID_6              0x0C9B
#define PID_CPU_ENABLEC7S                       0x0C9C

///////////////////////////////////////////////////////////
// PID 0x0C9D TO 0x0CFF Available for future use
///////////////////////////////////////////////////////////

// PCI Bus Variables
#define PID_PCIBUS_PCILATENCY                   0x0D00
#define PID_PCIBUS_PCIXLATENCY                  0x0D01
#define PID_PCIBUS_OPROMPROMPT                  0x0D02
#define PID_PCIBUS_RELAXEDORDERING              0x0D03
#define PID_PCIBUS_EXTTAGFIELD                  0x0D04
#define PID_PCIBUS_NOSNOOP                      0x0D05
#define PID_PCIBUS_MAXPAYLOAD                   0x0D06
#define PID_PCIBUS_MAXREADREQUEST               0x0D07
#define PID_PCIBUS_ASPMMODE                     0x0D08
#define PID_PCIBUS_EXTENDEDSYNCH                0x0D09

///////////////////////////////////////////////////////////
// PID 0x0D0A TO 0x0D3F Available for future use
///////////////////////////////////////////////////////////

// Overclocking Variables
#define PID_OC_FLEXOVERRIDEENABLE               0x0D40
#define PID_OC_FLEXRATIOOVERRIDE                0x0D41
#define PID_OC_FLEXVIDOVERRIDE                  0x0D42
#define PID_OC_FLEXN2ENABLE                     0x0D43
#define PID_OC_BUSSPEEDENABLE                   0x0D44
#define PID_OC_PROCESSORBUSSPEEDOVERRIDE        0x0D45
#define PID_OC_MEMORYOVERCLOCKENABLE            0x0D46
#define PID_OC_MEMORYFREQUENCYOVERRIDE          0x0D47
#define PID_OC_TRAS                             0x0D48
#define PID_OC_TRCD                             0x0D49
#define PID_OC_TCL                              0x0D4A
#define PID_OC_TRP                              0x0D4B
#define PID_OC_MEMORYVOLTAGE                    0x0D4C
#define PID_OC_NUMBEROFFAILEDBOOTS              0x0D4D

///////////////////////////////////////////////////////////
// PID 0x0D4E TO 0x0D6F Available for future use
///////////////////////////////////////////////////////////

// USB Variables
#define PID_USB_USBMASSDEVNUM                   0x0D70
#define PID_USB_INTERACTIONALLOWED              0x0D71
#define PID_USB_USBLEGACYSUPPORT                0x0D72
#define PID_USB_USBEHCIHANDOFF                  0x0D73
#define PID_USB_USBHOTPLUGFDDSUPPORT            0x0D74
#define PID_USB_USBHOTPLUGCDROMSUPPORT          0x0D75
#define PID_USB_USBEMUL6064                     0x0D76
#define PID_USB_USBMASSRESETDELAY               0x0D77

///////////////////////////////////////////////////////////
// PID 0x0D78 TO 0x0D7F Available for future use
///////////////////////////////////////////////////////////

#define PID_USB_USBEMU1                         0x0D80
#define PID_USB_USBEMU2                         0x0D81
#define PID_USB_USBEMU3                         0x0D82
#define PID_USB_USBEMU4                         0x0D83
#define PID_USB_USBEMU5                         0x0D84
#define PID_USB_USBEMU6                         0x0D85
#define PID_USB_USBEMU7                         0x0D86
#define PID_USB_USBEMU8                         0x0D87

///////////////////////////////////////////////////////////
// PID 0x0D88 TO 0x0DFF Available for future use
///////////////////////////////////////////////////////////

// Platform Variables
#define PID_PLATFORM_ACTIVETRIPPOINTLOWFANSPEED     0x0E00
#define PID_PLATFORM_ACTIVETRIPPOINTHIGHFANSPEED    0x0E01
#define PID_PLATFORM_PASSIVETHERMALTRIPPOINT        0x0E02
#define PID_PLATFORM_CRITICALTHERMALTRIPPOINT       0x0E03
#define PID_PLATFORM_PASSIVETC1VALUE                0x0E04
#define PID_PLATFORM_PASSIVETC2VALUE                0x0E05
#define PID_PLATFORM_PASSIVETSPVALUE                0x0E06
#define PID_PLATFORM_ENABLETHERMALOFFSET            0x0E07
#define PID_PLATFORM_ENABLEDTSCALIBRATION           0x0E08
#define PID_PLATFORM_ACTIVETHERMALTRIPPOINTMCD4     0x0E09
#define PID_PLATFORM_PASSIVETHERMALTRIPPOINTMCD4    0x0E0A
#define PID_PLATFORM_ACTIVETHERMALTRIPPOINTTMEM     0x0E0B
#define PID_PLATFORM_PASSIVETHERMALTRIPPOINTTMEM    0x0E0C

///////////////////////////////////////////////////////////
// PID 0x0E0D TO 0x0E0F Available for future use
///////////////////////////////////////////////////////////

#define PID_RBU_INFO                            0x0E10      // 2 WORD + 4 BYTE (see struct DELL_RBU_INFO in DellRbuInfo.h)
#define PID_EDIAGS_ADDRESS                      0x0E11      // Dell EDiags (PSA) memory location
#define PID_BLACKTOP_READER_ADDRESS            (0x0E12 | PT_VOLATILE) // Dell Blacktop Reader Rom Memory Location (in lower memory)
#define PID_MANIFEST                            0x0E13      // Dell Manifest - versions of current modules
#define PID_ME_ENABLEENDOFPOST                  0x0E14
#define PID_IMAGESERVER_STATUS                  0x0E15      // Dell Image Server data
// RETIRED - DO NOT USE                         0x0E16
#define PID_POWER_STATE                         0x0E17
#define VALUE_POWER_STATE_ON                        0xA5
#define VALUE_POWER_STATE_OFF                       0x5A
#define PID_POWER_FAIL                          0x0E18
#define POWER_FAIL_FLAG_TRUE                        0xA5
#define POWER_FAIL_FLAG_FALSE                       0x5A
#define PID_ECC_LOG_CONTROL                     0x0E19
    #define ECC_LOG_ENABLED_MASK                    0x01
    #define ECC_LOG_ENABLED                         0x01
    #define ECC_LOG_DISABLED                        0x00
    #define ECC_LOG_MAX_LEN                        (16 * 30)    // Max 30 entries for now.
#define PID_NIC2                                0x0E1A
    #define VALUE_NIC2_DIS                          0
    #define VALUE_NIC2_EN                           1

#define PID_SAS                                 0x0E1B
    #define VALUE_SAS_DIS                           0
    #define VALUE_SAS_EN                            1

#define PID_ADV_SYS_MGMT                        0x0E1C

#define PID_PRIMARY_VIDEO_SLOT                      0x0E1E
    #define VALUE_PRIMARY_VIDEO_ONBOARD             0   // If no onboard, this can be used to mean "Auto"
    #define VALUE_PRIMARY_VIDEO_SLOT_1              1
    #define VALUE_PRIMARY_VIDEO_SLOT_2              2
    #define VALUE_PRIMARY_VIDEO_SLOT_3              3
    #define VALUE_PRIMARY_VIDEO_SLOT_4              4
    #define VALUE_PRIMARY_VIDEO_SLOT_5              5
    #define VALUE_PRIMARY_VIDEO_SLOT_6              6
    #define VALUE_PRIMARY_VIDEO_SLOT_7              7
    #define VALUE_PRIMARY_VIDEO_AUTO                0xFF

#define PID_ABOVE_4G_PCI_DECODE                 0x0E1F   // Enable/Disable 64bit capable PCI device to be decoded in above 4G memory space
    #define VALUE_ABOVE_4G_PCI_DECODE_ENABLE    0x01     // Enable decoding in above 4G memory space

// RETIRED - DO NOT USE                         0x0E20

#define PID_VAR_SYS_FAN_SPEED                   0x0E21
    #define VALUE_VAR_SYS_FAN_SPEED_10              10
    #define VALUE_VAR_SYS_FAN_SPEED_20              20
    #define VALUE_VAR_SYS_FAN_SPEED_30              30
    #define VALUE_VAR_SYS_FAN_SPEED_40              40
    #define VALUE_VAR_SYS_FAN_SPEED_50              50
    #define VALUE_VAR_SYS_FAN_SPEED_60              60
    #define VALUE_VAR_SYS_FAN_SPEED_70              70
    #define VALUE_VAR_SYS_FAN_SPEED_80              80
    #define VALUE_VAR_SYS_FAN_SPEED_90              90
    #define VALUE_VAR_SYS_FAN_SPEED_100             100
    #define VALUE_VAR_SYS_FAN_SPEED_AUTO            0xFF

#define PID_LID_SWITCH                          0x0E22
#define PID_M2_PCIE_SSD                         0x0E23

///////////////////////////////////////////////////////////
//PID 0x0E24 TO 0x0E2F Available for future use
///////////////////////////////////////////////////////////

#define PID_COMMON_BIOS_MKTG_NAME               0x0E30
#define PID_COMMON_BIOS_SYS_ID                  0x0E31

#define PID_COLUMBUS_WWAN_HW_WORKAROUND         0x0E32
#define PID_2S2P_BATT_SUPPORTING_DOCK           0x0E33
#define PID_COMMON_BIOS_UNIQUE_SYNC_NUM         0x0E34
#define PID_USB3_FRONT_PORT_EN                  0x0E35      // Enable USB3 Front Ports
#define PID_USB3_REAR_PORT_EN                   0x0E36      // Enable USB3 Rear Ports
#define PID_PCIE_ASPM                           0x0E37      // PCIE ASPM mode.
    #define VALUE_PCIE_ASPM_AUTO                  0x04      // PCIE ASPM AUTO mode.
    #define VALUE_PCIE_ASPM_DIS                   0x00      // PCIE ASPM Disable.
    #define VALUE_PCIE_ASPM_L1_ONLY               0x02      // PCIE ASPM L1 Only.

///////////////////////////////////////////////////////////
//PID 0x0E38 TO 0x0E62 Available for future use
///////////////////////////////////////////////////////////


#define PID_SMART_AMP_AUDIO_CONFIG_DATA         0x0E63
#define PID_FISCHER_CONNECTOR_PRESENT           0x0E64

#define PID_FACTORY_FPT_PROCESS_MARKER          0x0E65

#define PID_FLASHINTERFACE                      0x0E66      //Flash Capability
#define PID_ESRT_TABLE                          0x0E67
#define PID_SIGN_OF_LIFE                        0x0E68      // Sign of Life Indication
#define PID_SERIAL_PORT3                        0x0E69
    #define VALUE_SER3_DIS                          0   // Serial port 3 disable
    #define VALUE_SER3_AUTO                         1   // Serial port 3 auto-config
#define PID_SERIAL_PORT4                        0x0E6A
    #define VALUE_SER4_DIS                          0   // Serial port 4 disable
    #define VALUE_SER4_AUTO                         1   // Serial port 4 auto-config
#define PID_SERIAL_PORT5                        0x0E6B
    #define VALUE_SER5_DIS                          0   // Serial port 5 disable
    #define VALUE_SER5_AUTO                         1   // Serial port 5 auto-config
#define PID_SERIAL_PORT6                        0x0E6C
    #define VALUE_SER6_DIS                          0   // Serial port 6 disable
    #define VALUE_SER6_AUTO                         1   // Serial port 6 auto-config
#define PID_CANBUS                               0x0E6D
    #define VALUE_CANBUS_DIS                        0
    #define VALUE_CANBUS_AUTO                       1

///////////////////////////////////////////////////////////
//PID 0x0E6E TO 0x0FFF Available for future use
///////////////////////////////////////////////////////////

/*
********************************************************************************************
********************************************************************************************
** PLATFORM BUILDS MUST NOT MODIFY THIS FILE.  PLATFORM BUILDS MUST NOT MODIFY THIS FILE. **
**                                                                                        **
** These definitions must maintain uniqueness.                                            **
**                                                                                        **
** Dell Provided Features and Independent BIOS Vendor and Independent Hardware Vendor    **
**  must all make use of this file to build against, and the golden master will be        **
**  maintained by Dell because the Dell Property ID is subject to Dell governance.        **
**                                                                                        **
** Please submit any required changes back to Dell Provided Features for inclusion, which **
**  will permit "locking" the file. The intention of this requriement is not to impede    **
**  access but to guarantee that no two properties collide.                               **
********************************************************************************************
********************************************************************************************
*/


#endif
