Draft_7
      1. Fix the issue: When the machine has a system service tag that don't list on support tables and SUMA is not present.
                        It will do the comparing with the support table on every booting.
      2. Remove DellAUxMac.sdl override.
         Reason: AMI don't suggest to change token value by this method.  	
      3. Remove "ProduceServiceTagDigestTable" codes

Draft_6
      1. Support one special service tag to verify the SUMA for shipping solution.
         Service Tag:BPSQNY1
         MAC Address:102030405060 
 
Draft_5
(NEW) 1. Offer LivingStone1 modified codes.
      2. Adjust Rugged2 code structure.

PS: LivingStone1 is for LiningStone1 project.
    Rugged2 is for Rugged gen2 platform.